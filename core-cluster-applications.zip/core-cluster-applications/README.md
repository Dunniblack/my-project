# Core Cluster Base Tooling

## How To Maintain this Suite of Tools

1. Inspect sandbox tooling versions via Argo
2. In the case of major version iteration, investigate necessary manual activities
   - Apply required modifications for major version iteration
3. Evaluate functionality on sandbox
4. If functionality is acceptable, create a PR that progresses the non-sandbox versions up to the version that the sandbox Argo app has resolved
5. Upon PR merge, non-sandbox deployments will update

## Modifying Values

- Do **not** make direct modifications to the template body of the application set
- Instead, add list elements that will only modify sandbox
- Verify changes in sandbox
- Update body of application set after confirming sandbox configuration

## Supported Tools

Migration is under way and this list will expand as tools are migrated out of the noms-cluster-base chart and into Argo application sets.

- Cert Manager
- Sealed Secrets
- Traefik
