<#
.SYNOPSIS
    K8S Management Tools Credential Rotation Script

.DESCRIPTION
    Rotates admin credentials for Rancher, ArgoCD, or Keycloak and writes the
    new password to Azure Key Vault for compliance monitoring.

    Keycloak is semi-automatic: the admin rotates the password via the Keycloak
    UI and updates the K8s secret, then this script syncs the K8s secret value
    to Key Vault. The pgpass (database) credential is NOT rotated here — it is
    a service account credential outside the scope of STIG V-222545.
#>
param(
    [Parameter(Mandatory = $true)] [string]$ClusterName,
    [Parameter(Mandatory = $true)] [string]$ResourceGroupName,
    [Parameter(Mandatory = $true)] [string]$TargetTool,
    [Parameter(Mandatory = $true)] [string]$KeyVaultName,
    [Parameter(Mandatory = $true)] [string]$BinDir
)

. "$PSScriptRoot/../functions/CommonUtilities.ps1"
$ErrorActionPreference = "Stop"

$env:KUBECONFIG = "$BinDir\kubeconfig"
$env:Path += ";$BinDir"
if (Test-Path $env:KUBECONFIG) {
    Remove-Item $env:KUBECONFIG -Force
}

$toolLower = $TargetTool.ToLower()

Write-Host "`n=========================================="
Write-Host "Standardized Credential Rotation Pipeline"
Write-Host "Cluster   : $ClusterName"
Write-Host "Target    : $toolLower"
Write-Host "Key Vault : $KeyVaultName"
Write-Host "==========================================`n"

Write-Host "Authenticating to AKS cluster $ClusterName..."
$null = Exec az aks get-credentials --resource-group $ResourceGroupName --name $ClusterName --overwrite-existing --format azure
$null = Exec "$BinDir\kubelogin.exe" convert-kubeconfig -l azurecli

(Get-Content $env:KUBECONFIG).Replace('kubelogin', "$BinDir\kubelogin.exe") | `
    Set-Content $env:KUBECONFIG

$newPassword = $null

switch ($toolLower) {
    "rancher" {
        Write-Host "Locating Rancher controller pod..."
        $podOutput = Exec kubectl -n cattle-system get pods -l app=rancher --no-headers
        $podName = ($podOutput -split '\s+')[0]

        if (-not $podName) { throw "Rancher controller pod not found." }

        Write-Host "Executing reset-password inside pod: $podName"
        $rawOutput = Exec kubectl -n cattle-system exec $podName -c rancher -- reset-password

        if ($rawOutput -match "New password for default administrator \(.*\):\s*(.*)") {
            $newPassword = $matches[1].Trim()
        }
        else { throw "Failed to parse Rancher output. Trace: $rawOutput" }
    }
    "argocd" {
        Write-Host "Nullifying active password strings from argocd secrets using JSON patch..."

        $patchJson = @"
[
  {
    "op": "replace",
    "path": "/data/admin.password",
    "value": null
  },
  {
    "op": "replace",
    "path": "/data/admin.passwordMtime",
    "value": null
  }
]
"@

        $null = Exec kubectl patch secret argocd-secret -n argocd --type='json' -p $patchJson

        Write-Host "Executing rollout restart on core-app-argocd-server..."
        $null = Exec kubectl -n argocd rollout restart deployment/core-app-argocd-server
        $null = Exec kubectl -n argocd rollout status deployment/core-app-argocd-server

        Write-Host "Retrieving newly generated password from argocd-initial-admin-secret..."
        $base64Pass = Exec kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}"

        if ([string]::IsNullOrEmpty($base64Pass)) {
            throw "ArgoCD initial admin secret password field is empty or failed to auto-regenerate."
        }

        $newPassword = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($base64Pass)).Trim()
    }
    "keycloak" {
        Write-Host "`n=========================================="
        Write-Host "Keycloak Admin Password Sync (Semi-Automatic)"
        Write-Host "==========================================`n"

        $namespace  = "auth"
        $secretName = "keycloak-admin-password"
        $secretKey  = "keycloak-admin-password"

        Write-Host "Reading admin password from K8s secret '$secretName' in namespace '$namespace'..."
        $b64Pass = Exec kubectl get secret $secretName -n $namespace -o jsonpath="{.data.$secretKey}"

        if ([string]::IsNullOrEmpty($b64Pass)) {
            throw @"
K8s secret '$secretName' (key '$secretKey') not found or empty in namespace '$namespace'.

This pipeline does NOT rotate the Keycloak admin password. The admin must:
  1. Rotate the password via the Keycloak admin UI.
  2. Update the K8s secret '$secretName' in namespace '$namespace' with the new password.
  3. Re-run this pipeline to sync the K8s secret value to Key Vault.
"@
        }

        $newPassword = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($b64Pass)).Trim()
        Write-Host "Admin password retrieved from K8s secret. Syncing to Key Vault..."
    }
    default { throw "Unsupported tool specified: $toolLower" }
}

Write-Host "Updating Azure Key Vault secret '$toolLower-admin-password'..."
$SecretValue = ConvertTo-SecureString $newPassword -AsPlainText -Force
Set-AzKeyVaultSecret -VaultName $KeyVaultName -Name "$toolLower-admin-password" -SecretValue $SecretValue | Out-Null
Write-Host "Key Vault updated successfully. 60-day STIG compliance clock reset for $toolLower."
exit 0
