<#
.SYNOPSIS
    AKS TLS Certificate Expiry Monitor

.DESCRIPTION
    Scans every Terraform-managed AKS cluster in the current subscription for
    tls.crt and ca.crt secrets expiring within a fixed threshold. Per-cluster
    findings are uploaded as JSON reports to Azure Blob Storage.

    Cluster discovery is tag-based: only clusters carrying the TerraformWorkspace
    resource tag (applied by terraform/modules/tags) are scanned.
#>

param (
    [Parameter(Mandatory = $true)]  [string]$StorageAccountName,
    [Parameter(Mandatory = $true)]  [string]$ContainerName,
    [Parameter(Mandatory = $false)] [string]$StorageAccountKey = '',
    [Parameter(Mandatory = $false)] [string]$BinDir = ''
)

. "$PSScriptRoot/../functions/CommonUtilities.ps1"
. "$PSScriptRoot/../functions/AzStorageAccountTools.ps1"

$ErrorActionPreference = "Stop"

$ExpiryThresholdDays = 30
$WorkspaceTagName    = 'TerraformWorkspace'

$ExpirationLimit = (Get-Date).AddDays($ExpiryThresholdDays)
$CurrentDateStr  = Get-Date -Format "yyyyMMdd-HHmm"
$TotalFindings   = 0
$FailedClusters  = @()

$KubectlCmd   = 'kubectl'
$KubeloginCmd = 'kubelogin'
if ($BinDir -and (Test-Path $BinDir)) {
    $env:Path     = "$BinDir;$env:Path"
    $KubectlCmd   = Join-Path $BinDir 'kubectl.exe'
    $KubeloginCmd = Join-Path $BinDir 'kubelogin.exe'
}

if ($StorageAccountKey) {
    $AlertStorageInfo = New-StorageAccountInfo -Name $StorageAccountName -Container $ContainerName -AccountKey $StorageAccountKey
} else {
    $AlertStorageInfo = New-StorageAccountInfo -Name $StorageAccountName -Container $ContainerName
}

Write-Host "`n=========================================="
Write-Host "AKS TLS Certificate Expiry Monitor"
Write-Host "Threshold : $ExpiryThresholdDays days"
Write-Host "Discovery : tag '$WorkspaceTagName'"
Write-Host "Storage   : $StorageAccountName / $ContainerName"
Write-Host "==========================================`n"

Write-Host "Fetching AKS cluster list from subscription..."
$ClusterJsonRaw = Exec az aks list --query "[].{name:name, rg:resourceGroup, tags:tags}" -o json
$ClusterJsonStr = ($ClusterJsonRaw -join "`n")
[array]$AllClusters = ConvertFrom-Json -InputObject $ClusterJsonStr

[array]$Clusters = $AllClusters | Where-Object {
    $_.tags -and ($_.tags.PSObject.Properties.Name -contains $WorkspaceTagName) -and $_.tags.$WorkspaceTagName
}

Write-Host "Found $($AllClusters.Count) AKS cluster(s); $($Clusters.Count) are Terraform-managed."

if ($Clusters.Count -eq 0) {
    Write-Host "No matching clusters. Exiting cleanly."
    exit 0
}
Write-Host ""

foreach ($C in $Clusters) {
    Write-Host "--- Checking Cluster: $($C.name) in RG: $($C.rg) ---"
    $ExpiringCerts = @()

    try {
        $null = Exec az aks get-credentials --resource-group $C.rg --name $C.name --overwrite-existing
        $null = Exec $KubeloginCmd convert-kubeconfig -l azurecli

        if ($BinDir -and (Test-Path $BinDir)) {
            $kubeconfigPath = "$env:USERPROFILE/.kube/config"
            if (Test-Path $kubeconfigPath) {
                (Get-Content $kubeconfigPath).Replace('kubelogin', $KubeloginCmd) |
                    Set-Content $kubeconfigPath
            }
        }

        $namespaceOutput = Exec $KubectlCmd get namespaces -o jsonpath='{.items[*].metadata.name}'

        foreach ($ns in (-split $namespaceOutput)) {
            Write-Host "  Checking namespace: $ns"

            $secretOutput = Exec $KubectlCmd get secrets -n $ns --field-selector type=kubernetes.io/tls `
                -o jsonpath='{.items[*].metadata.name}'

            foreach ($s in (-split $secretOutput)) {
                Write-Host "    Processing secret: $s"

                foreach ($key in @("tls.crt", "ca.crt")) {
                    $certDataB64 = Exec $KubectlCmd get secret $s -n $ns -o jsonpath="{.data.$($key.Replace('.', '\.'))}"

                    if ($certDataB64) {
                        $cert = [Security.Cryptography.X509Certificates.X509Certificate2]::new(
                            [Convert]::FromBase64String($certDataB64)
                        )
                        $daysRemaining = ($cert.NotAfter - (Get-Date)).Days

                        $status = "Valid"
                        if ($cert.NotAfter -lt (Get-Date)) { $status = "EXPIRED" }
                        elseif ($cert.NotAfter -lt $ExpirationLimit) { $status = "EXPIRING_SOON" }

                        if ($status -ne "Valid") {
                            $ExpiringCerts += [PSCustomObject]@{
                                Cluster       = $C.name
                                ResourceGroup = $C.rg
                                Namespace     = $ns
                                SecretName    = $s
                                CertType      = $key
                                Subject       = $cert.Subject
                                Issuer        = $cert.Issuer
                                ExpiryDate    = $cert.NotAfter.ToString("yyyy-MM-dd HH:mm:ss")
                                Status        = $status
                                DaysRemaining = $daysRemaining
                            }

                            $icon = if ($status -eq "EXPIRED") { "[!!]" } else { "[!]" }
                            Write-Host "      $icon $key ($status): $($cert.NotAfter.ToString('yyyy-MM-dd')) (${daysRemaining}d remaining)"
                        }
                    }
                }
            }
        }
    }
    catch {
        Write-Warning "  [ERROR] Failed to scan cluster $($C.name): $($_.Exception.Message)"
        $FailedClusters += [PSCustomObject]@{
            Cluster       = $C.name
            ResourceGroup = $C.rg
            Error         = $_.Exception.Message
        }
        continue
    }

    if ($ExpiringCerts.Count -gt 0) {
        $TotalFindings += $ExpiringCerts.Count
        $ReportName = "tls_alert_$($C.name)_$CurrentDateStr.json"
        $TempPath = Join-Path $env:TEMP $ReportName

        $ExpiringCerts | ConvertTo-Json -Depth 5 | Set-Content -Path $TempPath -Encoding UTF8

        Write-Host "`n  Uploading $ReportName ($($ExpiringCerts.Count) finding(s)) to storage..."
        Save-Blob -StorageAccountInfo $AlertStorageInfo -BlobName "alerts/$ReportName" -FilePath $TempPath
        Write-Host "  Upload successful: alerts/$ReportName"

        Remove-Item -Path $TempPath -Force -ErrorAction SilentlyContinue
    }
    else {
        Write-Host "  No expiring certificates found in cluster $($C.name)."
    }

    Write-Host ""
}

Write-Host "=========================================="
Write-Host "AKS TLS monitoring completed."
Write-Host "Clusters scanned : $($Clusters.Count)"
Write-Host "Clusters failed  : $($FailedClusters.Count)"
Write-Host "Total findings   : $TotalFindings"
Write-Host "=========================================="

if ($TotalFindings -gt 0) {
    Write-Warning "$TotalFindings certificate(s) are expiring or already expired within $ExpiryThresholdDays days."
}

if ($FailedClusters.Count -gt 0) {
    Write-Warning "$($FailedClusters.Count) cluster(s) could not be scanned. Marking step as failed."
    exit 1
}

exit 0
