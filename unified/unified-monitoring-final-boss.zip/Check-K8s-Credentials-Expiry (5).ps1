<#
.SYNOPSIS
    STIG 60-Day Credential Expiry Monitor

.DESCRIPTION
    Scans every Terraform-managed AKS cluster for aging rotated credentials.
    For each cluster, reads its TerraformWorkspace tag, locates the matching
    Key Vault in the same resource group, and checks the age of each tracked
    secret. Falls back to deployment creation age when a secret is not yet
    stored in Key Vault. Findings are uploaded as JSON reports to Azure Blob
    Storage.
#>

param(
    [Parameter(Mandatory = $true)]  [string]$StorageAccountName,
    [Parameter(Mandatory = $true)]  [string]$ContainerName,
    [Parameter(Mandatory = $false)] [string]$StorageAccountKey = '',
    [Parameter(Mandatory = $false)] [string]$BinDir = ''
)

. "$PSScriptRoot/../functions/CommonUtilities.ps1"
. "$PSScriptRoot/../functions/AzStorageAccountTools.ps1"

$ErrorActionPreference = "Stop"

$WarningThresholdDays = 55
$StigHardLimitDays    = 60
$WorkspaceTagName     = 'TerraformWorkspace'

$CurrentDateStr = Get-Date -Format "yyyyMMdd-HHmm"
$TotalFindings  = 0
$FailedClusters = @()

$KubectlCmd   = 'kubectl'
$KubeloginCmd = 'kubelogin'
if ($BinDir -and (Test-Path $BinDir)) {
    $env:Path     = "$BinDir;$env:Path"
    $KubectlCmd   = Join-Path $BinDir 'kubectl.exe'
    $KubeloginCmd = Join-Path $BinDir 'kubelogin.exe'
}

if ($StorageAccountKey) {
    $AlertStorageInfo = New-StorageAccountInfo -Name $StorageAccountName -Container $ContainerName -AccountKey $StorageAccountKey
} else {
    $AlertStorageInfo = New-StorageAccountInfo -Name $StorageAccountName -Container $ContainerName
}

$trackedSecrets = @{
    "rancher-admin-password" = @{ Namespace = "cattle-system"; Deployment = "core-app-rancher" }
}

Write-Host "`n=========================================="
Write-Host "STIG 60-Day Credential Expiry Monitor"
Write-Host "Discovery : tag '$WorkspaceTagName'"
Write-Host "Threshold : $WarningThresholdDays days (warn) / $StigHardLimitDays days (expired)"
Write-Host "Storage   : $StorageAccountName / $ContainerName"
Write-Host "==========================================`n"

Write-Host "Fetching AKS cluster list from subscription..."
$ClusterJsonRaw = Exec az aks list --query "[].{name:name, rg:resourceGroup, tags:tags}" -o json
$ClusterJsonStr = ($ClusterJsonRaw -join "`n")
[array]$AllClusters = ConvertFrom-Json -InputObject $ClusterJsonStr

[array]$Clusters = $AllClusters | Where-Object {
    $_.tags -and ($_.tags.PSObject.Properties.Name -contains $WorkspaceTagName) -and $_.tags.$WorkspaceTagName
}

Write-Host "Found $($AllClusters.Count) AKS cluster(s); $($Clusters.Count) are Terraform-managed."

if ($Clusters.Count -eq 0) {
    Write-Host "No matching clusters. Exiting cleanly."
    exit 0
}
Write-Host ""

foreach ($C in $Clusters) {
    Write-Host "--- Checking Cluster: $($C.name) in RG: $($C.rg) ---"
    $ExpiringCreds = @()

    try {
        $WorkspaceId = $C.tags.$WorkspaceTagName
        if (-not $WorkspaceId) {
            throw "Cluster '$($C.name)' is missing the '$WorkspaceTagName' tag."
        }
        Write-Host "  Cluster workspace (from tag): $WorkspaceId"

        $KvJsonRaw = Exec az keyvault list --resource-group $C.rg `
            --query "[].{name:name, tags:tags}" -o json
        $KvJsonStr = ($KvJsonRaw -join "`n")
        [array]$RgKeyVaults = ConvertFrom-Json -InputObject $KvJsonStr

        $MatchingKv = $RgKeyVaults | Where-Object {
            $_.tags -and
            ($_.tags.PSObject.Properties.Name -contains $WorkspaceTagName) -and
            ($_.tags.$WorkspaceTagName -eq $WorkspaceId)
        } | Select-Object -First 1

        $KeyVaultName = $MatchingKv.name
        if (-not $KeyVaultName) {
            throw "No Key Vault with '$WorkspaceTagName'='$WorkspaceId' found in resource group '$($C.rg)'."
        }
        Write-Host "  Using Key Vault: $KeyVaultName (tag match: $WorkspaceTagName=$WorkspaceId)"

        $null = Exec az aks get-credentials --resource-group $C.rg --name $C.name --overwrite-existing
        $null = Exec $KubeloginCmd convert-kubeconfig -l azurecli

        if ($BinDir -and (Test-Path $BinDir)) {
            $kubeconfigPath = "$env:USERPROFILE/.kube/config"
            if (Test-Path $kubeconfigPath) {
                (Get-Content $kubeconfigPath).Replace('kubelogin', $KubeloginCmd) |
                    Set-Content $kubeconfigPath
            }
        }

        foreach ($secretName in $trackedSecrets.Keys) {
            $ageDays = $null
            $source  = ""

            try {
                $secret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $secretName -ErrorAction Stop
                $ageDays = (New-TimeSpan -Start $secret.Updated.DateTime -End (Get-Date)).Days
                $source  = "Azure Key Vault"
            }
            catch {
                Write-Host "  [INFO] $secretName not found in KV $KeyVaultName. Checking deployment age..."

                $ns     = $trackedSecrets[$secretName].Namespace
                $deploy = $trackedSecrets[$secretName].Deployment

                try {
                    $creationTimeStr = Exec $KubectlCmd get deployment $deploy -n $ns -o jsonpath='{.metadata.creationTimestamp}'

                    if (-not [string]::IsNullOrWhiteSpace($creationTimeStr)) {
                        $creationTimeStr = $creationTimeStr -replace "'", ""
                        $creationDate    = [datetime]$creationTimeStr
                        $ageDays         = (New-TimeSpan -Start $creationDate -End (Get-Date)).Days
                        $source          = "Cluster Deployment ($deploy)"
                    }
                    else {
                        Write-Warning "  [WARN] Could not retrieve creation timestamp for '$deploy' in '$ns'."
                    }
                }
                catch {
                    Write-Warning "  [WARN] Failed to query kubectl for '$deploy' in '$ns'."
                }
            }

            if ($null -ne $ageDays) {
                Write-Host "  Secret: $secretName | Age: $ageDays Days | Source: $source"

                if ($ageDays -ge $WarningThresholdDays) {
                    $ExpiringCreds += [PSCustomObject]@{
                        Cluster            = $C.name
                        ResourceGroup      = $C.rg
                        KeyVault           = $KeyVaultName
                        TerraformWorkspace = $WorkspaceId
                        SecretName         = $secretName
                        AgeDays            = $ageDays
                        Source             = $source
                        Status             = if ($ageDays -ge $StigHardLimitDays) { "EXPIRED" } else { "EXPIRING_SOON" }
                    }
                }
            }
        }
    }
    catch {
        Write-Warning "  [ERROR] Failed to scan cluster $($C.name): $($_.Exception.Message)"
        $FailedClusters += [PSCustomObject]@{
            Cluster       = $C.name
            ResourceGroup = $C.rg
            Error         = $_.Exception.Message
        }
        continue
    }

    if ($ExpiringCreds.Count -gt 0) {
        $TotalFindings += $ExpiringCreds.Count
        $ReportName = "credential_alert_$($C.name)_$CurrentDateStr.json"
        $TempPath   = Join-Path $env:TEMP $ReportName

        $ExpiringCreds | ConvertTo-Json -Depth 5 | Set-Content -Path $TempPath -Encoding UTF8

        Write-Host "`n  Uploading $ReportName ($($ExpiringCreds.Count) finding(s)) to storage..."
        Save-Blob -StorageAccountInfo $AlertStorageInfo -BlobName "alerts/$ReportName" -FilePath $TempPath
        Write-Host "  Upload successful: alerts/$ReportName"

        Remove-Item -Path $TempPath -Force -ErrorAction SilentlyContinue
    }
    else {
        Write-Host "  All tracked credentials within threshold for cluster $($C.name)."
    }

    Write-Host ""
}

Write-Host "=========================================="
Write-Host "Credential expiry monitoring completed."
Write-Host "Clusters scanned : $($Clusters.Count)"
Write-Host "Clusters failed  : $($FailedClusters.Count)"
Write-Host "Total findings   : $TotalFindings"
Write-Host "=========================================="

if ($TotalFindings -gt 0) {
    Write-Warning "$TotalFindings credential(s) at or beyond $WarningThresholdDays-day warning threshold."
}

if ($FailedClusters.Count -gt 0) {
    Write-Warning "$($FailedClusters.Count) cluster(s) could not be scanned. Marking step as failed."
    exit 1
}

exit 0
