# Name of the provided AKS Resource Groups
global_resource_group_name = "AZ-GV-DOD-AF-CCE-AFMC-D-IL5-JOMS-Global-RGP-01"
aks_resource_group_name    = "AZ-GV-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-AKS-RGP-01"

# Name of the dedicated AKS Vnet Resources - VNet, Subnet, RG
vnet_name                = "AZ-GV-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-VNT-01"
subnet_name              = "AZ-GV-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-AKS-SNT-01"
vnet_resource_group_name = "AZ-GV-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-NET-RGP-01"
api_server_subnet_name   = "api-server-subnet-iac"

# Name of C1 Common Service Names - VNet, Subnet, RG
cmnsvc_vnet_name           = "AZ-DE-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-VNT-01"
cmnsvc_subnet_name         = "AZ-DE-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-CMN-SNT-01"
cmnsvc_resource_group_name = "AZ-DE-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-NET-RGP-01"

# Name of the C1 Core Key Vault, RG
core_key_vault_name    = "DEJOMSMVPDIL5KVT"
kv_resource_group_name = "AZ-DE-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-COR-RGP-01"

# Name of the C1 Log Analytics, RG
log_analytics_workspace_name = "AZ-GV-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-OMS-01"
la_resource_group_name       = "AZ-GV-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-COR-RGP-01"

# Name of the C1 Automation Account, RG
automation_account_name = "AZ-GV-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-AAA-01"
aa_resource_group_name  = "AZ-GV-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-COR-RGP-01"

# Azure Active Directory Group IDs of the Admin and Read-Only groups
# Admin name convention      - Contributor-CCE-AFMC-JOMSMVP-APP-DEV
admin_aad_group_ids = "2d8ce923-9ccb-4fec-9410-34464f25fe45"
# Read Only name convention  - ReadOnly-CCE-AFMC-JOMSMVP-APP-DEV
read_only_aad_group_id = "4c72f446-494d-4438-a05c-903f14a61cf1"

# Managed identities for AKS
# (Required if using Dedicated Hosts)
mi_resource_group_name = "AZ-GV-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-AKS-RGP-01"
mi_kubelet_name        = "JOMSMVP-AKS-KUBELET-IDENTITY"
mi_control_plane_name  = "JOMSMVP-AKS-CP-IDENTITY"
mi_velero_name         = "JOMSMVP-AKS-VELERO-IDENTITY"
mi_loki_name           = "JOMSMVP-LOKI-IDENTITY"
mi_eso_name            = "JOMSMVP-ESO-IDENTITY"
