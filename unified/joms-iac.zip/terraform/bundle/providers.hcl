// https://github.com/hashicorp/terraform/blob/v0.15/tools/terraform-bundle/README.md

// Note: The Terraform Version number is also located in scrits/sh/metadata/versions.sh
// Make sure to keep these version numbers in sync.

terraform {
  version = "1.14.4"
}

providers {
  azurerm = {
    source   = "hashicorp/azurerm"
    versions = ["~> 4.58.0"]
  }
  kubernetes = {
    source   = "hashicorp/kubernetes"
    versions = ["~> 3.0.1"]
  }
  helm = {
    source   = "hashicorp/helm"
    versions = ["~> 3.1.1"]
  }
  random = {
    source   = "hashicorp/random"
    versions = ["~> 3.8.1"]
  }
  local = {
    source   = "hashicorp/local"
    versions = ["~> 2.6.2"]
  }
  null = {
    source   = "hashicorp/null"
    versions = ["~> 3.2.4"]
  }
  tls = {
    source   = "hashicorp/tls"
    versions = ["~> 4.2.1"]
  }
  archive = {
    source   = "hashicorp/archive"
    versions = ["~> 2.7.1"]
  }
  external = {
    source   = "hashicorp/external"
    versions = ["~> 2.3.5"]
  }
  time = {
    source   = "hashicorp/time"
    versions = ["~> 0.13.1"]
  }
}