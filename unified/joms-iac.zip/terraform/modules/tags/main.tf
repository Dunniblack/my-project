locals {
  common_tags = {
    Enclave   = var.enclave
    ManagedBy = "Terraform"
    TerraformWorkspace = (
      (var.parent_module == "global") ?
      "Global" :
      var.environment_name
    )
  }
}
