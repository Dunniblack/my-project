output "common_tags" {
  value       = local.common_tags
  description = "common tags"
}
