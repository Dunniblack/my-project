variable "enclave" {
  type        = string
  description = "TF enclave: C1/WDSF"
}

variable "environment_name" {
  type        = string
  description = "TF environment name: TEST/MVP"
}

variable "parent_module" {
  type        = string
  description = "TF parent module: Global/Planner/Software"
}
