locals {
  # Transform the input strings into objects with properties
  transformed_objects = [
    for str in var.input_strings : merge(
      {
        (var.string_key) = str
      },
      var.properties
    )
  ]

  # Merge transformed objects with in static objects passed into the module
  result = concat(local.transformed_objects, var.objects_to_append)

  # Group final list by key property, making it ready to be used as a set
  result_grouped_bv_key = {
    for object in local.result : lookup(object, var.string_key) => object
  }
}
