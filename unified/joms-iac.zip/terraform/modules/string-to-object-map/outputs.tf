output "objects" {
  description = "List of objects created from input strings with added properties"
  value       = local.result
}

output "objects_by_key" {
  description = "Map of objects grouped by string key. Suitable to be converted to a set"
  value       = local.result_grouped_bv_key
}
