variable "input_strings" {
  description = "List of strings to be transformed into objects"
  type        = list(string)
}

variable "string_key" {
  description = "The key to use when adding the string value to the resulting objects. Defaults to 'name'"
  type        = string
  default     = "name"
}

variable "properties" {
  description = "Map of properties to be added to each object"
  type        = map(any)
}

variable "objects_to_append" {
  description = "Optional list of static objects to be appended to the transformed list"
  type        = list(map(any))
  default     = []
}


