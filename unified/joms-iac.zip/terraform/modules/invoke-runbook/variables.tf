variable "enclave" {
  description = "The enclave that we're executing the logic (i.e. 'wdsf', 'c1')."
  type        = string
  default     = "c1"
  validation {
    condition     = contains(["wdsf", "c1", "thundercamp"], var.enclave)
    error_message = "The enclave  must be one of the follwing: \"wdsf\", \"c1\", \"thundercamp\""
  }
}

variable "automation_account_name" {
  type = string
}

variable "aa_resource_group_name" {
  type = string
}

variable "runbook_name" {
  type    = string
  default = "update-bastion-hosts-file"
}
