# In C1, we run an Automation Account runbook to fix the hosts file
resource "null_resource" "invoke_runbook" {
  count = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1

  provisioner "local-exec" {
    command = format("%s%s%s%s%s",
      "Start-AzAutomationRunbook",
      " -Name $env:RUNBOOK_NAME",
      " -AutomationAccountName $env:AUTOMATION_ACCOUNT_NAME",
      " -ResourceGroupName $env:RESOURCE_GROUP",
      " -MaxWaitSeconds 1000 -Wait"
    )
    environment = {
      AUTOMATION_ACCOUNT_NAME = var.automation_account_name
      RUNBOOK_NAME            = var.runbook_name
      RESOURCE_GROUP          = var.aa_resource_group_name
    }
    interpreter = ["PowerShell", "-Command"]
  }
}

# In WDSF, we run the same runbook/PS1 on the local machine
resource "null_resource" "invoke_runbook_localhost" {
  count = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 1 : 0

  provisioner "local-exec" {
    command = format("%s%s",
      "${abspath(path.root)}/../../scripts/ps/runbooks/update-bastion-hosts-file.ps1",
      " -enclave $env:ENCLAVE"
    )
    environment = {
      ENCLAVE = "wdsf"
    }
    interpreter = ["PowerShell", "-Command"]
  }
}
