variable "resource_group_name" {
  description = "AKS resource group"
  type        = string
}

variable "aks_cluster_name" {
  description = "AKS cluster name"
  type        = string
}

variable "api_server_subnet_id" {
  description = "API server subnet id"
  type        = string
}

variable "key_vault_resource_id" {
  type        = string
  description = "KeyVault resource ID"
}

variable "key_vault_kms_key_id" {
  type        = string
  description = "KeyVault key URI."
}

variable "aks_kmsv2_setup" {
  type        = bool
  description = "Logic to check if we have KMS v2 set up"
}
