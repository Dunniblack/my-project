resource "null_resource" "enable_kmsv2_function" {

  provisioner "local-exec" {
    command = format("%s%s%s%s%s%s%s",
      "${abspath(path.root)}/../../scripts/ps/terraform/Enable-KmsV2.ps1",
      " -resourceGroupName $env:resourceGroupName",
      " -aksClusterName $env:aksClusterName",
      " -apiServerSubnetId $env:apiServerSubnetId",
      " -keyVaultResourceId $env:keyVaultResourceId",
      " -keyVaultKeyUri $env:keyVaultKeyUri",
      " -AksKmsV2Setup $env:AksKmsv2Setup"
    )
    environment = {
      resourceGroupName  = var.resource_group_name
      aksClusterName     = var.aks_cluster_name
      apiServerSubnetId  = var.api_server_subnet_id
      keyVaultResourceId = var.key_vault_resource_id
      keyVaultKeyUri     = var.key_vault_kms_key_id
      AksKmsV2Setup      = var.aks_kmsv2_setup
    }
    interpreter = ["PowerShell", "-Command"]
  }
}
