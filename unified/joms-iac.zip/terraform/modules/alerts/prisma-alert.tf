#### After Hours Login
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "prisma_after_hours_login" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "PrismaCloud After Hours Login"
  description             = "NIST CONTROL: AU-6\nAlert when admin access is identified at abnormal times (UTC: 2200 - 1000)"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    # TODO: This query identifies after hours login attempts (both successful and unsuccessful) for all users, not just admins
    query = <<-QUERY
      let TargetNamespace = "twistlock";     // Twistlock namespace
      ContainerLogV2
      | extend Hour = datetime_part("hour", TimeGenerated)
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where PodNamespace == TargetNamespace
      | where LogMessage contains "type=\"management_audit\""
          and LogMessage contains "log_type=\"login\""
      | where Hour >= 22 or Hour < 10        // Off-hours: 10 PM to 10 AM UTC
      | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage
      | order by TimeGenerated desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}


#### Log Forwarding Failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "prisma_log_forwarding_failure" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "PrismaCloud Audit Log Forwarding Failure"
  description             = "NIST CONTROL: AU-2, AU-12\nAlert when PrismaCloud fails to forward logs to centralized log systems"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      let ExpectedPods = ContainerLogV2
          | where PodNamespace == "twistlock"
          | where TimeGenerated > ago(1h)
          | distinct PodName;
      let ActivePods = ContainerLogV2
          | where PodNamespace == "twistlock"
          | where TimeGenerated > ago(5m)
          | distinct PodName;
      let InactivePods = ExpectedPods
          | join kind=leftanti (ActivePods) on PodName;
      ContainerLogV2
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where TimeGenerated > ago(1h)
      | where PodNamespace == "twistlock"
      | join kind=inner (InactivePods) on PodName
      | summarize LastSeen = max(TimeGenerated) by ClusterName, PodNamespace, PodName, ContainerName
      | project LastSeen, ClusterName, PodNamespace, PodName, ContainerName
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}


#### Excessive Failed Logins
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "prisma_excessive_failed_logins" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "PrismaCloud Excessive Failed Logins"
  description             = "NIST CONTROL: AC-7\nAlert on repeated failed login attempts for users or clients"
  severity                = 0
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 3
    query                   = <<-QUERY
      ContainerLogV2
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where tostring(PodNamespace) == "twistlock"
      | where LogMessage contains "type=\"management_audit\""
          and LogMessage contains "log_type=\"login\""
          and LogMessage !contains "status=\"successful login attempt\""
      | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### New Admin Assigned
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "prisma_new_admin_assigned" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "PrismaCloud New Admin Assigned"
  description             = "NIST CONTROL: AC-2, AC-6\nAlert on the assignment of admin role to any user"
  severity                = 0
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      ContainerLogV2
      | where tostring(PodNamespace) == "twistlock"
          and LogMessage contains "type=\"management_audit\""
          and LogMessage contains "log_type=\"user\""
      | extend
          ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId),
          RawChanges = extract(@'changes=(.+)"', 1, tostring(LogMessage))
      | where RawChanges matches regex @'+.*\\"role\\"\s*:\s*\\"(cloudAccountManager|admin)\\"'
      | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Runtime Settings Changed
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "prisma_runtime_settings_changed" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "PrismaCloud Runtime Settings Changed"
  description             = "NIST CONTROL: CM-6\nAlert on change to runtime policies"
  severity                = 0
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    # A successful login triggers a 'lastModified' update to every group assigned to the user, as well as a 'modified'
    # update to a number of rules. This query filters out log entries that only contain changes to either the
    # 'lastModified' or 'modified' attributes by comparing the number of lastModified/modified diff annotations with
    # the total number of diff annotations within the log entry's changes.
    query = <<-QUERY
      ContainerLogV2
      | where tostring(PodNamespace) == "twistlock"
          and LogMessage contains "type=\"management_audit\""
          and LogMessage !contains "log_type=\"login\""
      | extend
          ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId),
          RawChanges = extract(@'changes=(.+)"', 1, tostring(LogMessage))
      | extend
          ModifiedDateChanges = countof(RawChanges, @'\s*[-+]\s*\\"(lastModified|modified)\\"', 'regex'),
          TotalChanges = countof(RawChanges, @'\s*[-+]\s*\\"', 'regex')
      | where ModifiedDateChanges != TotalChanges
      | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}


#### Unavailable or Unresponsive
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "prisma_unavailable_or_unresponsive" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "PrismaCloud Unavailable or Unresponsive"
  description             = "NIST CONTROL: SI-4\nDetect when PrismaCloud goes offline or stops responding"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      (
      KubePodInventory
      | where TimeGenerated > ago(15m)
      | where Namespace == "twistlock"
      | where Name startswith "twistlock-console-" or Name startswith "twistlock-defender-ds-"
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId),
              Component   = iif(Name startswith "twistlock-console-","Console","Defender")
      | summarize arg_max(TimeGenerated, PodStatus, PodRestartCount, ContainerRestartCount, Name, Component, ClusterName) by Name
      | extend PodStatus = tolower(tostring(PodStatus))
      | where PodStatus !in ("running","succeeded")
      | project TimeGenerated, ClusterName, Component, PodName=Name, IssueType="Unresponsive",
                PodStatus, PodRestartCount, ContainerRestartCount
      )
      | union (
      KubePodInventory
      | where TimeGenerated > ago(15m)
      | where Namespace == "twistlock"
      | where Name startswith "twistlock-console-" or Name startswith "twistlock-defender-ds-"
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId),
              Component   = iif(Name startswith "twistlock-console-","Console","Defender")
      | summarize arg_max(TimeGenerated, PodStatus, PodRestartCount, ContainerRestartCount, Name, Component, ClusterName) by Name
      | extend PodRestarts = toint(coalesce(PodRestartCount, 0)),
              CtrRestarts = toint(coalesce(ContainerRestartCount, 0))
      | where PodRestarts > 2 or CtrRestarts > 2
      | project TimeGenerated, ClusterName, Component, PodName=Name, IssueType="Restarts",
                PodStatus, PodRestartCount=PodRestarts, ContainerRestartCount=CtrRestarts
      )
      | union (
      KubePodInventory
      | where TimeGenerated > ago(15m)
      | where Namespace == "twistlock"
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | summarize SeenConsole = dcountif(Name, Name startswith "twistlock-console-") by ClusterName
      | where SeenConsole == 0
      | project TimeGenerated=now(), ClusterName, Component="Console", PodName="(none)", IssueType="Unavailable",
                PodStatus="(n/a)", PodRestartCount=int(0), ContainerRestartCount=int(0)
      )
      | order by TimeGenerated desc, ClusterName, Component, IssueType, PodName
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}
