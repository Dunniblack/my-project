#### Repeated Failed Basic Auth on Services
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "traefik_repeated_failed_auth_services" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Traefik Repeated Failed Basic Auth on Services"
  description             = "NIST CONTROL: AC-7\nDetect brute-force or repeated login attempts to services behind Traefik"
  severity                = 0
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    # Find In ContainerLogV2
    # Find in ContainerLogV2 to search for a specific value in the ContainerLogV2 table.
    # Note that this query requires updating the <SeachValue> parameter to produce results
    # This query requires a parameter to run. Enter value in SearchValue to find in table.
    query = <<-QUERY
			let TargetNamespace = "ingress";
			let SuspiciousThreshold = 5;
			ContainerLogV2
			| where PodNamespace == TargetNamespace
			| where LogMessage has "401" and (LogMessage has "GET" or LogMessage has "POST")
			| extend Path = extract(@"""(GET|POST)\s+([^\s]+)\s+HTTP/1\.1""", 2, tostring(LogMessage))
			| extend IP = extract(@"^([\d\.]+)", 1, tostring(LogMessage))
			| extend UserAgent = extract(@"User-Agent:\s*([^\""]+)", 1, tostring(LogMessage))
			| where isnotempty(IP)
			| extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, tostring(_ResourceId))
			| summarize FailedAttempts = count() by bin(TimeGenerated, 5m), ClusterName, IP, Path, PodName
			| where FailedAttempts >= SuspiciousThreshold  // raise from 1 to 5
			| project Time=TimeGenerated, ClusterName, ClientIP=IP, Path, PodName, FailedAttempts
			| order by Time desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Log Forwarding Failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "traefik_log_forwarding_failure" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Traefik Audit Log Forwarding Failure"
  description             = "NIST CONTROL: AU-2, AU-12\nAlert when traefik fails to forward logs to centralized log systems"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
			let TargetNamespace = "ingress";
			let ActiveWindow = 10m;
			let ExpectedWindow = 1h;
			let PodRestartThreshold = 3;

			let ExpectedPods =
					KubePodInventory
					| where TimeGenerated > ago(ExpectedWindow)
					| where ServiceName == TargetNamespace
					| distinct InstanceName;

			let ActivePods =
					ContainerLogV2
					| where TimeGenerated > ago(ActiveWindow)
					| where PodNamespace == TargetNamespace
					| distinct PodName;

			let InactivePods =
					ExpectedPods
					| join kind=leftanti (ActivePods) on $left.InstanceName == $right.PodName;

			KubePodInventory
			| where ServiceName == TargetNamespace
			| where TimeGenerated > ago(ExpectedWindow)
			| where InstanceName in (InactivePods)
			| summarize
					LastSeen = max(TimeGenerated),
					RestartCount = max(PodRestartCount)
					by InstanceName, ServiceName, ClusterId
			| where RestartCount < PodRestartThreshold
			| project ClusterId, ServiceName, InstanceName, RestartCount, LastSeen
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Data exfiltration attempt
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "traefik_data_exfiltration_attempt" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Traefik Data Exfiltration Attempt"
  description             = "NIST CONTROL: IR-4\nAlert on DoS-like behavior or data exfiltration attempt"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    # Find In ContainerLogV2
    # Find in ContainerLogV2 to search for a specific value in the ContainerLogV2 table.
    # Note that this query requires updating the <SeachValue> parameter to produce results
    # This query requires a parameter to run. Enter value in SearchValue to find in table.
    query = <<-QUERY
			let TargetNamespace = "ingress";
			let TimeWindow = 10m;
			let UniquePathThreshold = 20;
			let ResponseSizeThreshold = 5000000;
			let SafePaths = dynamic(["/metrics", "/healthz", "/ready", "/live", "/docs", "/swagger"]);
			ContainerLogV2
			| where PodNamespace == TargetNamespace
			| where TimeGenerated > ago(TimeWindow)
			| where LogMessage has_any ("GET", "POST", "PUT")
			| extend
					ClientIP = extract(@"^([\d\.]+)", 1, tostring(LogMessage)),
					Method = extract(@"\""(GET|POST|PUT|DELETE|PATCH)\s", 1, tostring(LogMessage)),
					Path = extract(@"\""(?:GET|POST|PUT|DELETE|PATCH)\s+([^\s]+)", 1, tostring(LogMessage)),
					StatusCode = toint(extract(@""" (\d{3}) ", 1, tostring(LogMessage))),
					ResponseSize = toint(extract(@""" \d{3} (\d+)", 1, tostring(LogMessage)))
			| where isnotempty(ClientIP) and isnotempty(Path)
			| where Path !in (SafePaths) // exclude safe endpoints
			| extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, tostring(_ResourceId))
			| summarize
					TotalRequests = count(),
					UniquePaths = dcount(Path),
					TotalResponseSize = sum(ResponseSize),
					FirstSeen = min(TimeGenerated),
					LastSeen = max(TimeGenerated)
				by ClientIP, PodName, ClusterName
			| extend DurationSeconds = datetime_diff("second", LastSeen, FirstSeen)
			| where TotalResponseSize > ResponseSizeThreshold and DurationSeconds < 300
			| project Time=LastSeen, ClusterName, ClientIP, PodName, TotalRequests, UniquePaths, TotalResponseSize, DurationSeconds
			| order by TotalResponseSize desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### External Access to Unsecured Routes
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "traefik_unsecured_external_access" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Traefik External Access to Unsecured Routes"
  description             = "NIST CONTROL: SC-7\nAlert if HTTP routes (unencrypted) are exposed to the public"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      AKSAudit
      | where Verb contains "create"
      | where RequestUri contains "loadbalancer"
      | extend requestBody = parse_json(RequestObject)
      | where tostring(requestBody.spec.type) in ("LoadBalancer", "LB", "loadbalancer", "lb")
      | extend ports = requestBody.spec.ports
      | mv-expand ports
      | where tostring(ports.port) != "443"
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, tostring(_ResourceId))
      | project TimeGenerated, ClusterName, Verb, RequestUri, User, SourceIps, requestBody.metadata.name, requestBody.metadata.namespace, ports.port
      | order by TimeGenerated desc
      | order by TimeGenerated desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Unavailable or Unresponsive
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "traefik_unavailable_or_unresponsive" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                      = "Traefik Unavailable or Unresponsive"
  description               = "NIST CONTROL: SI-4\nDetect when Traefik goes offline or stops responding to authentication requests"
  severity                  = 2
  evaluation_frequency      = "PT5M"
  window_duration           = "PT5M"
  query_time_range_override = "P2D"
  scopes                    = [var.c1_log_analytics_workspace_id]
  target_resource_types     = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled   = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 1
    query                   = <<-QUERY
      let ExpectedServices = KubePodInventory
      | where Namespace == 'ingress'
      | where TimeGenerated > ago(1d)
      | where isnotempty(ServiceName)
      | distinct ClusterName, ServiceName;

      let ActiveServices = KubePodInventory
      | where TimeGenerated > ago(15m)
      | where Namespace == "ingress"
      | summarize Seen = dcount(Name) by ClusterName, ServiceName
      | project ClusterName, ServiceName, Seen;

      let Unresponsive = KubePodInventory
      | where TimeGenerated > ago(15m)
      | where Namespace == "ingress"
      | summarize
          arg_max(TimeGenerated, *),
          MaxPodRestarts = max(PodRestartCount),
          MaxContainerRestarts = max(ContainerRestartCount)
          by ClusterName, PodName = Name, ServiceName
      | where tolower(tostring(PodStatus)) !in ("running", "succeeded")
          or MaxPodRestarts > 2
          or MaxContainerRestarts > 2
      | project ClusterName, ServiceName, Reason = strcat(
          "UNRESPONSIVE/RESTARTING: pod=", PodName,
          "; status=", PodStatus,
          "; pod restarts=", tostring(MaxPodRestarts),
          "; container restarts=", tostring(MaxContainerRestarts)
      );

      let Churn = KubePodInventory
      | where Namespace == 'ingress'
      | where TimeGenerated > ago(15m)
      | where isnotempty(ServiceName)
      | where ControllerKind != "DaemonSet"
      | summarize
          UniquePodsCreated = dcount(Name),
          PodNames = make_set(Name),
          FirstSeen = min(TimeGenerated),
          LastSeen = max(TimeGenerated)
          by ClusterName, ServiceName
      | where UniquePodsCreated > 3
      | project ClusterName, ServiceName, Reason = strcat('CHURN: UniquePodsCreated=', UniquePodsCreated, '; Pods=', PodNames);

      union
      (
          ExpectedServices
          | join kind=leftouter ActiveServices on ClusterName, ServiceName
          | extend Seen = coalesce(Seen, 0)
          | where Seen == 0 or isempty(Seen)
          | project ClusterName, ServiceName, Reason = "ABSENCE: No service pods seen"
      ),
      Unresponsive,
      Churn
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}
