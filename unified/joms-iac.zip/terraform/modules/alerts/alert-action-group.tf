resource "azurerm_monitor_action_group" "devops" {
  resource_group_name = var.global_resource_group
  name                = "DevOps"
  short_name          = "DevOps"

  lifecycle {
    ignore_changes = [
      email_receiver
    ]
  }

  tags = merge(
    var.common_tags,
    { Service = "action-group" }
  )
}

resource "azurerm_monitor_action_group" "cyber" {
  resource_group_name = var.global_resource_group
  name                = "Cyber"
  short_name          = "Cyber"

  lifecycle {
    ignore_changes = [
      email_receiver
    ]
  }

  tags = merge(
    var.common_tags,
    { Service = "action-group" }
  )
}

resource "azurerm_monitor_action_group" "pmo" {
  resource_group_name = var.global_resource_group
  name                = "PMO"
  short_name          = "PMO"

  lifecycle {
    ignore_changes = [
      email_receiver
    ]
  }

  tags = merge(
    var.common_tags,
    { Service = "action-group" }
  )
}

resource "azurerm_monitor_action_group" "help_desk" {
  resource_group_name = var.global_resource_group
  name                = "Help-Desk"
  short_name          = "HelpDesk"

  lifecycle {
    ignore_changes = [
      email_receiver
    ]
  }

  tags = merge(
    var.common_tags,
    { Service = "action-group" }
  )
}
