#### After Hours Login
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "argocd_after_hours_login" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Argocd After Hours Login"
  description             = "NIST CONTROL: AU-6\nAlert when admin access is identified at abnormal times (UTC: 2200 - 1000)"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    # Find In ContainerLogV2
    # Find in ContainerLogV2 to search for a specific value in the ContainerLogV2 table.
    # Note that this query requires updating the <SeachValue> parameter to produce results
    # This query requires a parameter to run. Enter value in SearchValue to find in table.
    query = <<-QUERY
      ContainerLogV2
      | where tolower(PodNamespace) == "argocd"
      | where LogMessage has "Web login successful"
      | extend
        username  = extract(@"username\s*=\s*""([^""]+)""", 1, tostring(LogMessage)),
        realmId   = extract(@"realmId\s*=\s*""([^""]+)""", 1, tostring(LogMessage)),
        clientId  = extract(@"clientId\s*=\s*""([^""]+)""", 1, tostring(LogMessage)),
        email     = extract(@"email\s*=\s*""([^""]+)""", 1, tostring(LogMessage))
      | extend hour = datetime_part("hour", TimeGenerated)
      | where hour >= 22 or hour < 10   // Off-hours filter
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | project TimeGenerated, ClusterName, PodNamespace, PodName, username, realmId, clientId, email, LogMessage
      | order by TimeGenerated desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Log Forwarding Failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "argocd_log_forwarding_failure" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Argocd Audit Log Forwarding Failure"
  description             = "NIST CONTROL: AU-2, AU-12\nAlert when argocd fails to forward logs to centralized log systems"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      let ExpectedPods = ContainerLogV2
      | where PodNamespace == "argocd"
      | where TimeGenerated > ago(1h)
      | distinct PodName;
      let ActivePods = ContainerLogV2
      | where PodNamespace == "argocd"
      | where TimeGenerated > ago(5m)
      | distinct PodName;
      let InactivePods = ExpectedPods
      | join kind=leftanti (ActivePods) on PodName;
      ContainerLogV2
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where TimeGenerated > ago(1h)
      | where PodNamespace == "argocd"
      | join kind=inner (InactivePods) on PodName
      | summarize LastSeen = max(TimeGenerated) by ClusterName, PodNamespace, PodName, ContainerName
      | project LastSeen, ClusterName, PodNamespace, PodName, ContainerName
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Excessive Failed Logins
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "argocd_excessive_failed_logins" {
  resource_group_name     = var.global_resource_group
  location                = var.location
  name                    = "Argocd Excessive Failed Logins"
  description             = "NIST CONTROL: AC-7\nAlert on repeated failed login attempts for users or clients"
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }
  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 3
    # Find In ContainerLogV2
    # Find in ContainerLogV2 to search for a specific value in the ContainerLogV2 table.
    # Note that this query requires updating the <SeachValue> parameter to produce results
    # This query requires a parameter to run. Enter value in SearchValue to find in table.
    query = <<-QUERY
      ContainerLogV2
      | where PodNamespace == "argocd" and LogMessage has "failed login"
      | parse LogMessage with * 'msg="User ' username:string ' failed login ' failureCountInLog:int ' time(s)"' *
      | where isnotempty(username) and failureCountInLog > 3
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | project TimeGenerated, ClusterName, username, ReportedFailureCount = failureCountInLog, Message = strcat("High failure count detected for user '", username, "'. ArgoCD reported ", failureCountInLog, " failed attempts."), OriginalLogMessage = LogMessage
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Unavailable or Unresponsive
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "ArgoCD_unavailable_or_unresponsive" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "ArgoCD Unavailable or Unresponsive"
  description             = "NIST CONTROL: SI-4\nDetect when ArgoCD goes offline or stops responding to authentication requests"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      let ExpectedServices = KubePodInventory
      | where Namespace == 'argocd'
      | where TimeGenerated > ago(1d)
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where isnotempty(ServiceName)
      | distinct ClusterName, ServiceName;
      let ActiveServices = KubePodInventory
      | where TimeGenerated > ago(15m)
      | where Namespace == "argocd"
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | summarize Seen = dcount(Name) by ClusterName, ServiceName
      | project ClusterName, ServiceName, Seen;
      let DaemonSets = KubePodInventory
      | where Namespace == "argocd"
      | where TimeGenerated > ago(1d)
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where ControllerKind == "DaemonSet"
      | distinct ClusterName, DaemonSetName = ControllerName;
      let ActiveDaemonPods = KubePodInventory
      | where TimeGenerated > ago(15m)
      | where Namespace == "argocd"
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where ControllerKind == "DaemonSet"
      | summarize SeenPods = dcount(Name) by ClusterName, DaemonSetName = ControllerName
      | project ClusterName, DaemonSetName, SeenPods;
      let DaemonSetAbsence = DaemonSets
      | join kind=leftouter ActiveDaemonPods on ClusterName, DaemonSetName
      | extend SeenPods = coalesce(SeenPods, 0)
      | where SeenPods == 0 or isempty(SeenPods)
      | project ClusterName, ServiceName = DaemonSetName, Reason = strcat("ABSENCE: No DaemonSet pods seen");
      let Unresponsive = KubePodInventory
      | where TimeGenerated > ago(15m)
      | where Namespace == "argocd"
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | summarize
        arg_max(TimeGenerated, *),
        MaxPodRestarts = max(PodRestartCount),
        MaxContainerRestarts = max(ContainerRestartCount)
        by ClusterName, PodName = Name, ServiceName
      | where tolower(tostring(PodStatus)) !in ("running","succeeded")
        or MaxPodRestarts > 2
        or MaxContainerRestarts > 2
      | project ClusterName, ServiceName, Reason = strcat(
        "UNRESPONSIVE/RESTARTING: pod=", PodName,
        "; status=", PodStatus,
        "; pod restarts=", tostring(MaxPodRestarts),
        "; container restarts=", tostring(MaxContainerRestarts)
      );
      let Churn = KubePodInventory
      | where Namespace == 'argocd'
      | where TimeGenerated > ago(15m)
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where isnotempty(ServiceName)
      | where ControllerKind != "DaemonSet"
      | summarize
        UniquePodsCreated = dcount(Name),
        PodNames = make_set(Name),
        FirstSeen = min(TimeGenerated),
        LastSeen = max(TimeGenerated)
        by ClusterName, ServiceName
      | where UniquePodsCreated > 3
      | project ClusterName, ServiceName, Reason = strcat('CHURN: UniquePodsCreated=', UniquePodsCreated, '; Pods=', PodNames);
      union
      (
        ExpectedServices
        | join kind=leftouter ActiveServices on ClusterName, ServiceName
        | extend Seen = coalesce(Seen, 0)
        | where Seen == 0 or isempty(Seen)
        | project ClusterName, ServiceName, Reason = "ABSENCE: No service pods seen"
      ),
      Unresponsive,
      Churn,
      DaemonSetAbsence
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Drift Detection
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "deployed_drift-detection" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "ArgoCd Drift Detection"
  description             = "NIST CONTROL: CM-3, CM-5, and CM-6\nAlert when deployed resources drift from Git-defined config"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
    let ManualChangesByHuman = AKSAudit
    | where TimeGenerated > ago(15m)
    | where Stage == "ResponseComplete"
    | where Verb has_any ("update", "patch")
    | extend Actor = tostring(todynamic(User)['username'])
    | where isnotempty(Actor) and Actor contains "@"
    | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
    | project ChangeTime = TimeGenerated, ClusterName, Actor;

    let AutoSyncFromDrift = ContainerLogV2
    | where TimeGenerated > ago(15m)
    | where ContainerName == "application-controller"
    | where LogMessage has "Initiated automated sync"
    | parse LogMessage with * "application=" application " " *
    | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
    | project SyncTime = TimeGenerated, ClusterName, Application = application;

    ManualChangesByHuman
    | join kind=inner (AutoSyncFromDrift) on ClusterName
    | where SyncTime between (ChangeTime .. (ChangeTime + 5m))
    | project EventTime = SyncTime, ClusterName, Actor, Application, Message = strcat("Argo CD auto-sync was triggered for application '", Application, "' on cluster '", ClusterName, "' due to a recent manual change by user '", Actor, "'.")
    | order by EventTime desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### ArgoCD Unauthorized Resource Access
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "argocd_unauthorized_resource_access" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "ArgoCD Unauthorized Resource Access"
  description             = "NIST CONTROL: IR-6\nAlert on attempted access to unauthorized Git repositories"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1

    query = <<-QUERY
    ContainerLogV2
    | where TimeGenerated > ago(15m)
    | where tolower(PodNamespace) == "argocd"
    | where PodName has "argocd-repo-server"
    | where LogMessage has "grpc.code=Unknown"
    | where LogMessage has_any (
        "not a valid chart repository",
        "cannot be reached"
    )
    | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
    | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage
    | order by TimeGenerated desc
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}
