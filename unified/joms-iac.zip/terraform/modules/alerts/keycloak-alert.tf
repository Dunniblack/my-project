#### After Hours Login
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "keycloak_after_hours_login" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Keycloak After Hours Login"
  description             = "NIST CONTROL: AU-6\nAlert when admin access is identified at abnormal times (UTC: 2200 - 1000)"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    # Find In ContainerLogV2
    # Find in ContainerLogV2 to search for a specific value in the ContainerLogV2 table.
    # Note that this query requires updating the <SearchValue> parameter to produce results
    # This query requires a parameter to run. Enter value in SearchValue to find in table.
    query = <<-QUERY
			ContainerLogV2
			| where tolower(PodNamespace) == "auth"
			| where LogMessage has "LOGIN"
			| extend
					username  = extract(@"username\s*=\s*""([^""]+)""", 1, tostring(LogMessage)),
					realmId   = extract(@"realmId\s*=\s*""([^""]+)""", 1, tostring(LogMessage)),
					clientId  = extract(@"clientId\s*=\s*""([^""]+)""", 1, tostring(LogMessage)),
					email     = extract(@"email\s*=\s*""([^""]+)""", 1, tostring(LogMessage))
			| extend hour = datetime_part("hour", TimeGenerated)
			| where hour >= 22 or hour < 10   // Off-hours filter
			| extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
			| project TimeGenerated, ClusterName, PodNamespace, PodName, username, realmId, clientId, email, LogMessage
			| order by TimeGenerated desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}


#### Log Forwarding Failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "keycloak_log_forwarding_failure" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Keycloak Audit Log Forwarding Failure"
  description             = "NIST CONTROL: AU-2, AU-12\nAlert when Keycloak fails to forward logs to centralized log systems"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
			ContainerLogV2
			| where TimeGenerated > ago(5m)
			| where PodNamespace == "auth"
			| summarize by PodName = PodName
			| join kind=rightanti (
				KubePodInventory
				| where TimeGenerated > ago(1h)
				| where ContainerStatus == "Running"
				| summarize MaxRestarts = max(PodRestartCount) by PodName = InstanceName, ClusterId
			) on PodName
			| where MaxRestarts == 0
			| project ClusterId, PodName, MaxRestarts
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}


#### Disabled User Attempted Login
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "keycloak_disabled_user_attempted_login" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Keycloak Disabled User Attempted Login"
  description             = "NIST CONTROL: IR-6\nAlert when a disabled/deleted user tries to authenticate"
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 3
    query                   = <<-QUERY
			ContainerLogV2
			| where TimeGenerated > ago(15m)
			| where tolower(PodNamespace) == "auth"
			| where PodName has "keycloak-"
			| where LogMessage has_any('error="user_disabled"', 'error="user_not_found"')
			| extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
			| project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage
			| order by TimeGenerated desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}


#### Excessive Failed Logins
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "keycloak_excessive_failed_logins" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Keycloak Excessive Failed Logins"
  description             = "NIST CONTROL: AC-7\nAlert on repeated failed login attempts for users or clients"
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 3
    # Find In ContainerLogV2
    # Find in ContainerLogV2 to search for a specific value in the ContainerLogV2 table.
    # Note that this query requires updating the <SearchValue> parameter to produce results
    # This query requires a parameter to run. Enter value in SearchValue to find in table.
    query = <<-QUERY
			ContainerLogV2
			| where TimeGenerated > ago(5m)
			| extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
			| where PodNamespace == "auth"
			| where LogMessage has_any ("invalid_user_credentials", "USER_DISABLED_BY_TEMPORARY_LOCKOUT")
			| extend username = extract(@"username=""([^""]+)""", 1, tostring(LogMessage))
			| extend userId   = extract(@"userId=""([^""]+)""", 1, tostring(LogMessage))
			| extend reason   = extract(@"reason=""([^""]+)""", 1, tostring(LogMessage))
			| project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage, username, userId, reason
			| order by TimeGenerated desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}


#### Realm Admin Assigned
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "keycloak_realm_admin_assigned" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Keycloak New Realm Admin Assigned"
  description             = "NIST CONTROL: AC-2, AC-6\nAlert on the assignment of realm-admin or higher roles to any user"
  severity                = 0
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    # Find In ContainerLogV2
    # Find in ContainerLogV2 to search for a specific value in the ContainerLogV2 table.
    # Note that this query requires updating the <SearchValue> parameter to produce results
    # This query requires a parameter to run. Enter value in SearchValue to find in table.
    query = <<-QUERY
	ContainerLogV2
	| where PodNamespace == "auth"
	| where LogMessage has "REALM_ROLE_MAPPING"
	| where LogMessage has_any("realm-admin", "admin")
	| where not(LogMessage has_any("svc_bootstrap", "init_admin"))
	| extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
	| project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}


#### Realm Settings Changed
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "keycloak_realm_settings_changed" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Keycloak Realm Settings Changed"
  description             = "NIST CONTROL: CM-6\nAlert on change to login policies, session timeouts, password policies (This shows up as a Realm Update)"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    # Find In ContainerLogV2
    # Find in ContainerLogV2 to search for a specific value in the ContainerLogV2 table.
    # Note that this query requires updating the <SearchValue> parameter to produce results
    # This query requires a parameter to run. Enter value in SearchValue to find in table.
    query = <<-QUERY
			ContainerLogV2
      | where PodNamespace == "auth"
      | where LogMessage has_any (
          'operationType="UPDATE"',
          'operationType="CREATE"',
          'operationType="DELETE"'
      )
      | where LogMessage has 'resourceType="REALM"'
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage
      | order by TimeGenerated desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Unavailable or Unresponsive
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "keycloak_unavailable_or_unresponsive" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Keycloak Unavailable or Unresponsive"
  description             = "NIST CONTROL: SI-4\nDetect when Keycloak goes offline or stops responding to authentication requests"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
	(KubePodInventory
		| extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
		| where Namespace == "auth"
		| summarize MaxRestarts = max(PodRestartCount) by ClusterName, PodNamespace = Namespace, PodName = Name
	)
	| join kind=leftanti (
		ContainerLogV2
		| where TimeGenerated > ago(2m)
		| where PodNamespace == "auth"
		| where LogMessage has "Keycloak"
		| summarize LastSeen = max(TimeGenerated) by PodName
	) on PodName
	| where MaxRestarts == 0
	| project ClusterName, PodNamespace, PodName, MaxRestarts
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}
