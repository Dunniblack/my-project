#### Unauthorized Backup or Restore Attempt
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "velero_unauthorized_backup_or_restore_attempt" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Unauthorized Backup or Restore Attempt"
  description             = "NIST CONTROL: AC-2, AC-6, AC-7\nAlert when an unauthorized user attempts to access Velero CRDs or secrets, or has multiple failed attempts"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      AKSAudit
      | where ResponseStatus has_any ("401", "403") and
        ObjectRef.namespace has "velero" and
        ObjectRef.resource in ("backups", "restores", "backupstoragelocations", "volumesnapshotcontents")
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | extend PodNamespace = ObjectRef.namespace
      | project TimeGenerated, ClusterName, PodNamespace, PodName, AuditId, Stage, Verb, User, UserAgent, SourceIps, ObjectRef, ResponseStatus
      | order by TimeGenerated desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Audit Log Forwarding Failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "audit_log_forwarding_failure" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Velero Audit Log Forwarding Failure"
  description             = "NIST CONTROL: AU-2, AU-12\nAlert when Velero fails to forward logs to centralized log systems or SIEM ( 1 minute)"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      let LoggingDelayTolerance = 3m;
      let ExpectedPods = ContainerLogV2
      | where PodNamespace == "velero"
      | where TimeGenerated > ago(1h)
      | distinct PodName;
      let ActivePods = ContainerLogV2
      | where PodNamespace == "velero"
      | where TimeGenerated > ago(LoggingDelayTolerance)
      | distinct PodName;
      let InactivePods = ExpectedPods
      | join kind=leftanti (ActivePods) on PodName;
      let UnhealthyPods = KubePodInventory
      | where Namespace == "velero"
      | where TimeGenerated > ago(5m)
      | where PodStatus !in ("Running", "Succeeded") or ContainerRestartCount > 0
      | distinct Name;
      let ProblematicPods = union InactivePods, (UnhealthyPods | project PodName = Name);
      ContainerLogV2
      | where PodNamespace == "velero"
      | where TimeGenerated > ago(1h)
      | where PodName in (ProblematicPods)
      | where LogSource == "stderr" and LogMessage has "restore" and (LogMessage has "failed" or LogMessage has "error")
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | summarize FailedPodCount = dcount(PodName), LastFailureTime = max(TimeGenerated) by ClusterName
      | project ClusterName, FailedPodCount, LastFailureTime
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Velero Restore Job Failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "velero_restore_job_failure" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Velero Restore Job Failure"
  description             = "NIST CONTROL: Au-6, SI-4\nAlert on failed restore operations"
  severity                = 2
  evaluation_frequency    = "PT1H"
  window_duration         = "PT1H"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      ContainerLogV2
      | where PodNamespace has "velero" or PodName has "velero"
      | extend ParsedLog = parse_json(LogMessage)
      | where tostring(ParsedLog.level) == "error"
      | where tostring(ParsedLog.msg) has "restore" and ParsedLog.msg has_any ("fail", "error", "unable")
      | where tostring(ParsedLog.msg) !has "An error occurred: the server could not find the requested resource"
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage = ParsedLog.msg
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Velero Backup Job Failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "velero_backup_job_failure" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Velero Backup Job Failure"
  description             = "NIST CONTROL: CP-6, CP-9\nAlert when a scheduled or manual backup fails"
  severity                = 2
  evaluation_frequency    = "PT1H"
  window_duration         = "PT1H"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
       ContainerLogV2
      | where PodNamespace has "velero" or PodName has "velero"
      | extend ParsedLog = parse_json(LogMessage)
      | where tostring(ParsedLog.level) == "error"
      | where tostring(ParsedLog.msg) has_any ("backup", "schedule") and ParsedLog.msg has_any ("fail", "error", "unable")
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage = ParsedLog.msg
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Velero Stale Backup Alert
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "velero_stale_backup" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Velero Stale Backup"
  description             = "NIST CONTROL: CP-9, AU-6\nAlert if backups have not run in X hours/days"
  severity                = 2
  evaluation_frequency    = "PT1H"
  window_duration         = "PT6H"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  # Disable this alert in WDSF and C1 Zone B
  enabled = (
    (
      var.enclave == "c1" &&
      contains(["test", "prod"], lower(var.stage))
    ) ?
    true :
    false
  )

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      let threshold = 24h;
      let lookback = threshold + 1d;
      union ContainerLogV2, AKSAudit
      | where TimeGenerated > ago(lookback)
      | where
      (
      (PodNamespace has "velero" or PodName has "velero") and
      LogMessage has "backup" and
      (LogMessage has "completed successfully" or LogMessage has "phase=Completed")
      )
      or
      (
      PodName has "velero" and
      isnotempty(RequestObject) and
      tostring(parse_json(tostring(RequestObject)).verb) == "create" and
      tostring(parse_json(tostring(RequestObject)).requestObject.kind) == "Backup"
      )
      | summarize LastSuccessfulBackup = max(TimeGenerated)
      | where LastSuccessfulBackup < ago(threshold) or isempty(LastSuccessfulBackup)
      | project AlertName = "StaleVeleroBackup", AlertDescription = strcat("No successful Velero backup has been detected in the last ", threshold, ". This violates NIST controls CP-9 and AU-6."), LastSuccessfulBackup, Threshold = threshold
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Unavailable or Unresponsive
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "velero_unavailable_or_unresponsive" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Velero Unavailable or Unresponsive"
  description             = "NIST CONTROL: SI-4\nDetect when velero goes offline or stops responding to authentication requests"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      union
      (
      (
      KubePodInventory
      | where Namespace == 'velero'
      | where TimeGenerated > ago(24h)
      | where isnotempty(ServiceName)
      | distinct ClusterName, ServiceName
      )
      | join kind=leftouter (
      KubePodInventory
      | where TimeGenerated > ago(15m)
      | where Namespace == "velero"
      | summarize Seen = dcount(Name) by ClusterName, ServiceName
      ) on ClusterName, ServiceName
      | extend Seen = coalesce(Seen, 0)
      | where Seen == 0
      | project ClusterName, ServiceName, Reason = strcat('ABSENCE: No Velero pods seen in the last 15m')
      ),
      (
      KubePodInventory
      | where Namespace == "velero"
      | where TimeGenerated > ago(15m)
      | summarize
        arg_max(TimeGenerated, *),
        FirstSeenInWindow = min(TimeGenerated)
        by ClusterName, PodName = Name, ServiceName
      | where now() - FirstSeenInWindow > 3m
      | where tolower(tostring(PodStatus)) !in ("running", "succeeded")
        or PodRestartCount > 2
        or ContainerRestartCount > 2
      | project ClusterName, ServiceName, Reason = strcat(
        "UNRESPONSIVE/RESTARTING: pod=", PodName,
        "; status=", PodStatus,
        "; pod_restarts=", tostring(PodRestartCount),
        "; container_restarts=", tostring(ContainerRestartCount)
      )
      ),
      (
      KubePodInventory
      | where Namespace == 'velero'
      | where TimeGenerated > ago(15m)
      | where isnotempty(ServiceName)
      | summarize
        UniquePodsCreated = dcount(Name),
        PodNames = make_set(Name)
        by ClusterName, ServiceName
      | where UniquePodsCreated > 3
      | project ClusterName, ServiceName, Reason = strcat('CHURN: ', UniquePodsCreated, ' unique pods created in the last 15m. Pods: ', PodNames)
      )
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }
}
