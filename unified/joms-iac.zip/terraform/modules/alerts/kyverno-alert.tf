#### Log Forwarding Failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kyverno_log_forwarding_failure" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Kyverno Audit Log Forwarding Failure"
  description             = "NIST CONTROL: AU-2, AU-12\nAlert when Kyverno fails to forward logs to centralized log systems"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      let ExpectedPods = ContainerLogV2
          | where PodNamespace == "kyverno"
          | where TimeGenerated > ago(1h)
          | distinct PodName;
      let ActivePods = ContainerLogV2
          | where PodNamespace == "kyverno"
          | where TimeGenerated > ago(5m)
          | distinct PodName;
      let InactivePods = ExpectedPods
          | join kind=leftanti (ActivePods) on PodName;
      ContainerLogV2
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where TimeGenerated > ago(1h)
      | where PodNamespace == "kyverno"
      | join kind=inner (InactivePods) on PodName
      | summarize LastSeen = max(TimeGenerated) by ClusterName, PodNamespace, PodName, ContainerName
      | project LastSeen, ClusterName, PodNamespace, PodName, ContainerName
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Privileged Pod Creation Attempted
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kyverno_privileged_pod_creation_attempted" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Kyverno Privileged Pod Creation Attempted"
  description             = "NIST CONTROL: AU-2, AU-12\nAlert when a user tries to create a privileged pod"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      KubeEvents
      | where Reason == "PolicyViolation"
      | where Message has "disallow-privileged-containers"
      | project TimeGenerated, ClusterName, Namespace, Name, Message
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}
#### Unavailable or Unresponsive
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "kyverno_unavailable_or_unresponsive" {
  name                    = "Kyverno Unavailable or Unresponsive"
  description             = "NIST CONTROL: SI-4\nDetect when Kyverno goes offline or stops responding to authentication requests using KubePodInventory."
  resource_group_name     = var.global_resource_group
  location                = var.location
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT15M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1

    query = <<-KQL
      // SI-4: Detect when Kyverno goes offline or stops responding to authentication requests or restarting excessively (>2) (KubePodInventory only)
      union
      (
        // ABSENCE: no Kyvrno server/webhook pods seen in the lookback window
        KubePodInventory
        | where TimeGenerated > ago(15m)
        | where Namespace == "kyverno"
        // exclude short-lived jobs
        | where not(Name hasprefix "helm-operation-") and not(Name hasprefix "pull-")
          | summarize Seen = dcount(Name) by ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
        | where Seen == 0
        | project ClusterName, Reason = "ABSENCE: No Kyverno pods observed"
      ),
      (
        // UNRESPONSIVE / EXCESSIVE RESTARTS: not Running/Succeeded OR restarts > 2
        KubePodInventory
        | where TimeGenerated > ago(15m)
        | where Namespace == "kyverno"
        // exclude short-lived jobs
        | where not(Name hasprefix "helm-operation-") and not(Name hasprefix "pull-")
        | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
        | summarize arg_max(TimeGenerated, *),
                    MaxPodRestarts       = max(PodRestartCount),
                    MaxContainerRestarts = max(ContainerRestartCount)
            by ClusterName, PodName = Name
        | extend PodStatus = tolower(tostring(PodStatus))
        | where PodStatus !in ("running","succeeded")
              or MaxPodRestarts > 2
              or MaxContainerRestarts > 2
        | project TimeGenerated, ClusterName, Reason = strcat(
            "UNRESPONSIVE/RESTARTING: pod=", PodName,
            "; status=", PodStatus,
            "; pod restarts=", tostring(MaxPodRestarts),
            "; container restarts=", tostring(MaxContainerRestarts)
          )
      )
    KQL

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert", Control = "SI-4" }
  )
}

