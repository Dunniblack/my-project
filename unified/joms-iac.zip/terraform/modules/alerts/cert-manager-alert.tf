### Log Forwarding Failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "cert_manager_audit_log_forwarding_failure" {
  resource_group_name     = var.global_resource_group
  location                = var.location
  name                    = "Cert Manager Audit Log Forwarding Failure"
  description             = "NIST CONTROL: AU-2, AU-12\nAlert when Cert Manager fails to forward logs to centralized log systems or SIEM (1 minute)"
  severity                = 1      # High severity, matching log forwarding failure alert
  evaluation_frequency    = "PT1M" # As per ticket requirement (1 minute)
  window_duration         = "PT1M" # As per ticket requirement (1 minute)
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1

    query = <<-QUERY
	    let ExpectedPods = ContainerLogV2
        | where PodNamespace == "cert-manager"
        | where TimeGenerated > ago(1h)
        | distinct PodName;
      let ActivePods = ContainerLogV2
        | where PodNamespace == "cert-manager"
        | where TimeGenerated > ago(1m)
        | distinct PodName;
      let InactivePods = ExpectedPods
        | join kind=leftanti (ActivePods) on PodName;
      ContainerLogV2
        | where PodNamespace == "cert-manager"
        | where TimeGenerated > ago(1h)
        | where PodName in (InactivePods)
        | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
        | summarize LastSeen = max(TimeGenerated) by ClusterName, PodNamespace, PodName, ContainerName
        | project LastSeen, ClusterName, PodNamespace, PodName, ContainerName
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

### Detect Unapproved Issuer
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "cert_manager_detect_unapproved_issuer" {
  resource_group_name     = var.global_resource_group
  location                = var.location
  name                    = "Cert Manager Detect Unapproved issuer"
  description             = "CONTROL: SC-17\nDetect use of non-approved issuers/clusterissuers in cert-manager"
  severity                = 1 # High severity, matching log forwarding failure alert
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1

    query = <<-QUERY
      let approvedIssuers = dynamic(["ca-issuer", "redis-ca-issuer", "core-app-rancher", "selfsigned-issuer"]);

      ContainerLogV2
      | where TimeGenerated > ago(30m)
      | where PodNamespace == "cert-manager"
      | where LogMessage has "Setting lastTransitionTime for" and (LogMessage has "Issuer condition" or LogMessage has "ClusterIssuer condition")
      | parse LogMessage with * 'issuer="' issuer '"' *
      | extend issuerType = case(
        LogMessage has "ClusterIssuer", "ClusterIssuer",
        LogMessage has "Issuer", "Issuer",
        "Unknown"
      )
      | where isnotempty(issuer) and issuer !in (approvedIssuers)
      | extend ClusterName = extract("/managedclusters/([^/]+)", 1, _ResourceId)
      | project TimeGenerated, ClusterName, issuerType, issuer, LogMessage
      | order by TimeGenerated desc
    QUERY
    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

### Detect Unapproved Domain
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "cert_manager_detect_unapproved_domain" {
  resource_group_name     = var.global_resource_group
  location                = var.location
  name                    = "Cert Manager Detect Unapproved domain"
  description             = "CONTROL: SC-17\nDetect use of non-approved domain in cert-manager"
  severity                = 1 # High severity
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1

    query = <<-QUERY
      let approvedCertificates = dynamic(["redis-cert", "redis-selfsigned-ca"]);

      ContainerLogV2
      | where TimeGenerated > ago(30m)
      | where PodNamespace == "cert-manager"
      | where LogMessage has "Setting lastTransitionTime for Certificate condition"
      | parse LogMessage with * 'certificate="' certificateName '"' *
      | where isnotempty(certificateName) and certificateName !in (approvedCertificates)
      | extend ClusterName = extract("/managedclusters/([^/]+)", 1, _ResourceId)
      | project TimeGenerated, ClusterName, certificateName, LogMessage
      | order by TimeGenerated desc
    QUERY
    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Unavailable or Unresponsive
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "cert_manager_unavailable_or_unresponsive" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Cert Manager Unavailable or Unresponsive"
  description             = "NIST CONTROL: SI-4\nDetect when Cert Manager goes offline or stops responding to requests"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      let Lookback = 30m;
      let ExpectedServices = KubePodInventory
        | where Namespace == 'cert-manager'
        | where TimeGenerated > ago(1d)
        | where isnotempty(ServiceName)
        | distinct ClusterName, ServiceName;
      let ActiveServices = KubePodInventory
        | where TimeGenerated > Lookback
        | where Namespace == "cert-manager"
        | summarize Seen = dcount(Name) by ClusterName, ServiceName;
      union
      (
        ExpectedServices
        | join kind=leftouter ActiveServices on ClusterName, ServiceName
        | extend Seen = coalesce(Seen, 0)
        | where Seen == 0 or isempty(Seen)
        | project ClusterName, ServiceName, Reason = strcat('ABSENCE: No service pods seen in the last ', tostring(Lookback))
      ),
      (
        KubePodInventory
        | where TimeGenerated > Lookback
        | where Namespace == "cert-manager"
        | summarize
          arg_max(TimeGenerated, *),
          MaxPodRestarts = max(PodRestartCount),
          MaxContainerRestarts = max(ContainerRestartCount)
          by ClusterName, PodName = Name
        | where tostring(PodStatus) !in ("Running","Succeeded")
          or MaxPodRestarts > 3
          or MaxContainerRestarts > 3
        | project ClusterName, ServiceName, Reason = strcat(
          "UNRESPONSIVE/RESTARTING: pod=", PodName,
          "; status=", PodStatus,
          "; pod_restarts=", tostring(MaxPodRestarts),
          "; container_restarts=", tostring(MaxContainerRestarts)
          )
      ),
      (
          KubePodInventory
          | where Namespace == 'cert-manager'
          | where TimeGenerated > Lookback
          | where isnotempty(ServiceName)
          | summarize
            UniquePodsCreated = dcount(Name),
            PodNames = make_set(Name)
            by ClusterName, ServiceName
          | where UniquePodsCreated > 3
          | project ClusterName, ServiceName, Reason = strcat('CHURN: ', tostring(UniquePodsCreated), ' unique pods created in ', tostring(Lookback), '. Pods=', tostring(PodNames))
      )
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert", Control = "SI-4" }
  )
}
