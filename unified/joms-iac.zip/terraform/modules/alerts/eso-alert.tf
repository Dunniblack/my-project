#### Log Forwarding Failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "eso_log_forwarding_failure" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "External Secrets Operator (ESO) Audit Log Forwarding Failure"
  description             = "NIST CONTROL: AU-2, AU-12\nAlert when ESO fails to forward logs to centralized log systems"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      let TargetNamespace = "external-secrets";
      let ExpectedPods = ContainerLogV2
          | where PodNamespace == TargetNamespace
          | where TimeGenerated > ago(1h)
          | distinct PodName;
      let ActivePods = ContainerLogV2
          | where PodNamespace == TargetNamespace
          | where TimeGenerated > ago(5m)
          | distinct PodName;
      let InactivePods = ExpectedPods
          | join kind=leftanti (ActivePods) on PodName;
      ContainerLogV2
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where TimeGenerated > ago(1h)
      | where PodNamespace == TargetNamespace
      | join kind=inner (InactivePods) on PodName
      | summarize LastSeen = max(TimeGenerated) by ClusterName, PodNamespace, PodName, ContainerName
      | project LastSeen, ClusterName, PodNamespace, PodName, ContainerName
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }
}

#### Excessive Secret Access Failures
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "eso_excessive_secret_access_failure" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                 = "External Secrets Operator (ESO) Audit Excessive ESO Secret Access Failures"
  description          = "NIST CONTROL: AC-7, AU-12\nAlert on repeated failed sync attempts or access denials"
  severity             = 1
  evaluation_frequency = "PT5M"
  # ESO appears to attempt to sync approximately every 15 minutes - 30 minutes should cover multiple sync attempts
  window_duration         = "PT30M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 3
    query                   = <<-QUERY
      ContainerLogV2
      | where PodNamespace == "external-secrets"
          and ContainerName == "external-secrets"
          and LogLevel == "error"
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId),
          MessageDetails = parse_json(LogMessage)
      | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage
      | order by TimeGenerated desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }
}

#### Unauthorized ESO Secret Access
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "eso_unauthorized_secret_access" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "External Secrets Operator (ESO) Audit Unauthorized ESO Secret Access"
  description             = "NIST CONTROL: AU-2, AU-6\nAlert on unauthorized access attempts"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      AKSAudit
      | where RequestUri matches regex "/apis/external-secrets.io/.*/externalsecrets"
          and ResponseStatus has_any ("401", "403")
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | extend ObjectDetails = parse_json(ObjectRef)
      | extend PodNamespace = ObjectDetails.namespace
      | project TimeGenerated, ClusterName, PodNamespace, PodName, AuditId, Stage, RequestUri, Verb, User, UserAgent, SourceIps, ObjectRef, ResponseStatus
      | order by TimeGenerated desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }
}

#### Secret Access Spike
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "secret_access_spike" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "External Secrets Operator (ESO) Audit Surge in Secret Fetches"
  description             = "NIST CONTROL: IR-6\nIncident Reporting"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
    let timeWindow = 5m;
    let threshold = 30;
    AKSAudit
    | where RequestUri has "/apis/external-secrets.io"
        and (Verb == 'watch' or Verb == 'list' or Verb == "get")
    | extend
        ObjectDetails = parse_json(ObjectRef),
        UserDetails = parse_json(User)
    | extend
        Resource = ObjectDetails.resource,
        PodNamespace = ObjectDetails.namespace,
        SecretName = ObjectDetails.name,
        Username = tostring(UserDetails.username)
    | where Resource == "externalsecrets"
    | where TimeGenerated >= ago(timeWindow)
    | summarize
        RequestCount = count() by bin(TimeGenerated, timeWindow),
        Username
    | where RequestCount > threshold;
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }
}

#### Unavailable or Unresponsive
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "eso_unavailable_or_unresponsive" {
  name                    = "ESO Unavailable or Unresponsive"
  description             = "NIST CONTROL: SI-4\nDetect when ESO goes offline or stops responding to authentication requests using KubePodInventory."
  resource_group_name     = var.global_resource_group
  location                = var.location
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT15M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1

    query = <<-QUERY
    KubePodInventory
    | where TimeGenerated > ago(8m)
    | where Namespace == "external-secrets"
    | summarize arg_max(TimeGenerated, *) by ClusterName, Namespace, Name
    | project ClusterName, Namespace, PodName=Name, PodStatus, Reason=PodStatus, LastSeen=TimeGenerated
    | join kind=fullouter (
        KubeEvents
        | where TimeGenerated > ago(8m)
        | where Namespace == "external-secrets"
        | where Reason has_any ("Failed", "Unhealthy", "BackOff", "CrashLoopBackOff", "Error")
              or Message has_any ("Failed", "Unhealthy", "BackOff", "CrashLoopBackOff", "Error")
        | project ClusterName, Namespace, PodName=Name, EventReason=Reason, EventMessage=Message, EventTime=TimeGenerated
    ) on ClusterName, Namespace, PodName
    | project ClusterName, Namespace, PodName,
              PodStatus, Reason, LastSeen,
              EventReason, EventMessage, EventTime
    | where PodStatus !in ("Running", "Succeeded") or isnotempty(EventReason)
    | order by coalesce(LastSeen, EventTime) desc
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert", Control = "SI-4" }
  )
}
