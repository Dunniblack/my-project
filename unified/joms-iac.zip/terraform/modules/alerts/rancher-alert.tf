# Rancher Alert Rules – Mapped to NIST Controls

########################################
# AC-2, AC-6 – New Admin User Created
########################################
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "rancher_admin_role_assigned" {
  name                    = "Rancher New Admin Role Assigned"
  description             = "NIST CONTROL: AC-2, AC-6\nAlert when a new user is granted admin role in Rancher"
  resource_group_name     = var.global_resource_group
  location                = var.location
  severity                = 0
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      ContainerLogV2
      | where PodNamespace == "cattle-system"
      | where LogMessage has "Creating clusterRoleBinding"
      | where LogMessage has "for user"
      | where LogMessage has_any ("cattle-globalrole-admin", "cluster-admin", "admin")
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage
      | sort by TimeGenerated desc
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

########################################
# AC-7 – Excessive Failed Logins
########################################
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "rancher_excessive_failed_logins" {
  name                    = "Rancher Excessive Failed Logins"
  description             = "NIST CONTROL: AC-7\nDetect brute-force login attempts or abuse of authentication"
  resource_group_name     = var.global_resource_group
  location                = var.location
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 3
    query                   = <<-QUERY
      ContainerLogV2
      | where PodNamespace == "cattle-system"
      | extend LogJson        = parse_json(LogMessage)
      | extend RequestURI     = tostring(LogJson.requestURI)
      | extend Method         = tostring(LogJson.method)
      | extend UserName       = tostring(LogJson.user.name)
      | extend Groups         = tostring(LogJson.user.group)
      | extend ExtraUsername  = tostring(LogJson.user.extra.username[0])
      | extend XApiAuth       = tostring(coalesce(LogJson.responseHeader.["X-Api-Cattle-Auth"][0], "unknown"))
      | where RequestURI contains "/v3-public/localProviders/local?action=login"
      | where Method == "POST"
      | where XApiAuth == "false" or UserName == "system:cattle:error" or Groups contains "system:unauthenticated"
      | extend ClusterName    = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, RequestURI, Method, ExtraUsername, UserName, Groups, XApiAuth, LogMessage
      | sort by TimeGenerated desc
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}
########################################
# AU-2, AU-12 – Log Forwarding Failure
########################################
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "rancher_log_forwarding_failure" {
  name                    = "Rancher Audit Log Forwarding Failure"
  description             = "NIST CONTROL: AU-2, AU-12\nAlert when Rancher fails to forward logs to centralized log systems"
  resource_group_name     = var.global_resource_group
  location                = var.location
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      let ExpectedPods = ContainerLogV2
        | where PodNamespace == "cattle-system"
        | where TimeGenerated > ago(1h)
        | distinct PodName;
      let ActivePods = ContainerLogV2
        | where PodNamespace == "cattle-system"
        | where TimeGenerated > ago(5m)
        | distinct PodName;
      ExpectedPods
      | join kind=leftanti (ActivePods) on PodName
      | join kind=inner (
          ContainerLogV2
          | where PodNamespace == "cattle-system"
          | where TimeGenerated > ago(1h)
        ) on PodName
      | summarize LastSeen = max(TimeGenerated) by PodNamespace, PodName, ContainerName
      | project LastSeen, PodNamespace, PodName, ContainerName
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

########################################
# AU-6 – After Hours Login
########################################
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "rancher_after_hours_login" {
  name                    = "Rancher After Hours Login"
  description             = "NIST CONTROL: AU-6\nAlert when admin access is identified at abnormal times (UTC: 2200 - 1000)"
  resource_group_name     = var.global_resource_group
  location                = var.location
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      let TargetNamespace = "cattle-system";
      ContainerLogV2
      | where PodNamespace == TargetNamespace
      | extend LogJson = parse_json(LogMessage)
      | extend RequestURI = tostring(LogJson.requestURI)
      | extend Method = tostring(LogJson.method)
      | extend ResponseCode = tostring(LogJson.responseCode)
      | extend User = tostring(LogJson.user.name)
      | extend Groups = tostring(LogJson.user.group)
      | extend hour = datetime_part("hour", TimeGenerated)
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where RequestURI has "/v3-public/keyCloakOIDCProviders" and Method == "POST"
      | where hour >= 22 or hour < 10
      | project TimeGenerated, ClusterName, hour, PodNamespace, PodName, ContainerName, RequestURI, Method, ResponseCode, User, Groups, LogMessage
      | sort by TimeGenerated desc
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

########################################
# IR-6 – Unapproved Cluster Access Attempt
########################################
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "rancher_unapproved_cluster_access_attempt" {
  name                    = "Rancher Unapproved Cluster Access Attempt"
  description             = "NIST CONTROL: IR-6\nAlert if user within Rancher tries to access a restricted cluster or namespace"
  resource_group_name     = var.global_resource_group
  location                = var.location
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      ContainerLogV2
      | where TimeGenerated > ago(15m)
      | where PodNamespace == "cattle-system"
      | where ContainerName == "rancher-audit-log"
      | extend Parsed = parse_json(LogMessage)
      | extend Method       = tolower(tostring(coalesce(Parsed.method, Parsed.verb))),
              RequestURI   = tolower(tostring(coalesce(Parsed.requestURI, Parsed.requestUri, Parsed.uri))),
              UserName     = tostring(coalesce(Parsed.user.username,
                                                Parsed.user.name,
                                                Parsed.user["extra"]["username"][0])),
              ResponseCode = tostring(coalesce(Parsed.responseCode,
                                                Parsed.status,
                                                Parsed.code)),
              ClusterName  = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where ResponseCode in ("401","403")
      | where RequestURI has_any (
            "/v3/clusters/",
            "/v3/projects/",
            "/v3/clusterroletemplates",
            "/v3/roletemplates",
            "/v3/clusterroletemplatebindings",
            "/v3/projectroletemplatebindings",
            "/k8s/clusters/"         // includes proxied k8s API access to namespaces/resources
        )
      | where not(RequestURI has "/healthz")
      | project TimeGenerated, ClusterName, Method, RequestURI, UserName, ResponseCode
      | sort by TimeGenerated desc
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}
########################################
# CM-3, CM-5 – Unauthorized Cluster Config Change
########################################
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "rancher_unauthorized_cluster_config_change" {
  name                    = "Unauthorized Cluster Config Change"
  description             = "NIST CONTROL: CM-3, CM-5\nDetect if any Rancher-managed cluster config changes outside GitOps or UI"
  resource_group_name     = var.global_resource_group
  location                = var.location
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      union isfuzzy=true AKSAuditAdmin, AKSAudit, KubeAuditAdmin
      | where Verb in~ ("PATCH","POST","DELETE","PUT","CREATE")
      | where iif(isnotempty(Stage), Stage =~ "ResponseComplete", true)
      | extend UserJson=parse_json(User), RespJson=parse_json(ResponseStatus), ObjRef=parse_json(ObjectRef)
      | extend UserName=tostring(coalesce(UserJson.username, User)), UA=tostring(UserAgent), Req=tostring(RequestUri), ResponseCode=toint(RespJson.code)
      | where isnull(ResponseCode) or (ResponseCode between (200 .. 399))
      | extend ClusterName=iif(isnotempty(_ResourceId) and _ResourceId has "/managedclusters/", extract(@"/managedclusters/([^/]+)", 1, _ResourceId), "unknown")
      | extend ResourceKind=tostring(ObjRef.resource), Namespace=tostring(ObjRef.namespace), ResourceName=tostring(ObjRef.name)
      | extend ResourceKind=iif(isempty(ResourceKind), tostring(extract(@"/(?:apis/[^/]+/v[^/]+|api/v[^/]+)/(?:namespaces/[^/]+/)?([^/]+)/", 1, Req)), ResourceKind)
      | extend Namespace=iif(isempty(Namespace), tostring(extract(@"/namespaces/([^/]+)/", 1, Req)), Namespace)
      | extend ResourceName=iif(isempty(ResourceName), tostring(extract(@"/[^/]+/([^/?]+)", 1, Req)), ResourceName)
      | extend IsServiceAccount = UserName startswith "system:serviceaccount:"
      | extend IsRancher = tolower(UA) has "rancher" or tolower(UserName) in~ (dynamic(["system:serviceaccount:cattle-system:rancher"]))
      | extend IsGitOps = tolower(UA) has_any (dynamic(["flux","argocd","gitops"])) or array_index_of(dynamic(["system:serviceaccount:flux-system:source-controller","system:serviceaccount:flux-system:kustomize-controller","system:serviceaccount:argocd:argocd-server","system:serviceaccount:argocd:argocd-application-controller"]), tolower(UserName)) != -1
      | where array_index_of(dynamic(["clusterroles","clusterrolebindings","roles","rolebindings","networkpolicies","ciliumnetworkpolicies","validatingwebhookconfigurations","mutatingwebhookconfigurations","customresourcedefinitions","podsecuritypolicies","constrainttemplates","clusterpolicies","policies"]), tolower(ResourceKind)) != -1
      | extend rk=tolower(ResourceKind), ns=tolower(Namespace), rn=tolower(ResourceName), reqL=tolower(Req)
      | where not( (ns in~ (dynamic(["cattle-fleet-system","cattle-provisioning-capi-system"])) and rk in~ (dynamic(["roles","rolebindings"])) and (rn hasprefix "helm-operation-" or rn hasprefix "helm-installer-")) )
      | where not( rk =~ "clusterrolebindings" and rn hasprefix "pod-impersonation-helm-op-" )
      | where not( reqL has "fieldmanager=helm" or reqL has "fieldmanager=helm-controller" or reqL has "fieldmanager=clusterrole-aggregation-controller" )
      | where not(reqL has "dryrun=all")
      | where not(tolower(UserName) in~ (dynamic(["aksservice"])))
      | where not(IsRancher or IsGitOps)
      | project TimeGenerated, ClusterName, Verb, ResourceKind, Namespace, ResourceName, RequestUri=Req, UserName, UserAgent=UA, ResponseCode, _ResourceId
      | sort by TimeGenerated desc
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

########################################
# CM-6 – Rancher Policy Drift
########################################
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "rancher_policy_drift_detected" {
  name                    = "Rancher Policy Drift Detected"
  description             = "NIST CONTROL: CM-6\nDetect deviation from baseline Kubernetes/Rancher security policies via Rancher audit logs"
  resource_group_name     = var.global_resource_group
  location                = var.location
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT15M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1

    query = <<-QUERY
      let SensitiveTerms = dynamic([
        "clusterpolicies","kyverno",
        "globalroles","rolebindings","clusterrolebinding",
        "networkpolicies",
        "ciliumnetworkpolicy","ciliumclusterwidenetworkpolicy","/apis/cilium.io/"
      ]);
      ContainerLogV2
      | where TimeGenerated > ago(15m)
      | where PodNamespace == "cattle-system" and ContainerName == "rancher-audit-log"
      | extend Parsed = parse_json(LogMessage)
      | extend Method = tolower(tostring(coalesce(Parsed.method, Parsed.verb))),
              URI    = tolower(tostring(coalesce(Parsed.requestURI, Parsed.requestUri, Parsed.uri))),
              Code   = tostring(coalesce(Parsed.responseCode, Parsed.status, Parsed.code)),
              User   = tostring(coalesce(Parsed.user.username, Parsed.user.name, Parsed.user["extra"]["username"][0])),
              ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where Method in ("post","put","patch","delete")
      | where isnotempty(URI) and URI has_any (SensitiveTerms)
      | summarize DriftWrites = count(),
                Changes = make_set(pack("Method",Method,"URI",URI,"User",coalesce(User,"unknown"),"ResponseCode",Code), 5)
        by bin(TimeGenerated, 15m), ClusterName
      | where DriftWrites > 0
      | mv-expand Changes
      | project TimeGenerated, ClusterName, DriftWrites,
                Method=tostring(Changes.Method),
                URI=tostring(Changes.URI),
                User=tostring(Changes.User),
                ResponseCode=tostring(Changes.ResponseCode)
      | order by TimeGenerated desc
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert", Control = "CM-6", App = "rancher" }
  )
}
#### Unavailable or Unresponsive
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "rancher_unavailable_or_unresponsive" {
  name                    = "Rancher Unavailable or Unresponsive"
  description             = "NIST CONTROL: SI-4\nAlert when Rancher is absent, not running, or restarting excessively (>2) using KubePodInventory."
  resource_group_name     = var.global_resource_group
  location                = var.location
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT15M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1

    query = <<-KQL
      // SI-4: Rancher absent, unresponsive, or restarting excessively (>2) (KubePodInventory only)
      union
      (
        // ABSENCE: no Rancher server/webhook pods seen in the lookback window
        KubePodInventory
        | where TimeGenerated > ago(15m)
        | where Namespace == "cattle-system"
        // exclude short-lived jobs
        | where not(Name hasprefix "helm-operation-") and not(Name hasprefix "pull-")
        // only core Rancher components
        | where Name hasprefix "core-app-rancher-" or Name hasprefix "rancher-webhook-"
        | summarize Seen = dcount(Name) by ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
        | where Seen == 0
        | project ClusterName, Reason = "ABSENCE: No Rancher pods observed"
      ),
      (
        // UNRESPONSIVE / EXCESSIVE RESTARTS: not Running/Succeeded OR restarts > 2
        KubePodInventory
        | where TimeGenerated > ago(15m)
        | where Namespace == "cattle-system"
        // exclude short-lived jobs
        | where not(Name hasprefix "helm-operation-") and not(Name hasprefix "pull-")
        // only core Rancher components
        | where Name hasprefix "core-app-rancher-" or Name hasprefix "rancher-webhook-"
        | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
        | summarize arg_max(TimeGenerated, *),
                    MaxPodRestarts       = max(PodRestartCount),
                    MaxContainerRestarts = max(ContainerRestartCount)
            by ClusterName, PodName = Name
        | extend PodStatus = tolower(tostring(PodStatus))
        | where PodStatus !in ("running","succeeded")
              or MaxPodRestarts > 2
              or MaxContainerRestarts > 2
        | project ClusterName, Reason = strcat(
            "UNRESPONSIVE/RESTARTING: pod=", PodName,
            "; status=", PodStatus,
            "; pod restarts=", tostring(MaxPodRestarts),
            "; container restarts=", tostring(MaxContainerRestarts)
          )
      )
    KQL

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert", Control = "SI-4" }
  )
}
