#### Excessive Failed Logins
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "grafana_excessive_failed_logins" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Grafana Excessive Failed Logins"
  description             = "NIST CONTROL: AC-7\nAlert on repeated failed login attempts for users or clients"
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 3
    query                   = <<-QUERY
      let SearchValue = "invalid_user_credentials";
      ContainerLogV2
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where PodNamespace == "grafana"
      | where LogMessage contains tostring(SearchValue)
      | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Log Forwarding Failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "grafana_audit_log_forwarding_failure" {
  resource_group_name     = var.global_resource_group
  location                = var.location
  name                    = "Grafana Audit Log Forwarding Failure"
  description             = "NIST CONTROL: AU-2, AU-12\nAlert when grafana fails to forward logs to centralized log systems or SIEM (1 minute)"
  severity                = 1      # High severity, matching log forwarding failure alert
  evaluation_frequency    = "PT1M" # As per ticket requirement (1 minute)
  window_duration         = "PT1M" # As per ticket requirement (1 minute)
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
	    let ExpectedPods = ContainerLogV2
        | where PodNamespace == "grafana"
        | where TimeGenerated > ago(1h)
        | distinct PodName;
      let ActivePods = ContainerLogV2
        | where PodNamespace == "grafana"
        | where TimeGenerated > ago(1m)
        | distinct PodName;
      let InactivePods = ExpectedPods
        | join kind=leftanti (ActivePods) on PodName;
      ContainerLogV2
        | where PodNamespace == "grafana"
        | where TimeGenerated > ago(1h)
        | where PodName in (InactivePods)
        | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
        | summarize LastSeen = max(TimeGenerated) by ClusterName, PodNamespace, PodName, ContainerName
        | project LastSeen, ClusterName, PodNamespace, PodName, ContainerName
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Unusual admin console access
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "grafana_unusual_admin_console_access" {
  resource_group_name     = var.global_resource_group
  location                = var.location
  name                    = "Grafana Unusual Admin Console Access"
  description             = "NIST CONTROL: AU-6\nAlert when grafana admin console is detected between 1800 - 0600 hours"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
	    let SearchValue = "userId";
      let TargetNamespace = "grafana";
      ContainerLogV2
      | where PodNamespace == TargetNamespace
      | where LogMessage contains tostring(SearchValue)
      | parse kind=simple LogMessage with * "path=" pathValue " " *
      | where pathValue == "/login"
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | extend hour = datetime_part("hour", TimeGenerated)
      | where hour >= 22 or hour < 10   // Filter for activity between UTC 10 PM and 10 AM
      | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage
      | order by TimeGenerated desc
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

# Unauthorized API access
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "grafana_unauthorized_api_access" {
  resource_group_name     = var.global_resource_group
  location                = var.location
  name                    = "Grafana Unauthorized Api Access"
  description             = "NIST CONTROL: IR-6\nAlert when there is an unauthorized access to grafana/prometheus API"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
	    let TargetNamespace = "grafana";
      ContainerLogV2
        | where PodNamespace == TargetNamespace
        | where LogMessage has "status=401" or LogMessage has "status=403"
        | parse kind=simple LogMessage with * "path=" pathValue " " * "status=" statusCode:int *
        | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
        | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, pathValue, statusCode, LogMessage
        | order by TimeGenerated desc
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "grafana_log_queue_overflow" {
  resource_group_name     = var.global_resource_group
  location                = var.location
  name                    = "Grafana Log Queue Overflow"
  description             = "NIST CONTROL: AU-5\nAlert when log queue overflows or experiences backpressure"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
	    let TargetNamespace = "loki";
      ContainerLogV2
        | where PodNamespace == TargetNamespace
        | where PodName contains "core-app-promtail-"
        | where LogMessage has "final error sending batch"
        | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
        | project TimeGenerated, ClusterName, PodNamespace, PodName, ContainerName, LogMessage
        | order by TimeGenerated desc
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Unavailable or Unresponsive
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "grafana_unavailable_or_unresponsive" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Grafana Unavailable or Unresponsive"
  description             = "NIST CONTROL: SI-4\nDetect when Grafana goes offline or stops responding to authentication requests"
  severity                = 2
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      // SI-4: Detect when Grafana goes offline, stops responding, restarts excessively, or has DaemonSet failures.

      // Expected services (seen in last 24h)
      let ExpectedServices = KubePodInventory
      | where Namespace == 'grafana'
      | where TimeGenerated > ago(1d)
      | where isnotempty(ServiceName)
      | distinct ClusterName, ServiceName;

      // Active services (seen in last 15 min)
      let ActiveServices = KubePodInventory
      | where TimeGenerated > ago(15m)
      | where Namespace == "grafana"
      | summarize Seen = dcount(Name) by ClusterName, ServiceName
      | project ClusterName, ServiceName, Seen;

      // Dynamically identify DaemonSets (no hardcoding)
      let DaemonSets = KubePodInventory
      | where Namespace == "grafana"
      | where TimeGenerated > ago(1d)
      | where ControllerKind == "DaemonSet"
      | distinct ClusterName, DaemonSetName = ControllerName;

      // Active DaemonSet pods (seen in last 15m)
      let ActiveDaemonPods = KubePodInventory
      | where TimeGenerated > ago(15m)
      | where Namespace == "grafana"
      | where ControllerKind == "DaemonSet"
      | summarize SeenPods = dcount(Name) by ClusterName, DaemonSetName = ControllerName
      | project ClusterName, DaemonSetName, SeenPods;

      // DaemonSet absence or missing pods
      let DaemonSetAbsence = DaemonSets
      | join kind=leftouter ActiveDaemonPods on ClusterName, DaemonSetName
      | extend SeenPods = coalesce(SeenPods, 0)
      | where SeenPods == 0 or isempty(SeenPods)
      | project ClusterName, ServiceName = DaemonSetName, Reason = strcat("ABSENCE: No DaemonSet pods seen");

      // Unresponsive or excessive restarts
      let Unresponsive = KubePodInventory
      | where TimeGenerated > ago(15m)
      | where Namespace == "grafana"
      | summarize
          arg_max(TimeGenerated, *),
          MaxPodRestarts = max(PodRestartCount),
          MaxContainerRestarts = max(ContainerRestartCount)
          by ClusterName, PodName = Name, ServiceName
      | where tolower(tostring(PodStatus)) !in ("running","succeeded")
            or MaxPodRestarts > 2
            or MaxContainerRestarts > 2
      | project ClusterName, ServiceName, Reason = strcat(
          "UNRESPONSIVE/RESTARTING: pod=", PodName,
          "; status=", PodStatus,
          "; pod restarts=", tostring(MaxPodRestarts),
          "; container restarts=", tostring(MaxContainerRestarts)
        );

      // Excessive pod creation (churn)
      let Churn = KubePodInventory
      | where Namespace == 'grafana'
      | where TimeGenerated > ago(15m)
      | where isnotempty(ServiceName)
      | where ControllerKind != "DaemonSet"
      | summarize
          UniquePodsCreated = dcount(Name),
          PodNames = make_set(Name),
          FirstSeen = min(TimeGenerated),
          LastSeen = max(TimeGenerated)
          by ClusterName, ServiceName
      | where UniquePodsCreated > 3
      | project ClusterName, ServiceName, Reason = strcat('CHURN: UniquePodsCreated=', UniquePodsCreated, '; Pods=', PodNames);

      // Combine all findings
      union
      (
          // Missing services
          ExpectedServices
          | join kind=leftouter ActiveServices on ClusterName, ServiceName
          | extend Seen = coalesce(Seen, 0)
          | where Seen == 0 or isempty(Seen)
          | project ClusterName, ServiceName, Reason = "ABSENCE: No service pods seen"
      ),
      Unresponsive,
      Churn,
      DaemonSetAbsence
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}
