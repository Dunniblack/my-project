resource "azurerm_monitor_scheduled_query_rules_alert_v2" "secret_expiry_alert" {
  name                = "SecretExpiryAlert"
  resource_group_name = var.global_resource_group
  location            = var.location

  evaluation_frequency = "P1D"
  window_duration      = "P1D"
  scopes               = [var.c1_log_analytics_workspace_id]
  severity             = 3
  description          = "Alert when a Key Vault Secret is near expiry or has expired."
  enabled              = true


  criteria {
    query = <<-QUERY
		AzureDiagnostics
		| where OperationName contains "SecretNearExpiryEventGridNotification" or OperationName contains "SecretExpiredEventGridNotification"
		| project SecretName = column_ifexists("eventGridEventProperties_data_ObjectName_s", "eventGridEventProperties_data_ObjectName_s")
	QUERY

    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
  }

  action {
    action_groups = [azurerm_monitor_action_group.devops.id]
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )

}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "certificate_expiry_alert" {
  name                = "CertificateExpiryAlert"
  resource_group_name = var.global_resource_group
  location            = var.location

  evaluation_frequency = "P1D"
  window_duration      = "P1D"
  scopes               = [var.c1_log_analytics_workspace_id]
  severity             = 3
  description          = "Alert when a Key Vault Certificate is near expiry or has expired."
  enabled              = true


  criteria {
    query = <<-QUERY
		AzureDiagnostics
		| where OperationName contains "CertificateNearExpiryEventGridNotification" or OperationName contains "CertificateExpiredEventGridNotification"
		| project SecretName = column_ifexists("eventGridEventProperties_data_ObjectName_s", "eventGridEventProperties_data_ObjectName_s")
	QUERY

    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
  }

  action {
    action_groups = [azurerm_monitor_action_group.devops.id]
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )

}
