variable "stage" {
  description = "The stage of the Environment (dev, test, prod)"
  type        = string
}

variable "enclave" {
  description = "The enclave that we're executing the logic (i.e. 'wdsf', 'c1')."
  type        = string
  validation {
    condition     = contains(["wdsf", "c1", "thundercamp"], var.enclave)
    error_message = "The enclave  must be one of the follwing: \"wdsf\", \"c1\", \"thundercamp\""
  }
}

variable "location" {
  description = "The Azure location where resources will be created."
  type        = string
  default     = "USGov Virginia"
}

variable "global_resource_group" {
  description = "The name of the Global Resource Group."
  type        = string
}

variable "c1_log_analytics_workspace_id" {
  description = "The ID of the C1 Log Analytics Workspace."
  type        = string
}

variable "common_tags" {
  description = "Common Tags to apply to Azure resources."
  type        = map(any)
}

variable "global_storage_account_name" {
  description = "Name of the storage account used for global alerts."
  type        = string
}

variable "drift_container_name" {
  description = "Name of the storage container used for terraform drift detection."
  type        = string
}

variable "k8s_tls_alert_container_name" {
  description = "Name of the storage container used for tls expiration alerts."
  type        = string
}

variable "k8s_credentials_alert_container_name" {
  description = "Name of the storage container used for credentials expiration alerts."
  type        = string
}
