resource "azurerm_monitor_scheduled_query_rules_alert_v2" "k8s_credentials_expiration_alert" {
  resource_group_name     = var.global_resource_group
  location                = var.location
  name                    = "K8s Management Credential Expiration Alerts"
  description             = "Alerts when a STIG 60-day credential expiry report is uploaded to the k8s-credential-alert container"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [azurerm_monitor_action_group.devops.id]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1

    query = <<-QUERY
      StorageBlobLogs
      | where AccountName == "${var.global_storage_account_name}"
      | where OperationName == "PutBlob"
      | where StatusText == "Success"
      | where Uri contains "/${var.k8s_credentials_alert_container_name}/alerts/"
      | project TimeGenerated, AccountName, Uri
      | order by TimeGenerated desc
    QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}