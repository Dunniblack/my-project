#### Terraform Drift Alert
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "terraform_drift" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "Terraform Drift Detected"
  description             = "Alert on Terraform drift"
  severity                = 3
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [azurerm_monitor_action_group.devops.id]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      let StorageAccountName = "${var.global_storage_account_name}";
      let ContainerName = "${var.drift_container_name}";
      StorageBlobLogs
      | where OperationName == "PutBlob"
      | where StatusText == "Success"
      | where AccountName == StorageAccountName
      | where Uri has ContainerName
      | extend UriParts = split(parse_url(Uri).Path, "/")
      | extend ContainerName = UriParts[1]
      | extend RawBlobName = UriParts[2]
      | extend BlobNameParts = split(RawBlobName, "-")
      | extend BlobName = url_decode(tostring(RawBlobName))
      | extend Enclave = BlobNameParts[0]
      | extend Module = BlobNameParts[1]
      | extend Workspace = BlobNameParts[2]
      | project TimeGenerated, ContainerName, BlobName, Enclave, Module, Workspace, Uri
      | order by TimeGenerated desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}
