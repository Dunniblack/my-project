#### Log Forwarding Failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "aks_log_forwarding_failure" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "AKS Audit Log Forwarding Failure"
  description             = "NIST CONTROL: AU-2, AU-12\nAlert when AKS fails to forward logs to centralized log systems or SIEM ( 1 minute)"
  severity                = 1
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      let MinEvents = 5;        // require at least X events normally
      union
      (
          AKSAudit
          | where TimeGenerated > ago(5m)
          | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
          | summarize AuditCount = count() by ClusterName
      ),
      (
          AKSControlPlane
          | where TimeGenerated > ago(5m)
          | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
          | summarize ControlPlaneCount = count() by ClusterName
      )
      | summarize
          AuditCount = sum(AuditCount),
          ControlPlaneCount = sum(ControlPlaneCount),
          TotalLogCount = sum(AuditCount + ControlPlaneCount)
          by ClusterName
      | where TotalLogCount < MinEvents
      | project ClusterName, AuditCount, ControlPlaneCount, TotalLogCount
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### Excessive Failed Logins
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "aks_excessive_failed_logins" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "AKS Excessive Failed Logins to API Server"
  description             = "NIST CONTROL: AC-7\nDetect brute-force or unauthorized access attempts"
  severity                = 0
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 3
    query                   = <<-QUERY
      let Threshold = 10;
      let PerIPThreshold = 10;
      let Window = 5m;
      AKSAudit
      | where TimeGenerated > ago(15m)
      | extend StatusCode = tostring(parse_json(ResponseStatus).code)
      | where StatusCode in ("401","403")
      | extend ReqObj = parse_json(RequestObject)
      | extend XFF = tostring(ReqObj.headers["x-forwarded-for"])
      | extend XFF_First = trim(" ", tostring(split(XFF, ",")[0]))
      | extend SourceIpsArray = todynamic(SourceIps)
      | extend SourceIpsFirst = iif(SourceIpsArray != "" and array_length(SourceIpsArray) > 0, tostring(SourceIpsArray[0]), "unknown")
      | extend ClientIP = coalesce(XFF_First, SourceIpsFirst, "unknown")
      | extend UserName = coalesce(tostring(User.username), "anonymous")
      | extend UserAgentStr = tostring(UserAgent)
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | where UserName !in ("system:serviceaccount:kube-system:metrics-server")
      | where not(UserAgentStr contains "kube-probe")
      | where not(UserAgentStr contains "ELB-HealthChecker")
      | summarize FailuresPerIP = count()
          by bin(TimeGenerated, totimespan(Window)), UserName, SourceIP = ClientIP, UserAgent = UserAgentStr, ClusterName
      | summarize TotalFailures = sum(FailuresPerIP), DistinctIPs = dcount(SourceIP), MaxPerIP = max(FailuresPerIP)
          by bin(TimeGenerated, totimespan(Window)), UserName, UserAgent, ClusterName
      | where TotalFailures >= Threshold or MaxPerIP >= PerIPThreshold
      | project TimeGenerated, ClusterName, User = UserName, TotalFailures, DistinctIPs, UserAgent
      | order by TimeGenerated desc
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }
  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### New Cluster-Admin Role Binding Created
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "aks_new_cluster_admin_role_binding" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "AKS New Cluster-Admin Role Binding Created"
  description             = "NIST CONTROL: AC-2, AC-6\nAlert on creation of cluster-admin role bindings"
  severity                = 0
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      AKSAudit
      | where TimeGenerated > ago(5m)
      | where isnotempty(ObjectRef)
      | where tostring(ObjectRef.kind) in ("RoleBinding", "ClusterRoleBinding")
      | where tostring(Verb) in ("create", "patch", "apply")
      | extend RequestStr = tostring(RequestObject)
      | where RequestStr has "cluster-admin"
      | where tostring(User.username) !startswith "system:"
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | project
          TimeGenerated,
          ClusterName,
          User = tostring(User.username),
          ObjectKind = tostring(ObjectRef.kind),
          ObjectName = tostring(ObjectRef.name),
          Namespace = tostring(ObjectRef.namespace),
          Verb,
          RequestStr,
          ResponseStatus
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}

#### RBAC Changes Detected
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "aks_rbac_changes_detected" {
  resource_group_name = var.global_resource_group
  location            = var.location

  name                    = "AKS RBAC Changes Detected"
  description             = "NIST CONTROL: CM-6\nDetect any changes to RBAC roles or bindings"
  severity                = 0
  evaluation_frequency    = "PT5M"
  window_duration         = "PT5M"
  scopes                  = [var.c1_log_analytics_workspace_id]
  target_resource_types   = ["Microsoft.OperationalInsights/workspaces"]
  auto_mitigation_enabled = false

  action {
    action_groups = [
      azurerm_monitor_action_group.devops.id,
      azurerm_monitor_action_group.cyber.id
    ]
  }

  criteria {
    time_aggregation_method = "Count"
    operator                = "GreaterThanOrEqual"
    threshold               = 1
    query                   = <<-QUERY
      let ExcludedNamespaces = dynamic(["kube-system", "gatekeeper-system"]);
      AKSAudit
      | where TimeGenerated > ago(5m)
      | where isnotempty(ObjectRef)
      | where tostring(ObjectRef.kind) in ("Role", "ClusterRole", "RoleBinding", "ClusterRoleBinding")
      | where tostring(Verb) in ("create", "update", "patch", "delete")
      | where tostring(ObjectRef.namespace) !in (ExcludedNamespaces)
      | where tostring(User.username) !startswith "system:"   // ignore system accounts
      | extend ClusterName = extract(@"/managedclusters/([^/]+)", 1, _ResourceId)
      | project
          TimeGenerated,
          ClusterName,
          User = tostring(User.username),
          ObjectKind = tostring(ObjectRef.kind),
          ObjectName = tostring(ObjectRef.name),
          Namespace = tostring(ObjectRef.namespace),
          Verb,
          RequestUri,
          ResponseStatus
      QUERY

    failing_periods {
      number_of_evaluation_periods             = 1
      minimum_failing_periods_to_trigger_alert = 1
    }
  }

  tags = merge(
    var.common_tags,
    { Service = "monitor-alert" }
  )
}
