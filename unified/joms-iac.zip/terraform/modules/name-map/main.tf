locals {
  environment_common_name = (
    var.environment_name == "PREPR" ?
    "preprod" :
    lower(var.environment_name)
  )
  c1_project_name = (
    var.environment_name == "PREPR" ?
    "PREPROD" :
    upper(var.environment_name)
  )
  container_registry_name = join("",
    [
      lower(var.project),
      "registry",
      lower(var.stage)
    ]
  )
  key_vault_name = join("",
    [
      "GV",
      upper(var.project),
      upper(var.environment_name),
      upper(substr(var.stage, 0, 1)),
      upper(var.impact_level),
      "KV",
      upper(var.key_vault_unique_id)
    ]
  )
  sadus_storage_account_name = join("",
    [
      "gv",
      lower(var.c1_project),
      lower(var.environment_name),
      lower(substr(var.stage, 0, 1)),
      lower(var.impact_level),
      "sadus"
    ]
  )
  velero_storage_account_name = join("",
    [
      "gv",
      lower(var.c1_project),
      lower(var.environment_name),
      lower(substr(var.stage, 0, 1)),
      lower(var.impact_level),
      "velero"
    ]
  )
  loki_storage_account_name = join("",
    [
      "gv",
      lower(var.c1_project),
      lower(var.environment_name),
      lower(substr(var.stage, 0, 1)),
      lower(var.impact_level),
      "loki"
    ]
  )
  global_storage_account_name = join("",
    [
      "gv",
      lower(var.c1_project),
      lower(var.environment_name),
      lower(substr(var.stage, 0, 1)),
      lower(var.impact_level),
      "glb"
    ]
  )
  guardrail_storage_account_name = join("",
    [
      "gv",
      lower(var.c1_project),
      lower(var.environment_name),
      lower(substr(var.stage, 0, 1)),
      lower(var.impact_level),
      "grail"
    ]
  )
  guardrail_kv_name = join("",
    [
      "DE",
      upper(var.project),
      upper(var.environment_name),
      upper(substr(var.stage, 0, 1)),
      upper(var.impact_level),
      "KVT"
    ]
  )
  disk_encryption_set_name = join("",
    [
      "GV",
      upper(var.project),
      upper(var.environment_name),
      upper(substr(var.stage, 0, 1)),
      upper(var.impact_level),
      "DES01"
    ]
  )
  disk_encryption_set_key_name = join("",
    [
      "GV",
      upper(var.project),
      upper(var.environment_name),
      upper(substr(var.stage, 0, 1)),
      upper(var.impact_level),
      "DES-key01"
    ]
  )
  resource_group_name = join("",
    [
      "AZ-GV-DOD-AF-CCE-",
      upper(var.functional_area),
      "-",
      upper(substr(var.stage, 0, 1)),
      "-",
      upper(var.impact_level),
      "-",
      upper(var.project),
      "-",
      upper(var.environment_name),
      "-AKS-RGP-01"
    ]
  )
  dedicated_host_group = join("",
    [
      lower(var.project),
      "-",
      lower(var.environment_name),
      "-dedicated-host-group"
    ]
  )
  dedicated_host = join("",
    [
      lower(var.project),
      "-",
      lower(var.environment_name),
      "-dedicated-host"
    ]
  )
  aks_name = join("",
    [
      "AKS",
      upper(var.project),
      upper(var.environment_name),
      upper(substr(var.stage, 0, 1)),
      "GV01"
    ]
  )
  aks_fileshare_storage_account_name = join("",
    [
      "aksfileshare",
      lower(var.stage),
      lower(var.environment_name),
    ]
  )
}
