output "environment_common_name" {
  description = "The full common name of the environment."
  value       = local.environment_common_name
}

output "c1_project_name" {
  description = "The Project Name that C1 uses to provision resources."
  value       = local.c1_project_name
}

output "container_registry_name" {
  description = "The Name of the Azure Container Registry to create."
  value       = local.container_registry_name
}

output "key_vault_name" {
  description = "The Name of the Key Vault to create."
  value       = local.key_vault_name
}

output "sadus_storage_account_name" {
  description = "The Name of the Sadus Storage Account."
  value       = local.sadus_storage_account_name
}

output "velero_storage_account_name" {
  description = "The Name of the Velero Storage Account."
  value       = local.velero_storage_account_name
}

output "loki_storage_account_name" {
  description = "The Name of the Loki Storage Account."
  value       = local.loki_storage_account_name
}

output "global_storage_account_name" {
  description = "The Name of the Terraform Global Storage Account."
  value       = local.global_storage_account_name
}

output "guardrail_storage_account_name" {
  description = "The Name of the Guardrail Storage Account."
  value       = local.guardrail_storage_account_name
}

output "guardrail_kv_name" {
  description = "The Name of the Key Vault to create for guardrail."
  value       = local.guardrail_kv_name
}

output "disk_encryption_set_name" {
  description = "The name of the disk encryption set."
  value       = local.disk_encryption_set_name
}

output "disk_encryption_set_key_name" {
  description = "The name of the disk encryption set keyvault key."
  value       = local.disk_encryption_set_key_name
}

output "resource_group_name" {
  description = "The name of the resource group for resources to be deployed."
  value       = local.resource_group_name
}

output "dedicated_host_group" {
  description = "The Name of the dedicated host group."
  value       = local.dedicated_host_group
}

output "dedicated_host" {
  description = "The Name of the dedicated host."
  value       = local.dedicated_host
}

output "aks_name" {
  description = "The Name of the Azure Kuberenetes Service Resource."
  value       = local.aks_name
}

output "aks_fileshare_storage_account_name" {
  description = "The Name of the AKS Fileshare Storage Account."
  value       = local.aks_fileshare_storage_account_name
}
