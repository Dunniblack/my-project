output "azure_config" {
  description = "The current Azure Client Config"
  value       = data.azurerm_client_config.current
}

output "resource_group" {
  description = "AKS Resource Group"
  value       = data.azurerm_resource_group.aks
}

output "vnet" {
  description = "AKS Virtual Network"
  value       = data.azurerm_virtual_network.aks
}

output "subnet" {
  description = "AKS Subnet"
  value       = data.azurerm_subnet.aks
}

output "api_server_subnet" {
  description = "AKS API server Subnet"
  value       = data.azurerm_subnet.api_server_subnet
}

output "cmnsvc_vnet" {
  description = "C1 Common Service Virtual Network"
  value       = data.azurerm_virtual_network.cmnsvc
}

output "cmnsvc_subnet" {
  description = "C1 Common Service Subnet"
  value       = data.azurerm_subnet.cmnsvc
}

output "c1_key_vault" {
  description = "C1 Key Vault"
  value       = data.azurerm_key_vault.c1
}

output "c1_log_analytics_workspace" {
  description = "C1 Log Analytics Workspace"
  value       = data.azurerm_log_analytics_workspace.c1
}

output "c1_automation_account" {
  description = "C1 Azure Automation Account"
  value       = try(data.azurerm_automation_account.c1.0, null)
}

output "kubelet_managed_identity" {
  description = "User assigned managed identity for kublet"
  value       = try(data.azurerm_user_assigned_identity.kubelet.0, null)
}

output "control_plane_managed_identity" {
  description = "User assigned managed identity for control plane"
  value       = try(data.azurerm_user_assigned_identity.control_plane.0, null)
}

output "velero_managed_identity" {
  description = "User assigned managed identity for Velero"
  value       = try(data.azurerm_user_assigned_identity.velero.0, null)
}

output "loki_managed_identity" {
  description = "User assigned managed identity for Loki"
  value       = try(data.azurerm_user_assigned_identity.loki.0, null)
}

output "eso_managed_identity" {
  description = "User assigned managed identity for External Secrets"
  value       = try(data.azurerm_user_assigned_identity.eso.0, null)
}

output "api_server_subnet_id" {
  description = "The subnet Id for the api server"
  value       = try(data.azurerm_subnet.api_server_subnet.0.id, null)
}
