data "azurerm_client_config" "current" {}

data "azurerm_resource_group" "aks" {
  name = var.resource_group_name
}

data "azurerm_virtual_network" "aks" {
  name                = var.vnet_name
  resource_group_name = var.resource_group_name
}

data "azurerm_subnet" "aks" {
  name                 = var.subnet_name
  virtual_network_name = var.vnet_name
  resource_group_name  = var.resource_group_name
}

data "azurerm_subnet" "api_server_subnet" {
  count                = var.api_server_subnet_name != "" ? 1 : 0
  name                 = var.api_server_subnet_name
  virtual_network_name = var.vnet_name
  resource_group_name  = var.resource_group_name
}

data "azurerm_virtual_network" "cmnsvc" {
  name                = var.cmnsvc_vnet_name
  resource_group_name = var.cmnsvc_resource_group_name
}

data "azurerm_subnet" "cmnsvc" {
  name                 = var.cmnsvc_subnet_name
  virtual_network_name = var.cmnsvc_vnet_name
  resource_group_name  = var.cmnsvc_resource_group_name
}

data "azurerm_key_vault" "c1" {
  name                = var.core_key_vault_name
  resource_group_name = var.kv_resource_group_name
}

data "azurerm_log_analytics_workspace" "c1" {
  name                = var.log_analytics_workspace_name
  resource_group_name = var.la_resource_group_name
}

data "azurerm_automation_account" "c1" {
  count               = var.automation_account_name != "" ? 1 : 0
  name                = var.automation_account_name
  resource_group_name = var.aa_resource_group_name
}

data "azurerm_user_assigned_identity" "kubelet" {
  count               = var.mi_kubelet_name != "" ? 1 : 0
  name                = var.mi_kubelet_name
  resource_group_name = var.mi_resource_group_name
}

data "azurerm_user_assigned_identity" "control_plane" {
  count               = var.mi_control_plane_name != "" ? 1 : 0
  name                = var.mi_control_plane_name
  resource_group_name = var.mi_resource_group_name
}

data "azurerm_user_assigned_identity" "loki" {
  count               = var.mi_loki_name != "" ? 1 : 0
  name                = var.mi_loki_name
  resource_group_name = var.mi_resource_group_name
}

data "azurerm_user_assigned_identity" "eso" {
  count               = var.mi_eso_name != "" ? 1 : 0
  name                = var.mi_eso_name
  resource_group_name = var.mi_resource_group_name
}

data "azurerm_user_assigned_identity" "velero" {
  count               = var.mi_velero_name != "" ? 1 : 0
  name                = var.mi_velero_name
  resource_group_name = var.mi_resource_group_name
}
