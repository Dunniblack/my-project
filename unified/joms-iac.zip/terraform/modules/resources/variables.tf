variable "resource_group_name" {
  type        = string
  description = "The name of the AKS Resource Group."
}

variable "vnet_name" {
  type        = string
  description = "The Virtual Network Name of the AKS Resources."
}

variable "subnet_name" {
  type        = string
  description = "The Subnet Name of the AKS Resources."
}

variable "api_server_subnet_name" {
  type        = string
  description = "The Subnet Name of the cluster API server."
  default     = ""
}

variable "cmnsvc_resource_group_name" {
  description = "The name of the Resource Group of the C1 Common Services."
  type        = string
}

variable "cmnsvc_vnet_name" {
  type        = string
  description = "The Virtual Network Name of the C1 Common Services."
}

variable "cmnsvc_subnet_name" {
  type        = string
  description = "The Subnet Nameo f the C1 Common Services"
}

variable "core_key_vault_name" {
  type        = string
  description = "The C1 Key Vault Name."
}

variable "kv_resource_group_name" {
  type        = string
  description = "The name of the C1 Key Vault Resource Group."
}

variable "log_analytics_workspace_name" {
  type        = string
  description = "The Log Analytics Workspace Name."
}

variable "la_resource_group_name" {
  type        = string
  description = "The name of the C1 Log Analytics Workspace Resource Group."
}

variable "automation_account_name" {
  type        = string
  description = "The Azure Automation Account Name."
}

variable "aa_resource_group_name" {
  type        = string
  description = "The name of the C1 Azure Automation Account Resource Group."
}

variable "mi_kubelet_name" {
  type        = string
  description = "User assigned managed identity for kublet."
  default     = ""
}

variable "mi_control_plane_name" {
  type        = string
  description = "User assigned managed identity for control plane."
  default     = ""
}

variable "mi_loki_name" {
  type        = string
  description = "User assigned managed identity for loki."
  default     = ""
}

variable "mi_eso_name" {
  type        = string
  description = "User assigned managed identity for external secrets."
  default     = ""
}

variable "mi_velero_name" {
  type        = string
  description = "User assigned managed identity for velero."
  default     = ""
}

variable "mi_resource_group_name" {
  type        = string
  description = "Resource group for the managed identities."
  default     = ""
}
