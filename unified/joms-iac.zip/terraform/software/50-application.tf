resource "kubernetes_manifest" "application" {
  count = (var.aks_argo_cd_deployed) ? 1 : 0

  manifest = {

    # Make sure this API Version stays in sync with the file:
    # scripts/ps/terraform/Set-AksServerId.ps1
    apiVersion = "argoproj.io/v1alpha1"
    kind       = "Application"

    metadata = {
      name      = "bootstrap-parent"
      namespace = local.argocd_namespace
    }
    spec = {
      project = "default"
      source = {
        repoURL        = jsondecode(data.azurerm_key_vault_secret.repo-joms-iac.value).url
        path           = "argo-app"
        targetRevision = "${lower(var.environment_name)}-config"
      }
      destination = {
        server = "https://kubernetes.default.svc"
      }
      syncPolicy = {
        automated = {
          prune    = true
          selfHeal = true
        }
        syncOptions = [
          "Validate=false",
          "RespectIgnoreDifferences=true",
          "CreateNamespace=true",
          "ApplyOutOfSyncOnly=true",
        ]
      }
    }
  }

  lifecycle {
    replace_triggered_by = [
      null_resource.always_run
    ]
  }
  depends_on = [
    helm_release.argo-cd,
    kubernetes_storage_class_v1.aks-fileshare,
    kubernetes_secret_v1.repo-joms-iac,
    kubernetes_secret_v1.repo-helm,
    kubernetes_secret_v1.repo-helm-oci,
    null_resource.git_push,
  ]
}
