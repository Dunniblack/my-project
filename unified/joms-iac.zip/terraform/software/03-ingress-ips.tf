# Get the list of available internal IPs
data "external" "traefik_internal_ip" {
  program = ["powershell", "${abspath(path.root)}/../../scripts/ps/terraform/Get-InternalIp.ps1"]
  query = {
    resource_group = var.vnet_resource_group_name
    vnet_name      = var.vnet_name
    subnet_name    = var.subnet_name
  }
}

locals {
  traefik_internal_ip = coalesce(
    var.traefik_internal_ip,
    try(
      data.terraform_remote_state.az.outputs.traefik_internal_ip,
      data.external.traefik_internal_ip.result["internal_ip"]
    )
  )
  traefik_external_ingress_enabled = coalesce(
    var.traefik_external_ingress_enabled,
    try(
      data.terraform_remote_state.az.outputs.traefik_external_ingress_enabled,
      try(
        data.terraform_remote_state.infrastructure.outputs.traefik_external_ingress_enabled,
        contains(["test", "prod"], var.stage) ? true : false
      )
    )
  )
}

# Verify external IP exists
data "azurerm_public_ip" "external" {
  count               = (local.traefik_external_ingress_enabled) ? 1 : 0
  name                = "aks-pip-${lower(var.environment_name)}"
  resource_group_name = local.default_resource_group
}
