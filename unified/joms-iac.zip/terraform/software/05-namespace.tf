locals {
  argocd_namespace = "argocd"
  init_namespaces = [
    "kyverno",
    local.argocd_namespace,
  ]
  mission_planner_namespaces = [
    "cd1-blue",
    "cd1-green",
  ]
  namespaces = concat(
    local.init_namespaces,
    local.mission_planner_namespaces,
    [
      "alloy",
      "auth",
      "cattle-global-data",
      "cattle-system",
      "cert-manager",
      "external-secrets",
      "grafana",
      "ingress",
      "loki",
      "twistlock",
      "velero",
    ]
  )
}

resource "kubernetes_namespace_v1" "all" {
  for_each = toset(local.namespaces)
  metadata {
    name = each.key
    labels = {
      "core-app" = "yes"
    }
  }

  lifecycle {
    ignore_changes = [
      metadata
    ]
  }
}
