## helm-credentials
data "azurerm_key_vault_secret" "helm-credentials" {
  count = 1

  name         = "helm-credentials"
  key_vault_id = module.resources.c1_key_vault.id
}

## git-credentials
data "azurerm_key_vault_secret" "git-credentials" {
  name         = "git-credentials"
  key_vault_id = module.resources.c1_key_vault.id
}

## keycloak-idp-config
data "azurerm_key_vault_secrets" "global_secrets" {
  key_vault_id = module.resources.c1_key_vault.id
}

# Keycloak IdP Config is expected to adhere to this JSON schema:
#     displayName:            (String, required) Identity Provider name that will be displayed on the Keycloak login screen
#     spEntityId:             (String, optional) Service Provider entity ID. If not provided, will be set to Keycloak external host URL
#     idpEntityId:            (String, required) Identity Provider entity ID
#     singleSignOnServiceUrl: (String, required) Identity Provider single sign-on service URL
#     singleLogoutServiceUrl: (String, optional) Identity Provider logout service URL
#     signingCertificate:     (String, required) Identity Provider signing certificate
#     encryptionPublicKey:    (String, optional) Identity Provider encryption public key
#     principalType:          (String, required) Specifies how the principal is found in the assertion response. Must be one of: ["SUBJECT", "ATTRIBUTE"]
#     principalAttribute:     (String, optional) If principalType is "ATTRIBUTE", this identifies the response attribute containing the user's principal
#     firstNameAttribute:     (String, required) Response attribute that contains the user's first name
#     lastNameAttribute:      (String, required) Response attribute that contains the user's last name
#     emailAttribute:         (String, optional) Response attribute that contains the user's email. If not provided, user's email will not be mapped and user must provide on first login
#     usernameAttribute:      (String, optional) Response attribute that contains the unique user name. It not provided, the user's principal will be used.
#     allowedCIDRs:           (List, optional) Allowed CIDR ranges for Keycloak's IDP connectivity
data "azurerm_key_vault_secret" "keycloak_idp_config" {
  # Default to using IdP config specific to this environment_name, if not found fall back to default config for the enclave
  name = (
    contains(data.azurerm_key_vault_secrets.global_secrets.names, "keycloak-idp-config-${var.enclave}-${lower(var.environment_name)}")
    ? "keycloak-idp-config-${var.enclave}-${lower(var.environment_name)}"
    : "keycloak-idp-config-${var.enclave}"
  )
  key_vault_id = module.resources.c1_key_vault.id
}

locals {
  registry_domain       = "nexus.seicdevops.com"
  helm_oci_repo         = "${local.registry_domain}/helm-dev-oci"
  helm_oci_repo_https   = "https://${local.registry_domain}/v1/"
  docker_registry_creds = "image-pull-credentials"
  default_helm_folder   = "IaC/helm"
}

resource "kubernetes_secret_v1" "image-pull-credentials" {
  for_each = toset(local.init_namespaces)

  metadata {
    name      = local.docker_registry_creds
    namespace = each.key
  }
  data = {
    ".dockerconfigjson" = (
      "{\"auths\":{\"${local.helm_oci_repo_https}\":${data.azurerm_key_vault_secret.helm-credentials.0.value}}}"
    )
  }
  type = "kubernetes.io/dockerconfigjson"

  depends_on = [
    kubernetes_namespace_v1.all,
  ]

  lifecycle {
    ignore_changes = [
      data,
      metadata[0].annotations,
      metadata[0].labels,
    ]
  }
}


## repo-joms-iac
data "azurerm_key_vault_secret" "repo-joms-iac" {
  name         = "repo-joms-iac"
  key_vault_id = module.resources.c1_key_vault.id
}

resource "kubernetes_secret_v1" "repo-joms-iac" {
  metadata {
    name      = "repo-joms-iac"
    namespace = local.argocd_namespace
    labels = {
      "argocd.argoproj.io/secret-type" = "repository"
    }
  }
  data = tomap(merge(
    jsondecode(data.azurerm_key_vault_secret.repo-joms-iac.value),
    jsondecode(data.azurerm_key_vault_secret.git-credentials.value)
  ))
  type = "Opaque"

  depends_on = [
    kubernetes_namespace_v1.all,
  ]

  lifecycle {
    ignore_changes = [
      data,
      metadata[0].annotations,
      metadata[0].labels,
    ]
  }
}


## repo-helm
data "azurerm_key_vault_secret" "repo-helm" {
  count = 1

  name         = "repo-helm"
  key_vault_id = module.resources.c1_key_vault.id
}

resource "kubernetes_secret_v1" "repo-helm" {
  metadata {
    name      = "repo-helm"
    namespace = local.argocd_namespace
    labels = {
      "argocd.argoproj.io/secret-type" = "repository"
    }
  }
  data = (
    tomap(merge(
      jsondecode(
        replace(
          data.azurerm_key_vault_secret.repo-helm.0.value,
          local.default_helm_folder,
          local.helm_folder
        )
      ),
      jsondecode(data.azurerm_key_vault_secret.helm-credentials.0.value)
    ))
  )
  type = "Opaque"

  lifecycle {
    ignore_changes = [
      data,
      metadata[0].annotations,
      metadata[0].labels,
    ]
  }

  depends_on = [
    kubernetes_namespace_v1.all,
  ]
}

resource "kubernetes_secret_v1" "repo-helm-oci" {
  count = (
    var.enclave == "c1" &&
    lower(var.environment_name) == "prod"
  ) ? 0 : 1

  metadata {
    name      = "repo-helm-oci"
    namespace = local.argocd_namespace
    labels = {
      "argocd.argoproj.io/secret-type" = "repository"
    }
  }
  data = (
    tomap(merge(
      {
        "name"      = "repo-helm-oci"
        "enableOCI" = "true"
        "type"      = "helm"
        "project"   = "default"
        "url"       = "${local.helm_oci_repo}"
      },
      jsondecode(data.azurerm_key_vault_secret.helm-credentials.0.value)
    ))
  )
  type = "Opaque"

  lifecycle {
    ignore_changes = [
      data,
      metadata[0].annotations,
      metadata[0].labels,
    ]
  }

  depends_on = [
    kubernetes_namespace_v1.all,
  ]
}
