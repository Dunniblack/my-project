
locals {
  acr_private_endpoint_name = coalesce(
    var.acr_private_endpoint_name,
    try(
      data.terraform_remote_state.az.outputs.acr_private_endpoint_name,
      "${module.name-map.container_registry_name}-private-endpoint-0"
    )
  )
  helm_release = coalesce(
    var.helm_release,
    try(
      data.terraform_remote_state.az.outputs.helm_release,
      try(
        data.terraform_remote_state.infrastructure.outputs.helm_release,
        "core-app"
      )
    )
  )
  helm_folder = coalesce(
    var.helm_folder,
    try(
      data.terraform_remote_state.az.outputs.helm_folder,
      "IaC/helm/${lower(var.enclave)}/${lower(var.stage)}/${lower(var.environment_name)}"
    )
  )
  deploy_alloy = coalesce(
    var.deploy_alloy,
    try(
      data.terraform_remote_state.az.outputs.deploy_alloy,
      false
    )
  )
  deploy_argocd = coalesce(
    var.deploy_argocd,
    try(
      data.terraform_remote_state.az.outputs.deploy_argocd,
      false
    )
  )
  deploy_cert_manager = coalesce(
    var.deploy_cert_manager,
    try(
      data.terraform_remote_state.az.outputs.deploy_cert_manager,
      true
    )
  )
  deploy_external_secrets = coalesce(
    var.deploy_external_secrets,
    try(
      data.terraform_remote_state.az.outputs.deploy_external_secrets,
      true
    )
  )
  deploy_grafana = coalesce(
    var.deploy_grafana,
    try(
      data.terraform_remote_state.az.outputs.deploy_grafana,
      false
    )
  )
  deploy_keycloak = coalesce(
    var.deploy_keycloak,
    try(
      data.terraform_remote_state.az.outputs.deploy_keycloak,
      false
    )
  )
  deploy_kyverno = coalesce(
    var.deploy_kyverno,
    try(
      data.terraform_remote_state.az.outputs.deploy_kyverno,
      true
    )
  )
  deploy_loki = coalesce(
    var.deploy_loki,
    try(
      data.terraform_remote_state.az.outputs.deploy_loki,
      true
    )
  )
  deploy_rancher = coalesce(
    var.deploy_rancher,
    try(
      data.terraform_remote_state.az.outputs.deploy_rancher,
      false
    )
  )
  deploy_rancher_cleanup = coalesce(
    var.deploy_rancher_cleanup,
    try(
      data.terraform_remote_state.az.outputs.deploy_rancher_cleanup,
      false
    )
  )
  deploy_traefik = coalesce(
    var.deploy_traefik,
    try(
      data.terraform_remote_state.az.outputs.deploy_traefik,
      false
    )
  )
  deploy_velero = coalesce(
    var.deploy_velero,
    try(
      data.terraform_remote_state.az.outputs.deploy_velero,
      true
    )
  )
  deploy_twistlock = coalesce(
    var.deploy_twistlock,
    try(
      data.terraform_remote_state.az.outputs.deploy_twistlock,
      false
    )
  )
  deploy_mission_planner = coalesce(
    var.deploy_mission_planner,
    try(
      data.terraform_remote_state.az.outputs.deploy_mission_planner,
      false
    )
  )
  mission_planner_helm_version = coalesce(
    var.mission_planner_helm_version,
    try(
      data.terraform_remote_state.az.outputs.mission_planner_helm_version,
      (contains(["prepr", "prod"], lower(var.environment_name)) ? "*" : "*-0")
    )
  )
  up_node_selector = coalesce(
    var.up_node_selector,
    try(
      data.terraform_remote_state.az.outputs.up_node_selector,
      "blue01"
    )
  )
  include_warpdrive_idp = coalesce(
    var.include_warpdrive_idp,
    try(
      data.terraform_remote_state.az.outputs.include_warpdrive_idp,
      var.enclave != "c1"
    )
  )
  velero_backup_schedule_enabled = coalesce(
    var.velero_backup_schedule_enabled,
    try(
      data.terraform_remote_state.az.outputs.velero_backup_schedule_enabled,
      var.enclave == "c1"
    )
  )
  grafana_local_admin_enabled = coalesce(
    var.grafana_local_admin_enabled,
    try(
      data.terraform_remote_state.az.outputs.grafana_local_admin_enabled,
      false
    )
  )
}
