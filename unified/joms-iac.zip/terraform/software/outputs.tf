output "versions" {
  value = data.external.versions.result
}

output "traefik_internal_ip" {
  value = local.traefik_internal_ip
}

output "traefik_external_ingress_enabled" {
  value = local.traefik_external_ingress_enabled
}

output "twistlock_email_egress_enabled" {
  value = local.twistlock_email_egress_enabled
}

output "acr_private_endpoint_name" {
  value = local.acr_private_endpoint_name
}

output "helm_release" {
  value = local.helm_release
}

output "helm_folder" {
  value = local.helm_folder
}

output "deploy_alloy" {
  value = local.deploy_alloy
}

output "deploy_argocd" {
  value = local.deploy_argocd
}

output "deploy_cert_manager" {
  value = local.deploy_cert_manager
}

output "deploy_external_secrets" {
  value = local.deploy_external_secrets
}

output "deploy_grafana" {
  value = local.deploy_grafana
}

output "deploy_keycloak" {
  value = local.deploy_keycloak
}

output "deploy_kyverno" {
  value = local.deploy_kyverno
}

output "deploy_loki" {
  value = local.deploy_loki
}

output "deploy_rancher" {
  value = local.deploy_rancher
}

output "deploy_rancher_cleanup" {
  value = local.deploy_rancher_cleanup
}

output "deploy_traefik" {
  value = local.deploy_traefik
}

output "deploy_velero" {
  value = local.deploy_velero
}

output "deploy_twistlock" {
  value = local.deploy_twistlock
}

output "deploy_mission_planner" {
  value = local.deploy_mission_planner
}

output "mission_planner_helm_version" {
  value = local.mission_planner_helm_version
}

output "up_node_selector" {
  value = local.up_node_selector
}

output "include_warpdrive_idp" {
  value = local.include_warpdrive_idp
}

output "velero_backup_schedule_enabled" {
  value = local.velero_backup_schedule_enabled
}

output "grafana_local_admin_enabled" {
  value = local.grafana_local_admin_enabled
}
