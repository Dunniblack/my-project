resource "null_resource" "always_run" {
  triggers = {
    timestamp = "${timestamp()}"
  }
}

locals {
  keycloak_idp_config = jsondecode(data.azurerm_key_vault_secret.keycloak_idp_config.value)
}

data "azurerm_key_vault_secret" "ingress_ips" {
  name         = "ingress-ips"
  key_vault_id = module.resources.c1_key_vault.id
}

resource "local_file" "bootstrap-yml" {
  filename = "../../argo-app/bootstrap.yml"
  content = templatefile(
    "${path.module}/templates/argo-app/bootstrap.yml", {
      namespace                       = local.argocd_namespace
      helmRelease                     = local.helm_release
      globalHelmRepoURL               = local.helmRepoURL
      clusterBaseResourcesHelmVersion = data.external.versions.result["CLUSTER_BASE_RESOURCES_HELM_VERSION"]
      dockerRegistryCredentials       = local.docker_registry_creds
      host_overrides                  = replace(local.host_overrides, "\n", "\n                ")
      kubeApiServerEndpointIp         = var.aks_kube_api_server_endpoint_ip

      # Deploy Flags
      deployAlloy           = local.deploy_alloy
      deployArgocd          = local.deploy_argocd
      deployCertManager     = local.deploy_cert_manager
      deployExternalSecrets = local.deploy_external_secrets
      deployGrafana         = local.deploy_grafana
      deployKeycloak        = local.deploy_keycloak
      deployKyverno         = local.deploy_kyverno
      deployLoki            = local.deploy_loki
      deployRancher         = local.deploy_rancher
      deployTraefik         = local.deploy_traefik
      deployVelero          = local.deploy_velero
      deployTwistlock       = local.deploy_twistlock
      deployMissionPlanner  = local.deploy_mission_planner

      # Azure Values
      azureVaultUrl           = "https://${local.key_vault_name}.${local.key_vault_api_domain}"
      azureGlobalVaultUrl     = "https://${module.resources.c1_key_vault.name}.${local.key_vault_api_domain}"
      azureTenantId           = module.resources.azure_config.tenant_id
      azureSubscriptionId     = var.subscription_id
      certificateName         = "tls-cert"
      aksManagedResourceGroup = local.resource_group_name_aks_node
      azureAdReadOnlyGroupIds = var.read_only_aad_group_ids

      # Kyverno Values
      kyvernoHelmVersion         = data.external.versions.result["KYVERNO_HELM_VERSION"]
      kyvernoPoliciesHelmVersion = data.external.versions.result["KYVERNO_POLICIES_HELM_VERSION"]
      kyvernoDockerRegistry      = "${local.registry_domain}${local.docker_folder}${local.infra_tools_folder}"
      allowedImageRegistries     = "${local.registry_domain}/*"
      allowedImageRegistryIp     = "${element(split(",", local.repo_ips), -1)}"

      # Cert Manager Values
      certManagerHelmVersion = data.external.versions.result["CERT_MANAGER_HELM_VERSION"]
      certManagetDockerRepo  = "${local.registry_domain}${local.docker_folder}${local.infra_tools_folder}"

      # External Secrets Values
      externalSecretsHelmVersion = data.external.versions.result["EXTERNAL_SECRETS_HELM_VERSION"]
      externalSecretsDockerRepo  = "${local.registry_domain}${local.docker_folder}${local.infra_tools_folder}/external-secrets"
      esoWorkIdentityClientId    = module.resources.eso_managed_identity.client_id

      # Traefik Values
      traefikHelmVersion            = data.external.versions.result["TRAEFIK_HELM_VERSION"]
      traefikDockerRegistry         = local.registry_domain
      traefikDockerRepo             = trim(format("%s%s%s", local.docker_folder, local.infra_tools_folder, "/traefik"), "/")
      traefikTrustedIPs             = "${data.azurerm_key_vault_secret.ingress_ips.value}"
      traefikInternalIP             = local.traefik_internal_ip
      traefikExternalIngressEnabled = local.traefik_external_ingress_enabled
      traefikPipName                = "aks-pip-${lower(var.environment_name)}"
      traefikPipResourceGroup       = local.default_resource_group

      # Keycloak Values
      keycloakHelmVersion                = data.external.versions.result["NOMS_INFRASTRUCTURE_HELM_VERSION"]
      keycloakExternalHost               = local.keycloak_domain
      keycloakDockerRegistry             = "${local.registry_domain}${local.docker_folder}/noms"
      keycloakSamlDisplayName            = local.keycloak_idp_config["displayName"]
      keycloakSamlSpEntityId             = lookup(local.keycloak_idp_config, "spEntityId", null)
      keycloakSamlIdpEntityId            = local.keycloak_idp_config["idpEntityId"]
      keycloakSamlSingleSignOnServiceUrl = local.keycloak_idp_config["singleSignOnServiceUrl"]
      keycloakSamlAllowedCIDRs           = join(",", local.keycloak_idp_config["allowedCIDRs"])
      keycloakSamlSingleLogoutServiceUrl = lookup(local.keycloak_idp_config, "singleLogoutServiceUrl", null)
      keycloakSamlSigningCertificate     = local.keycloak_idp_config["signingCertificate"]
      keycloakSamlEncryptionPublicKey    = lookup(local.keycloak_idp_config, "encryptionPublicKey", null)
      keycloakSamlPrincipalType          = local.keycloak_idp_config["principalType"]
      keycloakSamlPrincipalAttribute     = lookup(local.keycloak_idp_config, "principalAttribute", null)
      keycloakSamlFirstNameAttribute     = local.keycloak_idp_config["firstNameAttribute"]
      keycloakSamlLastNameAttribute      = local.keycloak_idp_config["lastNameAttribute"]
      keycloakSamlEmailAttribute         = lookup(local.keycloak_idp_config, "emailAttribute", null)
      keycloakSamlUsernameAttribute      = lookup(local.keycloak_idp_config, "usernameAttribute", null)

      # Grafana Alloy Values
      alloyHelmVersion = data.external.versions.result["ALLOY_HELM_VERSION"]

      # ArgoCD Values
      argocdHelmVersion   = data.external.versions.result["ARGOCD_HELM_VERSION"]
      argocdExternalHost  = local.argo_domain
      argocdDockerRepo    = local.argocd_repo
      argocdDockerVersion = local.argocd_tag
      redisDockerRepo     = local.redis_repo
      redisDockerVersion  = local.redis_tag
      repoServerEgressIPs = local.repo_ips
      argoAllowedDomains  = local.repo_domains
      argoAllowedIPs      = local.repo_ips

      # Grafana/Prometheus Values
      grafanaHelmVersion              = data.external.versions.result["GRAFANA_HELM_VERSION"]
      grafanaExternalHost             = local.grafana_domain
      grafanaDefaultDockerRegistry    = "${local.registry_domain}${local.docker_folder}${local.infra_tools_folder}"
      grafanaDefaultDockerRepoSubpath = local.opensource_folder
      grafanaLocalAdminEnabled        = local.grafana_local_admin_enabled
      alpineDockerRegistry            = "${local.registry_domain}${local.ironbank_folder}"

      # Loki Values
      lokiHelmVersion            = data.external.versions.result["LOKI_HELM_VERSION"]
      lokiDockerRegistry         = local.registry_domain
      lokiDockerRepo             = trim(format("%s%s/%s", local.docker_folder, local.infra_tools_folder, "loki"), "/")
      lokiStorageAccount         = module.name-map.loki_storage_account_name
      lokiStorageManagedIdentity = module.resources.loki_managed_identity.client_id
      lokiSidecarDockerRegistry  = local.registry_domain
      lokiSidecarDockerRepo      = trim(format("%s%s/%s", local.docker_folder, local.infra_tools_folder, "k8s-sidecar"), "/")

      # Rancher Values
      rancherCleanupEnabled        = local.deploy_rancher_cleanup
      rancherHelmVersion           = data.external.versions.result["RANCHER_HELM_VERSION"]
      rancherExternalHost          = local.rancher_domain
      rancherDefaultDockerRegistry = local.registry_domain

      # Twistlock/Prisma Cloud Values
      twistlockHelmVersion            = data.external.versions.result["TWISTLOCK_HELM_VERSION"]
      twistlockExternalHost           = local.prismacloud_domain
      twistlockConsoleDockerRepo      = "${local.registry_domain}${local.docker_folder}${local.infra_tools_folder}/console"
      twistlockDefenderDockerRepo     = "${local.registry_domain}${local.docker_folder}${local.infra_tools_folder}/defender"
      twistlockInitDockerRepo         = "${local.registry_domain}${local.docker_folder}${local.infra_tools_folder}/base"
      twistlockTrustedRegistry        = local.registry_domain
      twistlockEmailEgressEnabled     = local.twistlock_email_egress_enabled
      twistlockInternalAllowedIps     = local.twistlock_internal_allowed_ips
      twistlockExternalAllowedDomains = local.twistlock_external_allowed_domains
      twistlockHostStigIds            = local.twistlock_host_stig_ids
      twistlockContainerStigIds       = local.twistlock_container_stig_ids

      # Velero Values
      veleroHelmVersion           = data.external.versions.result["VELERO_HELM_VERSION"]
      veleroDockerRepo            = "${local.registry_domain}${local.docker_folder}${local.infra_tools_folder}/velero"
      veleroAzurePluginDockerRepo = "${local.registry_domain}${local.docker_folder}${local.infra_tools_folder}/velero-plugin-for-microsoft-azure"
      kubectlDockerRepo           = "${local.registry_domain}${local.docker_folder}${local.infra_tools_folder}/kubectl"
      veleroBackupScheduleEnabled = local.velero_backup_schedule_enabled
      veleroBackupResourceGroup   = local.default_resource_group
      veleroBackupStorageAccount  = module.name-map.velero_storage_account_name
      veleroBackupManagedIdentity = module.resources.velero_managed_identity.client_id

      # Missions Planner Values
      missionPlannerHelmChart   = "wp-server-b1-il5"
      missionPlannerHelmVersion = try(local.mission_planner_helm_version, data.external.versions.result["MISSION_PLANNER_HELM_VERSION"])
      missionPlannerHelmRepoUrl = (
        (
          var.enclave == "c1" &&
          contains(["prod"], lower(var.environment_name))
        ) ?
        local.helmRepoURL :
        local.helm_oci_repo
      )
      missionPlannerName           = "cd1"
      missionPlannerDeployment     = "blue"
      missionPlannerExternalHost   = local.keycloak_domain
      missionPlannerNodeSelector   = local.up_node_selector
      missionPlannerDockerRegistry = "${local.registry_domain}${local.docker_folder}/noms"
      includeWarpdriveIdp          = local.include_warpdrive_idp
    }
  )
  lifecycle {
    replace_triggered_by = [
      null_resource.always_run
    ]
  }
}
