resource "null_resource" "git_push" {
  provisioner "local-exec" {
    command = "${abspath(path.root)}/../../scripts/ps/terraform/Push-GitRepo.ps1"
    environment = {
      ENCLAVE           = var.enclave
      WORKSPACE         = lower(var.environment_name)
      GIT_SSL_NO_VERIFY = "true"
      WORKING_DIR       = abspath(path.root)
    }
    interpreter = ["PowerShell", "-Command"]
  }
  lifecycle {
    replace_triggered_by = [
      null_resource.always_run
    ]
  }
  depends_on = [
    local_file.bootstrap-yml,
  ]
}
