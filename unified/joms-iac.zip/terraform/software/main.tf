terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.58.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 3.0.1"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 3.1.1"
    }
    external = {
      source  = "hashicorp/external"
      version = "~> 2.3.5"
    }
  }
  backend "azurerm" {
    access_key = "{{ ARM_ACCESS_KEY }}"
  }
}

provider "azurerm" {
  subscription_id                 = var.subscription_id
  storage_use_azuread             = true
  resource_provider_registrations = (var.enclave == "wdsf") ? "none" : "all"
  metadata_host                   = "${var.metadata_host}/"
  features {}
}

provider "helm" {
  kubernetes = {
    config_path = "${local.bin_path}/kubeconfig"
  }
}

data "terraform_remote_state" "az" {
  backend = "azurerm"
  config = {
    resource_group_name  = var.tfstate_resource_group
    storage_account_name = var.tfstate_storage_account
    container_name       = var.tfstate_container
    key = (
      (var.enclave == "wdsf") ?
      "${var.tfstate_key}env:${var.environment_name}" :
      var.tfstate_key
    )
    access_key = "{{ ARM_ACCESS_KEY }}"
  }
}

locals {
  infra_tfstate_key = replace(
    var.tfstate_key,
    "software/",
    "infrastructure/"
  )
}

data "terraform_remote_state" "infrastructure" {
  backend = "azurerm"
  config = {
    resource_group_name  = var.tfstate_resource_group
    storage_account_name = var.tfstate_storage_account
    container_name       = var.tfstate_container
    key = (
      (var.enclave == "wdsf") ?
      "${local.infra_tfstate_key}env:${var.environment_name}" :
      local.infra_tfstate_key
    )
    access_key = "{{ ARM_ACCESS_KEY }}"
  }
}

data "terraform_remote_state" "global" {
  backend = "azurerm"
  config = {
    resource_group_name  = var.tfstate_resource_group
    storage_account_name = var.tfstate_storage_account
    container_name       = var.tfstate_container
    key = (
      (var.enclave == "wdsf") ?
      "global/Global.tfstateenv:Global" :
      "global/Global.tfstate"
    )
    access_key = "{{ ARM_ACCESS_KEY }}"
  }
}

module "name-map" {
  source = "../modules/name-map"

  environment_name = var.environment_name
  parent_module    = var.parent_module
  stage            = var.stage
  project          = var.project
  c1_project       = var.c1_project
  functional_area  = var.functional_area
  location         = var.location
  impact_level     = var.impact_level
}

module "resources" {
  source = "../modules/resources"

  resource_group_name = var.vnet_resource_group_name
  vnet_name           = var.vnet_name
  subnet_name         = var.subnet_name

  cmnsvc_resource_group_name = var.cmnsvc_resource_group_name
  cmnsvc_vnet_name           = var.cmnsvc_vnet_name
  cmnsvc_subnet_name         = var.cmnsvc_subnet_name

  core_key_vault_name    = var.core_key_vault_name
  kv_resource_group_name = var.kv_resource_group_name

  log_analytics_workspace_name = var.log_analytics_workspace_name
  la_resource_group_name       = var.la_resource_group_name

  automation_account_name = var.automation_account_name
  aa_resource_group_name  = var.aa_resource_group_name

  mi_resource_group_name = var.mi_resource_group_name
  mi_velero_name         = var.mi_velero_name
  mi_loki_name           = var.mi_loki_name
  mi_eso_name            = var.mi_eso_name
}

data "external" "versions" {
  program = ["powershell", "${abspath(path.root)}/../../scripts/ps/terraform/Get-Versions.ps1"]
}
