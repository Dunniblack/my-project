locals {
  default_resource_group = var.aks_resource_group_name
  global_resource_group = var.global_resource_group_name
  resource_group_name_aks_node = "${local.default_resource_group}-${var.environment_name}-node-01"
  key_vault_name = try (
    data.terraform_remote_state.infrastructure.outputs.key_vault_name,
    lower(module.name-map.key_vault_name)
  )
  key_vault_api_domain = replace(
    var.metadata_host,
    "management.",
    "vault."
  )
  bin_path = (
    (var.enclave == "wdsf") ?
    "${abspath(path.root)}/../.." :
    "${abspath(path.root)}/../../.."
  )

}

data "azurerm_kubernetes_cluster" "default" {
  name                = module.name-map.aks_name
  resource_group_name = local.default_resource_group
}

provider "kubernetes" {
  host                   = data.azurerm_kubernetes_cluster.default.kube_config.0.host
  cluster_ca_certificate = base64decode(data.azurerm_kubernetes_cluster.default.kube_config.0.cluster_ca_certificate)

  exec {
    api_version = "client.authentication.k8s.io/v1beta1"
    args        = ["get-token", "--login", "azurecli", "--server-id", var.aks_server_id]
    command     = "${local.bin_path}/kubelogin.exe"
  }
}
