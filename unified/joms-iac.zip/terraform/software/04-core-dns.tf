data "azurerm_key_vault_secret" "hosts-override" {
  name         = "hosts-override"
  key_vault_id = module.resources.c1_key_vault.id
}

# Get the domain name of the Key Vault
data "azurerm_key_vault" "default" {
  name                = local.key_vault_name
  resource_group_name = local.default_resource_group
}

# Get the Private IP address of the Key Vault
data "azurerm_private_endpoint_connection" "keyvault_default" {
  name                = "${lower(var.project)}-${lower(var.environment_name)}-kv-private-endpoint"
  resource_group_name = local.default_resource_group
}

locals {
  # In C1, we don't use the env_name as apart of the official Test/Prod domains
  suffix_doman = (
    (
      var.enclave == "c1" &&
      contains(["test", "prod"], lower(var.environment_name))
    ) ?
    ".${var.root_domain}" :
    "-${lower(module.name-map.environment_common_name)}.${var.root_domain}"
  )

  argo_domain        = "mps-argo${local.suffix_doman}"
  grafana_domain     = "mps-grafana${local.suffix_doman}"
  prismacloud_domain = "mps-prismacloud${local.suffix_doman}"
  rancher_domain     = "mps-rancher${local.suffix_doman}"
  keycloak_domain    = "mps${local.suffix_doman}"

  keyvault_private_ip = data.azurerm_private_endpoint_connection.keyvault_default.private_service_connection[0].private_ip_address
  keyvault_domain     = split("/", data.azurerm_key_vault.default.vault_uri)[2]

  custom_host_overrides = chomp(replace(
    data.azurerm_key_vault_secret.hosts-override.value,
    ",",
    "\r\n"
  ))

  host_overrides = <<-EOF
      ${local.custom_host_overrides}
      ${local.keyvault_private_ip} ${local.keyvault_domain}
      ${local.traefik_internal_ip} ${local.argo_domain}
      ${local.traefik_internal_ip} ${local.grafana_domain}
      ${local.traefik_internal_ip} ${local.prismacloud_domain}
      ${local.traefik_internal_ip} ${local.rancher_domain}
      ${local.traefik_internal_ip} ${local.keycloak_domain}
    EOF

  repo_ips = join(",",
    [
      for hosts_entry in split(",", data.azurerm_key_vault_secret.hosts-override.value) :
      element(split(" ", hosts_entry), 0)
    ]
  )
  repo_domains = join(",",
    [
      for hosts_entry in split(",", data.azurerm_key_vault_secret.hosts-override.value) :
      element(split(" ", hosts_entry), 1)
    ]
  )
  twistlock_internal_base_ips = [
    "10.244.0.0/16", # Pod CIDR
    "172.18.0.0/16", # Node Subnet
    "127.0.0.1",     # Loopback
    "10.0.0.0/16",   # Service CIDR
    "0.0.0.0/32"     # K8s Wildcard Bind address
  ]
  twistlock_external_allowed_ips = [
    # NOAA / Weather service
    # tgftp.nws.noaa.gov / tgftp.ncep.noaa.gov
    "140.172.138.79/32",
    # aviationweather.gov
    "13.107.246.40/32",
    "13.107.213.40/32",
    # api.weather.gov
    "23.48.203.233/32",
    "23.48.203.244/32",
    "23.39.174.164/32",
    "23.48.203.245/32",
    # nowcoast.noaa.gov
    "3.167.112.123/32",
    "3.167.112.89/32",
    "3.167.112.76/32",
    "3.167.112.86/32",
    # gisweather.afwa.af.mil
    # GCDS CIDRs
    "214.24.252.0/24",
    "214.48.0.0/16",
    "140.17.26.0/23",
    "140.17.112.0/23",
    "140.17.136.0/23",
    "140.17.144.0/23",
    # portal.fnmoc.navy.mil / portal-alpha.fnmoc.navy.mil
    "152.80.49.120/32",
    # nomads.ncep.noaa.gov uses Akamai CDN
    # Reference: https://www.weather.gov/media/notification/pdf2/scn20-13nomads_website.pdf
    # Akamai CDN CIDRs: https://techdocs.akamai.com/origin-ip-acl/docs/update-your-origin-server
    "2.16.0.0/13",
    "23.0.0.0/12",
    "23.192.0.0/11",
    "23.32.0.0/11",
    "95.100.0.0/15",
    "184.24.0.0/13",
    # intelligence.twistlock.com
    "104.155.181.42/32",
    # Microsoft / Azure / Defender
    # api.cloud.defender.microsoft.com
    "13.107.226.41/32",
    "13.107.253.41/32",
    # api.cloud.defender.azure.us
    "20.140.151.75/32",
    # data-uga.cloud.defender.azure.us
    "20.140.48.70/32",
    # *.ods.opinsights.azure.us
  ]
  twistlock_external_allowed_domains = join(",",
    [
      # NOAA / Weather services
      "aviationweather.gov",
      "api.weather.gov",
      "tgftp.nws.noaa.gov",
      "tgftp.ncep.noaa.gov",
      "nowcoast.noaa.gov",
      "gisweather.afwa.af.mil",
      "portal.fnmoc.navy.mil",
      "portal-alpha.fnmoc.navy.mil",
      "nomads.ncep.noaa.gov",
      "portal-alpha.fnmoc.navy.mil",

      # Prisma Cloud / Twistlock
      "intelligence.twistlock.com",

      # Microsoft / Azure / Defender
      "*.ods.opinsights.azure.us",
      "api.cloud.defender.microsoft.com",
      "api.cloud.defender.azure.us",
      "data-uga.cloud.defender.azure.us",

      # AKS private endpoint
      "*.privatelink.usgovvirginia.cx.aks.containerservice.azure.us"
    ]
  )
  twistlock_internal_allowed_ips = join(",",
    compact(concat(
      local.twistlock_internal_base_ips,
      local.twistlock_external_allowed_ips
    ))
  )
}

resource "kubernetes_config_map_v1_data" "coredns-custom" {
  metadata {
    name      = "coredns-custom"
    namespace = "kube-system"
  }

  data = {
    "test.override" = <<-EOF
        hosts {
          ${local.host_overrides}
          fallthrough
        }
        EOF
  }

  lifecycle {
    ignore_changes = [data]
  }
}
