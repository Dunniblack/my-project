resource "kubernetes_storage_class_v1" "aks-fileshare" {
  metadata {
    name = "azurefile"
  }
  allow_volume_expansion =  true
  storage_provisioner    = "file.csi.azure.com"
  reclaim_policy         = "Delete"
  volume_binding_mode    = "Immediate"
  parameters = {
    skuName        = "Standard_LRS"
    storageAccount = module.name-map.aks_fileshare_storage_account_name
    resourceGroup  = local.default_resource_group
  }
  mount_options = [
    "mfsymlinks",
    "actimeo=30",
    "nosharesock"
  ]

  lifecycle {
    ignore_changes = [
      metadata
    ]
  }

  depends_on = [
    null_resource.remove-existing-aks-fileshare,
  ]
}

resource "null_resource" "remove-existing-aks-fileshare" {
  provisioner "local-exec" {
    command     = "& \"$($env:BIN_DIR)/kubectl\" -n kube-system delete storageclass azurefile"
    interpreter = ["PowerShell", "-Command"]
    environment = {
      KUBECONFIG = "${local.bin_path}/kubeconfig"
      BIN_DIR    = "${local.bin_path}"
    }
  }
}