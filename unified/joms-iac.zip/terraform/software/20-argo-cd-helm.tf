locals {
  docker_folder      = "/docker-dev-share"
  infra_tools_folder = "/infra-tools"
  ironbank_folder    = "/ironbank"
  opensource_folder  = "opensource/"
  helmRepoURL        = "https://${local.registry_domain}/repository/private-mvcr-asset/${local.helm_folder}"

  argocd_repo = "${local.registry_domain}${local.docker_folder}${local.infra_tools_folder}/argocd"
  argocd_tag  = "3.2.1"
  redis_repo  = "${local.registry_domain}${local.docker_folder}${local.infra_tools_folder}/redis"
  redis_tag   = "8.3.2"

  twistlock_email_egress_enabled = coalesce(
    var.twistlock_email_egress_enabled,
    try(
      data.terraform_remote_state.az.outputs.twistlock_email_egress_enabled,
      contains(["test", "prod"], var.stage)
    )
  )
  twistlock_host_stig_ids      = "8212,8311,81427,81428,8214,8227,8115,8116,8118,81122,81123,81129,82112,81141"
  twistlock_container_stig_ids = "41,54,5525,59,515,516,517,520,530,55,57,5510,5511,599"
}

resource "helm_release" "argo-cd" {
  name             = local.helm_release
  chart            = (
    (var.enclave == "wdsf") ?
    "${local.bin_path}/argo-cd/" :
    "${local.bin_path}/../argo-cd/"
  )
  namespace        = local.argocd_namespace
  create_namespace = false
  atomic           = true
  timeout          = 300

  values = [
    templatefile("${path.module}/templates/helm-values/argo-cd.yml", {
      argoRepository  = local.argocd_repo
      argoTag         = local.argocd_tag
      redisRepository = local.redis_repo
      redisTag        = local.redis_tag
    })
  ]

  set = (
    [
      {
        name  = "global.imagePullSecrets[0].name"
        value = "image-pull-credentials"
        type  = "string"
      }
    ]
  )

  depends_on = [
    kubernetes_config_map_v1_data.coredns-custom,
    kubernetes_secret_v1.image-pull-credentials,
  ]

  lifecycle {
    ignore_changes = [
      chart,
      values,
    ]
  }
}
