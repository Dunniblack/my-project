# Variables for Azure resources

variable "environment_name" {
  description = "The name of the Environment"
  type        = string

  validation {
    condition     = length(var.environment_name) <= 5
    error_message = "The environment_name value must not exceed 5 characters."
  }
}

variable "parent_module" {
  description = "The name of the Parent Terraform Module."
  type        = string
}

variable "stage" {
  description = "The stage of the Environment (dev, test, prod)"
  type        = string
}

variable "project" {
  description = "The Project Name"
  type        = string
  default     = "JOMS"
}

variable "c1_project" {
  description = "The C1 Project Name"
  type        = string
  default     = "JOMSMVP"
}

variable "enclave" {
  description = "The enclave that we're executing the logic (i.e. 'wdsf', 'c1')."
  type        = string
  default     = "c1"
  validation {
    condition     = contains(["wdsf", "c1", "thundercamp"], var.enclave)
    error_message = "The enclave  must be one of the follwing: \"wdsf\", \"c1\", \"thundercamp\""
  }
}

variable "functional_area" {
  description = "The Functional Area of the environment (AFMC)"
  type        = string
  default     = "AFMC"
}

variable "location" {
  description = "The Azure location where resources will be created."
  type        = string
  default     = "USGov Virginia"
}

variable "subscription_id" {
  description = "The Subscription ID for Azure."
  type        = string
}

variable "global_resource_group_name" {
  description = "The name of the Global Resource Group."
  type        = string
  default     = ""
}

variable "aks_resource_group_name" {
  description = "The name of the AKS Resource Group."
  type        = string
}

variable "tfstate_resource_group" {
  description = "The name of the TF State Resource Group."
  type        = string
}

variable "tfstate_storage_account" {
  description = "The name of the TF State Storage Account."
  type        = string
}

variable "tfstate_container" {
  description = "The name of the TF State Container."
  type        = string
}

variable "tfstate_key" {
  description = "The name of the TF State Key."
  type        = string
}

variable "vnet_resource_group_name" {
  description = "The name of the VNet Resource Group."
  type        = string
}

variable "vnet_name" {
  type        = string
  description = "The Virtual Network Name."
}

variable "subnet_name" {
  type        = string
  description = "The Subnet Name."
}

variable "cmnsvc_vnet_name" {
  type        = string
  description = "The Virtual Network Name of the C1 Common Services."
}

variable "cmnsvc_resource_group_name" {
  description = "The name of the Resource Group of the C1 Common Services."
  type        = string
}

variable "cmnsvc_subnet_name" {
  type        = string
  description = "The Subnet Nameo f the C1 Common Services"
}

variable "acr_private_endpoint_name" {
  type        = string
  description = "The name respective ACR Private Endpoint associated with the VNet."
  default     = null
}

variable "core_key_vault_name" {
  type        = string
  description = "The C1 Key Vault Name."
}

variable "kv_resource_group_name" {
  type        = string
  description = "The name of the C1 Key Vault Resource Group."
}

variable "log_analytics_workspace_name" {
  type        = string
  description = "The Log Analytics Workspace Name."
}

variable "la_resource_group_name" {
  type        = string
  description = "The name of the C1 Log Analytics Workspace Resource Group."
}

variable "automation_account_name" {
  type        = string
  description = "The C1 Automation Account Name."
}

variable "aa_resource_group_name" {
  type        = string
  description = "The name of the C1 Automation Account Resource Group."
}

variable "admin_aad_group_ids" {
  description = "CSV list of Azure Active Directory Group IDs of Admin Users."
  type        = string
  default     = ""
}

variable "read_only_aad_group_ids" {
  description = "CSV list of Azure Active Directory Group ID of Read Only Users."
  type        = string
  default     = ""
}

variable "aks_server_id" {
  description = "The AKS Cluster Server Id."
  type        = string
  default     = null
}

variable "aks_argo_cd_deployed" {
  description = "True/False falg to determine if the AKS Cluster has Argo CD deployed."
  type        = bool
  default     = false
}

variable "aks_kube_api_server_endpoint_ip" {
  description = "IP address of the AKS Kubernetes API Server Endpoint"
  type        = string
}

variable "impact_level" {
  description = "The IL5/IL6 deployment."
  type        = string
  default     = "IL5"
}

variable "metadata_host" {
  description = "Metadata_host endpoint."
  type        = string
  default     = "management.usgovcloudapi.net"
}

variable "root_domain" {
  description = "Root domain to use for DNS entries."
  type        = string
}

variable "traefik_internal_ip" {
  description = "Traefik Internal IP to allocate."
  type        = string
  default     = null
}

variable "traefik_external_ingress_enabled" {
  description = "True/False flag to determine if Traefik external ingress is enabled."
  type        = bool
  default     = null
}

variable "twistlock_email_egress_enabled" {
  description = "True/False flag to determine if Prisma Email Egress is enabled."
  type        = bool
  default     = null
}

variable "mi_velero_name" {
  type        = string
  description = "User assigned managed identity for velero."
  default     = ""
}

variable "mi_loki_name" {
  type        = string
  description = "User assigned managed identity for loki."
  default     = ""
}

variable "mi_eso_name" {
  type        = string
  description = "User assigned managed identity for external secrets."
  default     = ""
}

variable "mi_resource_group_name" {
  type        = string
  description = "Resource group for the managed identities."
  default     = ""
}

variable "helm_release" {
  type        = string
  description = "Helm release name to deploy Mgmt Tools."
  default     = null
}

variable "helm_folder" {
  type        = string
  description = "Helm Registry folder to pull the Helm Charts from. (Only Applies to WDSF deployments.)"
  default     = null
}

variable "deploy_alloy" {
  type        = bool
  description = "True/False flag to determine if we want to deploy Alloy."
  default     = null
}

variable "deploy_argocd" {
  type        = bool
  description = "True/False flag to determine if we want to deploy ArgoCD."
  default     = null
}

variable "deploy_cert_manager" {
  type        = bool
  description = "True/False flag to determine if we want to deploy Cert Manager."
  default     = null
}

variable "deploy_external_secrets" {
  type        = bool
  description = "True/False flag to determine if we want to deploy External Secrets."
  default     = null
}

variable "deploy_grafana" {
  type        = bool
  description = "True/False flag to determine if we want to deploy Grafana and Prometheus."
  default     = null
}

variable "deploy_keycloak" {
  type        = bool
  description = "True/False flag to determine if we want to deploy Keycloak (Standalone)."
  default     = null
}

variable "deploy_kyverno" {
  type        = bool
  description = "True/False flag to determine if we want to deploy Keyverno."
  default     = null
}

variable "deploy_loki" {
  type        = bool
  description = "True/False flag to determine if we want to deploy Loki."
  default     = null
}

variable "deploy_rancher" {
  type        = bool
  description = "True/False flag to determine if we want to deploy Rancher."
  default     = null
}

variable "deploy_rancher_cleanup" {
  type        = bool
  description = "True/False flag to determine if we want to deploy Rancher Cleanup."
  default     = null
}

variable "deploy_traefik" {
  type        = bool
  description = "True/False flag to determine if we want to deploy Traefik."
  default     = null
}

variable "deploy_velero" {
  type        = bool
  description = "True/False flag to determine if we want to deploy Velero."
  default     = null
}

variable "deploy_twistlock" {
  type        = bool
  description = "True/False flag to determine if we want to deploy Twistlock (PrismaCloud)."
  default     = null
}

variable "deploy_mission_planner" {
  type        = bool
  description = "True/False flag to determine if we want to deploy Mission Planner (MPS)."
  default     = null
}

variable "include_warpdrive_idp" {
  type        = bool
  description = "True/False flag to determine if we want to add F5 SAML option in keycloak"
  default     = null
}

variable "velero_backup_schedule_enabled" {
  type        = bool
  description = "True/False flag to determine if we want Velero backups enabled"
  default     = null
}

variable "mission_planner_helm_version" {
  type        = string
  description = "Helm version of the Mission Planner Helm chart (Default: '*-0')"
  default     = null
}

variable "up_node_selector" {
  type        = string
  description = "Node Selector to use when deploying Unified Planner/Mission Planner."
  default     = null
}

variable "grafana_local_admin_enabled" {
  description = "Enable/Disable Grafana local admin login for troubleshooting."
  type        = bool
  default     = null
}
