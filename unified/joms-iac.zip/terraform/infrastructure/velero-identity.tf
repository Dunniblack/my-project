resource "azurerm_federated_identity_credential" "velero" {
  count               = var.mi_velero_name != "" ? 1 : 0
  name                = "aks-${lower(var.environment_name)}-velero-federated-identity"
  resource_group_name = var.mi_resource_group_name
  audience            = ["api://AzureADTokenExchange"]
  issuer              = azurerm_kubernetes_cluster.default.oidc_issuer_url
  parent_id           = module.resources.velero_managed_identity.id
  subject             = "system:serviceaccount:velero:${local.helm_release}-velero-server"
}
