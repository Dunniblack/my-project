
resource "tls_private_key" "ssh" {
  algorithm = "RSA"
  rsa_bits  = 4096
}

resource "azurerm_key_vault_secret" "ssh_private" {
  name         = "ssh-private-key"
  value        = tls_private_key.ssh.private_key_openssh
  key_vault_id = azurerm_key_vault.default.id

  tags = merge(
    module.tags.common_tags,
    { Service = "key-vault-secret" }
  )

  depends_on = [
    azurerm_key_vault_access_policy.service_principal,
    azurerm_private_dns_a_record.keyvault,
    module.invoke_runbook_post_kv_privte_link,
  ]
}

resource "azurerm_key_vault_secret" "ssh_public" {
  name         = "ssh-public-key"
  value        = tls_private_key.ssh.public_key_openssh
  key_vault_id = azurerm_key_vault.default.id

  tags = merge(
    module.tags.common_tags,
    { Service = "key-vault-secret" }
  )

  depends_on = [
    azurerm_key_vault_access_policy.service_principal,
    azurerm_private_dns_a_record.keyvault,
    module.invoke_runbook_post_kv_privte_link,
  ]
}
