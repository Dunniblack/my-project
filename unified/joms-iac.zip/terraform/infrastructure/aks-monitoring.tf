# Creating Data Collection Endpoint
resource "azurerm_monitor_data_collection_endpoint" "aks_dce" {
  count  = local.stream_logs == true ? 1 : 0
  name                = "${module.name-map.aks_name}-dce"
  resource_group_name = var.aks_resource_group_name
  location            = var.location
  kind                = "Linux"
}

# Creating Data Collection Rule for ContainerLogV2
resource "azurerm_monitor_data_collection_rule" "aks_dcr_v2" {
  count  = local.stream_logs == true ? 1 : 0
  name                        = "${module.name-map.aks_name}-dcr-v2"
  resource_group_name         = var.aks_resource_group_name
  location                    = var.location
  data_collection_endpoint_id = azurerm_monitor_data_collection_endpoint.aks_dce[0].id

  data_sources {
    extension {
      name           = "ContainerInsights"
      streams        = ["Microsoft-ContainerLogV2"]
      extension_name = "AzureMonitor-Containers"
    }
  }
  destinations {
    log_analytics {
      name                  = "log-analytics-destination"
      workspace_resource_id = module.resources.c1_log_analytics_workspace.id
    }
  }
  data_flow {
    destinations = ["log-analytics-destination"]
    streams      = ["Microsoft-ContainerLogV2"]
  }
}

# Link the Data Collection Rule to the AKS cluster
resource "azurerm_monitor_data_collection_rule_association" "aks_association" {
  count  = local.stream_logs == true ? 1 : 0
  name                    = "${module.name-map.aks_name}-dcr-assoc"
  target_resource_id      = azurerm_kubernetes_cluster.default.id
  data_collection_rule_id = azurerm_monitor_data_collection_rule.aks_dcr_v2[0].id
  description             = "Association of Data Collection Rule to AKS cluster for ContainerLogV2"
  depends_on = [
    azurerm_kubernetes_cluster.default
  ]
}

resource "null_resource" "enable_aks_monitoring" {
  count  = local.stream_logs == true ? 1 : 0
  depends_on = [
    azurerm_kubernetes_cluster_node_pool.all,
    azurerm_monitor_data_collection_rule.aks_dcr_v2,
    azurerm_monitor_data_collection_rule_association.aks_association,
    azurerm_monitor_data_collection_endpoint.aks_dce
  ]
  provisioner "local-exec" {
    command = format("%s%s%s%s",
      "${abspath(path.root)}/../../scripts/ps/terraform/Enable-AksMonitoring.ps1",
      " -resourceGroupName $env:resourceGroupName",
      " -aksClusterName $env:aksClusterName",
      " -workspaceResourceId $env:workspaceResourceId"
    )
    environment = {
      resourceGroupName   = var.aks_resource_group_name
      aksClusterName      = module.name-map.aks_name
      workspaceResourceId = module.resources.c1_log_analytics_workspace.id
    }
    interpreter = ["PowerShell", "-Command"]
  }
}
