resource "null_resource" "create_public_ip" {
  count = local.traefik_external_ingress_enabled ? 1 : 0

  provisioner "local-exec" {
    command = format("%s%s%s",
      "${abspath(path.root)}/../../scripts/ps/terraform/Create-PublicIp.ps1",
      " -publicIpName $env:PUBLIC_IP_NAME",
      " -resourceGroupName $env:RESOURCE_GROUP"
    )
    environment = {
      PUBLIC_IP_NAME = "aks-pip-${lower(var.environment_name)}"
      RESOURCE_GROUP = local.default_resource_group
    }
    interpreter = ["PowerShell", "-Command"]
  }
}
