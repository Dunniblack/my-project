
resource "azurerm_dedicated_host_group" "default" {
  count                       = contains(["prod", "test"], var.stage) ? 1 : 0
  name                        = module.name-map.dedicated_host_group
  resource_group_name         = var.mi_resource_group_name
  location                    = var.location
  platform_fault_domain_count = 2
  automatic_placement_enabled = true

  tags = merge(
    module.tags.common_tags,
    { Service = "dedicated-host-group" }
  )
}

resource "azurerm_dedicated_host" "default" {
  count                   = contains(["prod", "test"], var.stage) ? 1 : 0
  name                    = module.name-map.dedicated_host
  location                = var.location
  dedicated_host_group_id = azurerm_dedicated_host_group.default.0.id
  sku_name                = "DDSv4-Type1"
  platform_fault_domain   = 1

  tags = merge(
    module.tags.common_tags,
    { Service = "dedicated-host" }
  )
}
