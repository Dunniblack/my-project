output "kubernetes_version" {
  value = local.kubernetes_version
}

output "aks_node_resource_group" {
  value = azurerm_kubernetes_cluster.default.node_resource_group
}

output "aks_resource_group_name" {
  value = local.default_resource_group
}

output "invoke_runbook_post_kv_privte_link" {
  value = local.invoke_runbook_post_kv_privte_link
}

output "invoke_runbook_post_aks_cluster" {
  value = local.invoke_runbook_post_aks_cluster
}

output "invoke_runbook_post_aks_cluster_kms_setup" {
  value = local.invoke_runbook_post_aks_cluster_kms_setup
}

output "aks_cluster_name" {
  value = module.name-map.aks_name
}

output "aks_node_pool_map" {
  value = local.aks_node_pool_map
}

output "aks_enable_ssh" {
  value = local.aks_enable_ssh
}

output "aks_use_kmsv2" {
  value = local.aks_use_kmsv2
}

output "key_vault_name" {
  value = module.name-map.key_vault_name
}

output "key_vault_id" {
  value = azurerm_key_vault.default.id
}

output "key_vault_unique_id" {
  value = local.key_vault_unique_id
}

output "kv_secret_twistlock_license" {
  value = local.kv_secret_twistlock_license
}

output "helm_release" {
  value = local.helm_release
}

output "stream_logs" {
  value = local.stream_logs
}

output "traefik_external_ingress_enabled" {
  value = local.traefik_external_ingress_enabled
}