resource "azurerm_key_vault_key" "disk_encryption_set" {
  name         = module.name-map.disk_encryption_set_key_name
  key_vault_id = azurerm_key_vault.default.id
  key_type     = "RSA"
  key_size     = 2048

  rotation_policy {
    automatic {
      time_before_expiry = "P30D"
    }

    expire_after         = "P90D"
    notify_before_expiry = "P29D"
  }

  key_opts = [
    "decrypt",
    "encrypt",
    "sign",
    "unwrapKey",
    "verify",
    "wrapKey",
  ]

  tags = merge(
    module.tags.common_tags,
    { Service = "key-vault-key" }
  )

  depends_on = [
    azurerm_key_vault_access_policy.service_principal,
    azurerm_private_dns_a_record.keyvault,
    module.invoke_runbook_post_kv_privte_link,
  ]
}

resource "azurerm_disk_encryption_set" "default" {
  name                      = module.name-map.disk_encryption_set_name
  resource_group_name       = local.default_resource_group
  location                  = var.location
  key_vault_key_id          = azurerm_key_vault_key.disk_encryption_set.versionless_id
  auto_key_rotation_enabled = true

  identity {
    type = "SystemAssigned"
  }

  tags = merge(
    module.tags.common_tags,
    { Service = "disk-encryption-set" }
  )
}

resource "azurerm_key_vault_access_policy" "disk-encryption-access" {
  key_vault_id = azurerm_key_vault.default.id

  tenant_id = azurerm_disk_encryption_set.default.identity[0].tenant_id
  object_id = azurerm_disk_encryption_set.default.identity[0].principal_id

  key_permissions = [
    "Create",
    "Delete",
    "Get",
    "Purge",
    "Recover",
    "Update",
    "List",
    "Decrypt",
    "Sign",
    "UnwrapKey",
    "WrapKey",
  ]
}
