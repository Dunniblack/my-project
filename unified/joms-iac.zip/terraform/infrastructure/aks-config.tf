locals {
  bin_path = (
    (var.enclave == "wdsf" || var.enclave == "thundercamp") ?
    "${abspath(path.root)}/../.." :
    "${abspath(path.root)}/../../.."
  )
}

provider "kubernetes" {
  host = (
    (var.aks_use_service_principal) ?
    azurerm_kubernetes_cluster.default.kube_config.0.host :
    try(
      azurerm_kubernetes_cluster.default.kube_admin_config.0.host,
      ""
    )
  )
  cluster_ca_certificate = (
    (var.aks_use_service_principal) ?
    base64decode(azurerm_kubernetes_cluster.default.kube_config.0.cluster_ca_certificate) :
    try(
      base64decode(azurerm_kubernetes_cluster.default.kube_admin_config.0.cluster_ca_certificate),
      ""
    )
  )
  client_certificate = (
    (var.aks_use_service_principal) ?
    null :
    try(
      base64decode(azurerm_kubernetes_cluster.default.kube_admin_config.0.client_certificate),
      ""
    )
  )
  client_key = (
    (var.aks_use_service_principal) ?
    null :
    try(
      base64decode(azurerm_kubernetes_cluster.default.kube_admin_config.0.client_key),
      ""
    )
  )

  dynamic "exec" {
    for_each = (var.aks_use_service_principal) ? [{}] : []
    content {
      api_version = "client.authentication.k8s.io/v1beta1"
      args        = ["get-token", "--login", "azurecli", "--server-id", var.aks_server_id]
      command     = "${local.bin_path}/kubelogin.exe"
    }
  }
}

resource "kubernetes_cluster_role_binding_v1" "sp-admin" {
  metadata {
    name = "aks-admin-binding-sp"
  }
  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "ClusterRole"
    name      = "cluster-admin"
  }
  subject {
    kind      = "User"
    name      = module.resources.azure_config.object_id
    api_group = "rbac.authorization.k8s.io"
  }

  depends_on = [
    module.invoke_runbook_post_aks_cluster,
  ]
}
