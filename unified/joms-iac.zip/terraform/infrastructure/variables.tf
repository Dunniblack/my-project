# Variables for Azure resources

variable "environment_name" {
  description = "The name of the Environment"
  type        = string

  validation {
    condition     = length(var.environment_name) <= 5
    error_message = "The environment_name value must not exceed 5 characters."
  }
}

variable "parent_module" {
  description = "The name of the Parent Terraform Module."
  type        = string
}

variable "stage" {
  description = "The stage of the Environment (dev, test, prod)"
  type        = string
}

variable "project" {
  description = "The Project Name"
  type        = string
  default     = "JOMS"
}

variable "c1_project" {
  description = "The C1 Project Name"
  type        = string
  default     = "JOMSMVP"
}

variable "enclave" {
  description = ""
  type        = string
  default     = "c1"
  validation {
    condition     = contains(["wdsf", "c1", "thundercamp"], var.enclave)
    error_message = "The enclave  must be one of the follwing: \"wdsf\", \"c1\", \"thundercamp\""
  }
}

variable "functional_area" {
  description = "The Functional Area of the environment (AFMC)"
  type        = string
  default     = "AFMC"
}

variable "location" {
  description = "The Azure location where resources will be created."
  type        = string
  default     = "USGov Virginia"
}

variable "subscription_id" {
  description = "The Subscription ID for Azure."
  type        = string
}

variable "global_resource_group_name" {
  description = "The name of the Global Resource Group."
  type        = string
  default     = ""
}

variable "aks_resource_group_name" {
  description = "The name of the AKS Resource Group."
  type        = string
}

variable "tfstate_resource_group" {
  description = "The name of the TF State Resource Group."
  type        = string
}

variable "tfstate_storage_account" {
  description = "The name of the TF State Storage Account."
  type        = string
}

variable "tfstate_container" {
  description = "The name of the TF State Container."
  type        = string
}

variable "tfstate_key" {
  description = "The name of the TF State Key."
  type        = string
}

variable "vnet_resource_group_name" {
  description = "The name of the VNet Resource Group."
  type        = string
}

variable "vnet_name" {
  type        = string
  description = "The Virtual Network Name."
}

variable "subnet_name" {
  type        = string
  description = "The Subnet Name."
}

variable "cmnsvc_resource_group_name" {
  description = "The name of the Resource Group of the C1 Common Services."
  type        = string
}

variable "cmnsvc_vnet_name" {
  type        = string
  description = "The Virtual Network Name of the C1 Common Services."
}

variable "cmnsvc_subnet_name" {
  type        = string
  description = "The Subnet Name of the C1 Common Services"
}

variable "cmnsvc_location" {
  type        = string
  description = "The Location of the C1 Common Services"
  default     = "USDoD East"
}

variable "core_key_vault_name" {
  type        = string
  description = "The C1 Key Vault Name."
}

variable "kv_resource_group_name" {
  type        = string
  description = "The name of the C1 Key Vault Resource Group."
}

variable "kv_secret_twistlock_license" {
  type        = string
  description = "The name of the Key Vault Secret that holds the Twistlock License Key."
  default     = null
}

variable "log_analytics_workspace_name" {
  type        = string
  description = "The C1 Log Analytics Workspace Name."
}

variable "la_resource_group_name" {
  type        = string
  description = "The name of the C1 Log Analytics Workspace Resource Group."
}

variable "stream_logs" {
  description = "True/False flag to determine if logs will stream to the Log Analytics Workspace."
  type        = bool
  default     = null
}

variable "automation_account_name" {
  type        = string
  description = "The C1 Automation Account Name."
}

variable "aa_resource_group_name" {
  type        = string
  description = "The name of the C1 Automation Account Resource Group."
}

variable "admin_aad_group_ids" {
  description = "CSV list of Azure Active Directory Group IDs of Admin Users."
  type        = string
}

variable "read_only_aad_group_ids" {
  description = "CSV list of Azure Active Directory Group ID of Read Only Users."
  type        = string
  default     = ""
}

variable "mi_kubelet_name" {
  type        = string
  description = "User assigned managed identity for kublet."
  default     = ""
}

variable "mi_control_plane_name" {
  type        = string
  description = "User assigned managed identity for control plane."
  default     = ""
}

variable "mi_loki_name" {
  type        = string
  description = "User assigned managed identity for Loki."
  default     = ""
}

variable "mi_eso_name" {
  type        = string
  description = "User assigned managed identity for External Secrets."
  default     = ""
}

variable "mi_velero_name" {
  type        = string
  description = "User assigned managed identity for velero."
  default     = ""
}

variable "mi_resource_group_name" {
  type        = string
  description = "Resource group for the managed identities."
  default     = ""
}

variable "key_vault_unique_id" {
  description = "The unique Key Vault Identifier to name the resource."
  type        = string
  default     = null
}

variable "kubernetes_version" {
  description = "The version of the Azure Kubernetes Service Resource."
  type        = string
  default     = null
}

variable "aks_use_service_principal" {
  description = "True/False flag to determine if to use the Service Prinicipal to connect to the AKS Cluster."
  type        = bool
  default     = false
}

variable "aks_server_id" {
  description = "The AKS Cluster Server Id."
  type        = string
  default     = null
}

variable "aks_node_pool_map" {
  description = "Map of AKS Cluster Node Pools to deploy."
  type        = map
  default     = null
}

variable "node_pool_enabled_overrides" {
  description = "Map of Node Pools to enable"
  type        = map(bool)
  default     = {}
}

variable "aks_enable_ssh" {
  description = "True/False flag to determine if SSH is enabled on AKS."
  type        = string
  default     = null
}

variable "invoke_runbook_post_kv_privte_link" {
  description = "Triggers runbook post KV private link."
  type        = string
  default     = null
}

variable "invoke_runbook_post_aks_cluster" {
  description = "Triggers runbook post AKS cluster creation."
  type        = string
  default     = null
}

variable "invoke_runbook_post_aks_cluster_kms_setup" {
  description = "Triggers runbook post AKS cluster KMSv2 setup."
  type        = string
  default     = null
}

variable "impact_level" {
  description = "The IL5/IL6 deployment."
  type        = string
  default     = "IL5"
}

variable "api_server_subnet_name" {
  description = "Api Server Subnet name"
  type        = string
  default     = ""
}

variable "metadata_host" {
  description = "Metadata_host endpoint"
  type        = string
  default     = "management.usgovcloudapi.net"
}

variable "aks_kmsv2_setup" {
  description = "Value to check KMS setup status."
  type        = bool
}

variable "aks_use_kmsv2" {
  description = "Boolean value to determine if to run kms block in aks.tf."
  type        = bool
  default     = null
}

variable "helm_release" {
  type        = string
  description = "Helm release name to deploy Mgmt Tools."
  default     = null
}

variable "traefik_external_ingress_enabled" {
  description = "True/False falg to determine if Traefik external ingress is enabled."
  type        = bool
  default     = null
}
