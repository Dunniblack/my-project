terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.58.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 3.0.1"
    }
  }
  backend "azurerm" {
    access_key = "{{ ARM_ACCESS_KEY }}"
  }
}

provider "azurerm" {
  subscription_id                 = var.subscription_id
  storage_use_azuread             = true
  resource_provider_registrations = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? "none" : "all"
  metadata_host                   = "${var.metadata_host}/"
  features {}
}

data "terraform_remote_state" "az" {
  backend = "azurerm"
  config = {
    resource_group_name  = var.tfstate_resource_group
    storage_account_name = var.tfstate_storage_account
    container_name       = var.tfstate_container
    key = (
      (var.enclave == "wdsf" || var.enclave == "thundercamp") ?
      "${var.tfstate_key}env:${var.environment_name}" :
      var.tfstate_key
    )
    access_key = "{{ ARM_ACCESS_KEY }}"
  }
}

module "name-map" {
  source = "../modules/name-map"

  environment_name    = var.environment_name
  parent_module       = var.parent_module
  stage               = var.stage
  project             = var.project
  c1_project          = var.c1_project
  functional_area     = var.functional_area
  location            = var.location
  key_vault_unique_id = local.key_vault_unique_id
  impact_level        = var.impact_level
}


module "tags" {
  source = "../modules/tags"

  enclave          = var.enclave
  parent_module    = var.parent_module
  environment_name = var.environment_name
}

module "resources" {
  source = "../modules/resources"

  resource_group_name = var.vnet_resource_group_name
  vnet_name           = var.vnet_name
  subnet_name         = var.subnet_name

  cmnsvc_resource_group_name = var.cmnsvc_resource_group_name
  cmnsvc_vnet_name           = var.cmnsvc_vnet_name
  cmnsvc_subnet_name         = var.cmnsvc_subnet_name

  core_key_vault_name    = var.core_key_vault_name
  kv_resource_group_name = var.kv_resource_group_name

  log_analytics_workspace_name = var.log_analytics_workspace_name
  la_resource_group_name       = var.la_resource_group_name

  automation_account_name = var.automation_account_name
  aa_resource_group_name  = var.aa_resource_group_name

  mi_resource_group_name = var.mi_resource_group_name
  mi_kubelet_name        = var.mi_kubelet_name
  mi_control_plane_name  = var.mi_control_plane_name
  mi_velero_name         = var.mi_velero_name
  mi_loki_name           = var.mi_loki_name
  mi_eso_name            = var.mi_eso_name

  api_server_subnet_name = var.api_server_subnet_name
}

module "invoke_runbook_post_kv_privte_link" {
  for_each = toset([local.invoke_runbook_post_kv_privte_link])
  source   = "../modules/invoke-runbook"

  enclave                 = var.enclave
  automation_account_name = var.automation_account_name
  aa_resource_group_name  = var.aa_resource_group_name

  depends_on = [
    azurerm_private_dns_a_record.keyvault
  ]
}

module "invoke_runbook_post_aks_cluster" {
  for_each = toset([local.invoke_runbook_post_aks_cluster])
  source   = "../modules/invoke-runbook"

  enclave                 = var.enclave
  automation_account_name = var.automation_account_name
  aa_resource_group_name  = var.aa_resource_group_name

  depends_on = [
    azurerm_kubernetes_cluster.default,
    azurerm_kubernetes_cluster_node_pool.all,
  ]
}

module "enable_kmsv2_function" {
  count  = local.aks_use_kmsv2 == true ? 1 : 0
  source = "../modules/enable-kmsv2"

  resource_group_name   = local.default_resource_group
  aks_cluster_name      = azurerm_kubernetes_cluster.default.name
  api_server_subnet_id  = module.resources.api_server_subnet.0.id
  key_vault_resource_id = azurerm_key_vault.default.id
  key_vault_kms_key_id  = azurerm_key_vault_key.aks_kms_key.id
  aks_kmsv2_setup       = var.aks_kmsv2_setup

  depends_on = [
    module.invoke_runbook_post_aks_cluster
  ]
}

module "invoke_runbook_post_aks_cluster_kms_setup" {
  for_each = toset([local.invoke_runbook_post_aks_cluster_kms_setup])
  source   = "../modules/invoke-runbook"

  enclave                 = var.enclave
  automation_account_name = var.automation_account_name
  aa_resource_group_name  = var.aa_resource_group_name

  depends_on = [
    module.enable_kmsv2_function
  ]
}
