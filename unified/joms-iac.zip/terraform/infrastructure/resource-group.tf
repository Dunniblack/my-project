locals {
  default_resource_group = var.aks_resource_group_name
  global_resource_group = var.global_resource_group_name
  resource_group_name_aks_node = "${local.default_resource_group}-${var.environment_name}-node-01"
}
