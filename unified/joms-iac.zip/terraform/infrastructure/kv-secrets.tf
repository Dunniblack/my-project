# Copy the Twistlock License Secret from the Global KV to the AKS Key Vault
data "azurerm_key_vault_secret" "twistlock-license" {
  name         = local.kv_secret_twistlock_license
  key_vault_id = module.resources.c1_key_vault.id
}

resource "azurerm_key_vault_secret" "twistlock-license" {
  name         = "twistlock-license"
  value        = data.azurerm_key_vault_secret.twistlock-license.value
  key_vault_id = azurerm_key_vault.default.id

  tags = merge(
    module.tags.common_tags,
    { Service = "keyvault-secret" }
  )

  depends_on = [
    azurerm_key_vault_access_policy.service_principal,
    azurerm_private_dns_a_record.keyvault,
    module.invoke_runbook_post_kv_privte_link,
  ]
}
