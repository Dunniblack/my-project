data "azurerm_key_vault_secret" "sp_app_id" {
  name         = "spAppId"
  key_vault_id = module.resources.c1_key_vault.id
}

data "azurerm_key_vault_secret" "sp_app_key" {
  name         = "spAppKey"
  key_vault_id = module.resources.c1_key_vault.id
}


resource "azurerm_kubernetes_cluster" "default" {
  name                = module.name-map.aks_name
  location            = var.location
  resource_group_name = local.default_resource_group
  node_resource_group = local.resource_group_name_aks_node

  automatic_upgrade_channel = "stable"
  #Cost analysis can only be enabled on a cluster with a system assigned or user assigned managed identity.
  cost_analysis_enabled               = false
  disk_encryption_set_id              = azurerm_disk_encryption_set.default.id
  dns_prefix                          = lower(module.name-map.aks_name)
  image_cleaner_enabled               = true
  image_cleaner_interval_hours        = 24
  kubernetes_version                  = local.kubernetes_version
  local_account_disabled              = var.aks_use_service_principal
  node_os_upgrade_channel             = "NodeImage"
  oidc_issuer_enabled                 = true
  open_service_mesh_enabled           = false
  private_cluster_enabled             = true
  private_dns_zone_id                 = "System"
  private_cluster_public_fqdn_enabled = false
  workload_identity_enabled           = true
  role_based_access_control_enabled   = true
  run_command_enabled                 = true
  sku_tier                            = "Premium"
  support_plan                        = "KubernetesOfficial"

  default_node_pool {
    name                    = "systempool"
    node_count              = 1
    vm_size                 = "Standard_D16ds_v4"
    host_encryption_enabled = true
    auto_scaling_enabled    = true
    max_count               = 3
    min_count               = 1
    scale_down_mode         = "Delete"
    node_public_ip_enabled  = false
    host_group_id           = try(azurerm_dedicated_host_group.default.0.id, null)
    fips_enabled            = true
    kubelet_disk_type       = "OS"
    max_pods                = 150
    node_labels = {
      "node" = "systempool"
    }
    only_critical_addons_enabled = false
    os_disk_size_gb              = 128
    os_sku                       = "AzureLinux"
    #NetworkPluginMode overlay cannot be used with PodSubnetID
    #pod_subnet_id                 = module.resources.subnet.id
    temporary_name_for_rotation = "tempname"
    type                        = "VirtualMachineScaleSets"
    #Availability zone is required for UltraSSD setting.
    ultra_ssd_enabled = false
    vnet_subnet_id    = module.resources.subnet.id
    workload_runtime  = "OCIContainer"

    upgrade_settings {
      drain_timeout_in_minutes      = 0
      max_surge                     = "10%"
      node_soak_duration_in_minutes = 0
    }

    #kubelet_config {}
    #linux_os_config {}
  }

  dynamic "service_principal" {
    for_each = (
      module.resources.control_plane_managed_identity == null &&
      module.resources.kubelet_managed_identity == null
    ) ? [1] : []
    content {
      client_id     = data.azurerm_key_vault_secret.sp_app_id.value
      client_secret = data.azurerm_key_vault_secret.sp_app_key.value
    }
  }

  dynamic "identity" {
    for_each = module.resources.control_plane_managed_identity != null ? [1] : []
    content {
      type = "UserAssigned"
      identity_ids = [
        module.resources.control_plane_managed_identity.id
      ]
    }
  }
  dynamic "kubelet_identity" {
    for_each = module.resources.kubelet_managed_identity != null ? [1] : []
    content {
      client_id                 = module.resources.kubelet_managed_identity.client_id
      object_id                 = module.resources.kubelet_managed_identity.principal_id
      user_assigned_identity_id = module.resources.kubelet_managed_identity.id
    }
  }

  azure_active_directory_role_based_access_control {
    azure_rbac_enabled     = true
    tenant_id              = module.resources.azure_config.tenant_id
    admin_group_object_ids = split(",", var.admin_aad_group_ids)
  }

  storage_profile {
    blob_driver_enabled         = true
    disk_driver_enabled         = true
    file_driver_enabled         = true
    snapshot_controller_enabled = true
  }

  # Vnet integration should be enabled when KeyVault network access is Private.
  dynamic "key_management_service" {
    for_each = (
      var.aks_kmsv2_setup == true &&
      local.aks_use_kmsv2 == true
    ) ? [1] : []
    content {
      key_vault_key_id         = azurerm_key_vault_key.aks_kms_key.id
      key_vault_network_access = "Private"
    }
  }

  key_vault_secrets_provider {
    secret_rotation_enabled  = true
    secret_rotation_interval = "1h"
  }

  network_profile {
    network_mode        = "transparent"
    network_plugin      = "azure"
    network_policy      = "cilium"
    network_data_plane  = "cilium"
    network_plugin_mode = "overlay"

    outbound_type     = "loadBalancer"
    load_balancer_sku = "standard"
    load_balancer_profile {
      #An argument named "backend_pool_type" is not expected here.
      #backend_pool_type         = "NodeIPConfiguration"
      idle_timeout_in_minutes   = 30
      managed_outbound_ip_count = 3
      outbound_ports_allocated  = 0
    }
  }

  dynamic "linux_profile" {
    for_each = (local.aks_enable_ssh) ? [1] : []
    content {
      admin_username = "sysadmin"
      ssh_key {
        key_data = chomp(tls_private_key.ssh.public_key_openssh)
      }
    }
  }

  microsoft_defender {
    log_analytics_workspace_id = module.resources.c1_log_analytics_workspace.id
  }

  maintenance_window {
    allowed {
      day   = "Sunday"
      hours = [7, 8, 9, 10] # EST 3-7AM
    }
  }
  maintenance_window_auto_upgrade {
    frequency   = "Weekly"
    interval    = 1
    duration    = 4
    day_of_week = "Sunday"
    start_time  = "07:00"
    utc_offset  = "+00:00"
  }
  maintenance_window_node_os {
    frequency   = "Weekly"
    interval    = 1
    duration    = 4
    day_of_week = "Sunday"
    start_time  = "07:00"
    utc_offset  = "+00:00"
  }

  #Private cluster cannot be enabled with AuthorizedIPRanges.
  #api_server_access_profile {
  #    authorized_ip_ranges = module.resources.vnet.address_space
  #}

  #OpenServiceMesh addon is incompatible with feature Azure Service Mesh.
  #service_mesh_profile {
  #  mode      = "Istio"
  #  revisions = ["asm-1-20"]
  #}

  #Application Gateway Ingress Controller addon is not supported with Azure CNI Overlay.
  #ingress_application_gateway {}

  depends_on = [
    azurerm_key_vault_access_policy.service_principal
  ]

  lifecycle {
    ignore_changes = [
      default_node_pool.0.node_count,
      kubernetes_version,
      oms_agent,
      api_server_access_profile,
    ]
  }

  tags = merge(
    module.tags.common_tags,
    { Service = "kubernetes-service" }
  )
}

resource "azurerm_kubernetes_cluster_node_pool" "all" {
  for_each = local.aks_node_pool_map

  name                        = each.key
  kubernetes_cluster_id       = azurerm_kubernetes_cluster.default.id
  vm_size                     = each.value.vm_size
  host_encryption_enabled     = true
  auto_scaling_enabled        = true
  max_count                   = each.value.max_count
  min_count                   = each.value.min_count
  scale_down_mode             = "Delete"
  node_public_ip_enabled      = false
  host_group_id               = each.value.use_dedicated_host ? try(azurerm_dedicated_host_group.default.0.id, null) : null
  fips_enabled                = true
  kubelet_disk_type           = "OS"
  max_pods                    = each.value.max_pods
  node_labels                 = each.value.node_labels
  node_taints                 = each.value.node_taints
  os_disk_size_gb             = each.value.os_disk_size_gb
  os_disk_type                = "Managed"
  os_sku                      = each.value.os_sku
  os_type                     = "Linux"
  #NetworkPluginMode overlay cannot be used with PodSubnetID
  #pod_subnet_id                 = module.resources.subnet.id
  #Availability zone is required for UltraSSD setting.
  temporary_name_for_rotation = "${substr(each.key, 0, 8)}temp"
  ultra_ssd_enabled           = false
  vnet_subnet_id              = module.resources.subnet.id
  workload_runtime            = "OCIContainer"

  upgrade_settings {
    drain_timeout_in_minutes      = 0
    max_surge                     = "10%"
    node_soak_duration_in_minutes = 0
  }

  #kubelet_config {}
  #linux_os_config {}

  tags = merge(
    module.tags.common_tags,
    { Service = "kubernetes-cluster-node-pool" }
  )
}


resource "azurerm_monitor_diagnostic_setting" "aks" {
  count                          = (local.stream_logs) ? 1 : 0
  name                           = "aks-diagnostics"
  target_resource_id             = azurerm_kubernetes_cluster.default.id
  log_analytics_workspace_id     = module.resources.c1_log_analytics_workspace.id
  log_analytics_destination_type = "Dedicated"

  # Enable logging for select categories
  enabled_log {
    category = "kube-audit"
  }
  enabled_log {
    category = "kube-apiserver"
  }
  enabled_log {
    category = "guard"
  }

  # Enable metrics for AllMetrics category
  metric {
    category = "AllMetrics"
  }
}
