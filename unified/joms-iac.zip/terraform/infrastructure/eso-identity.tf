locals {
  # Namespaces that pull AKV secrets
  eso_namespaces = [
    "argocd",
    "cd1-blue",
    "cd1-green",
    "ingress",
    "twistlock",
  ]
}

resource "azurerm_key_vault_access_policy" "eso-global-akv" {
  count = (
    contains(
      module.resources.c1_key_vault.access_policy[*].object_id,
      module.resources.eso_managed_identity.principal_id
    ) ? 0 : 1
  )

  key_vault_id = module.resources.c1_key_vault.id
  tenant_id    = module.resources.azure_config.tenant_id
  object_id    = module.resources.eso_managed_identity.principal_id

  secret_permissions = [
    "Get",
    "List",
  ]

  certificate_permissions = [
    "Get",
    "List",
  ]
}

resource "azurerm_key_vault_access_policy" "eso-local-akv" {
  key_vault_id = azurerm_key_vault.default.id
  tenant_id    = module.resources.azure_config.tenant_id
  object_id    = module.resources.eso_managed_identity.principal_id

  secret_permissions = [
    "Get",
    "List",
  ]

  certificate_permissions = [
    "Get",
    "List",
  ]
}

resource "azurerm_federated_identity_credential" "eso" {
  for_each = toset((var.mi_eso_name != "") ? local.eso_namespaces : [])

  name                = "aks-${lower(var.environment_name)}-eso-federated-identity-${each.key}"
  resource_group_name = var.mi_resource_group_name
  audience            = ["api://AzureADTokenExchange"]
  issuer              = azurerm_kubernetes_cluster.default.oidc_issuer_url
  parent_id           = module.resources.eso_managed_identity.id
  subject             = "system:serviceaccount:${each.key}:external-secrets-workload-id"
}
