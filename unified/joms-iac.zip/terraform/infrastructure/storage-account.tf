data "azurerm_key_vault_secret" "ingress_ips" {
  name         = "ingress-ips"
  key_vault_id = module.resources.c1_key_vault.id
}

resource "azurerm_storage_account" "sadus" {
  name                              = module.name-map.sadus_storage_account_name
  resource_group_name               = local.default_resource_group
  location                          = var.location
  account_kind                      = "StorageV2"
  account_tier                      = "Standard"
  account_replication_type          = "RAGRS"
  infrastructure_encryption_enabled = true
  allow_nested_items_to_be_public   = false
  https_traffic_only_enabled        = true
  min_tls_version                   = "TLS1_2"
  shared_access_key_enabled         = true
  public_network_access_enabled     = true
  default_to_oauth_authentication   = false
  local_user_enabled                = false
  dns_endpoint_type                 = "Standard"

  blob_properties {
    versioning_enabled       = true
    change_feed_enabled      = false
    last_access_time_enabled = true
    delete_retention_policy {
      days                     = 365
      permanent_delete_enabled = false
    }
  }

  network_rules {
    default_action = "Deny"
    bypass = [
      "Logging",
      "Metrics",
      "AzureServices"
    ]
    ip_rules = (
      (var.enclave == "wdsf" || var.enclave == "thundercamp") ?
      null :
      split(",", data.azurerm_key_vault_secret.ingress_ips.value)
    )
    virtual_network_subnet_ids = [
      module.resources.subnet.id,
      module.resources.cmnsvc_subnet.id,
    ]
  }

  identity {
    type = "SystemAssigned"
  }

  tags = merge(
    module.tags.common_tags,
    { Service = "storage-account" }
  )

  lifecycle {
    ignore_changes = [
      customer_managed_key
    ]
  }
}

resource "azurerm_storage_container" "sadus_container" {
  name                  = "sadus-pvc"
  storage_account_id    = azurerm_storage_account.sadus.id
  container_access_type = "private"

}

resource "azurerm_monitor_diagnostic_setting" "storage-account" {
  count                      = (local.stream_logs) ? 1 : 0
  name                       = "storage-account-diagnostics"
  target_resource_id         = azurerm_storage_account.sadus.id
  log_analytics_workspace_id = module.resources.c1_log_analytics_workspace.id

  metric {
    category = "Transaction"
  }

  lifecycle {
    ignore_changes = [
      metric
    ]
  }
}

resource "azurerm_monitor_diagnostic_setting" "storage-account-service" {
  for_each = toset((local.stream_logs ? ["blob", "queue", "table", "file"] : []))

  name                       = "storage-account-${each.key}-diagnostics"
  target_resource_id         = "${azurerm_storage_account.sadus.id}/${each.key}Services/default/"
  log_analytics_workspace_id = module.resources.c1_log_analytics_workspace.id

  enabled_log {
    category_group = "allLogs"
  }

  metric {
    category = "Transaction"
  }

  lifecycle {
    ignore_changes = [
      metric
    ]
  }
}

resource "azurerm_key_vault_access_policy" "sadus-storage" {
  key_vault_id = azurerm_key_vault.default.id
  tenant_id    = module.resources.azure_config.tenant_id
  object_id    = azurerm_storage_account.sadus.identity[0].principal_id

  secret_permissions = ["Get"]
  key_permissions = [
    "Get",
    "UnwrapKey",
    "WrapKey"
  ]
}

resource "azurerm_key_vault_key" "sadus-storage" {
  name         = "sadus-key"
  key_vault_id = azurerm_key_vault.default.id
  key_type     = "RSA"
  key_size     = 2048
  key_opts = [
    "decrypt",
    "encrypt",
    "sign",
    "unwrapKey",
    "verify",
    "wrapKey"
  ]

  depends_on = [
    azurerm_key_vault_access_policy.service_principal,
    azurerm_key_vault_access_policy.sadus-storage
  ]

  tags = merge(
    module.tags.common_tags,
    { Service = "keyvault-key" }
  )
}

resource "azurerm_storage_account_customer_managed_key" "sadus-storage" {
  storage_account_id = azurerm_storage_account.sadus.id
  key_vault_id       = azurerm_key_vault.default.id
  key_name           = azurerm_key_vault_key.sadus-storage.name
}


resource "azurerm_storage_account" "velero" {
  name                              = module.name-map.velero_storage_account_name
  resource_group_name               = local.default_resource_group
  location                          = var.location
  account_kind                      = "StorageV2"
  account_tier                      = "Standard"
  account_replication_type          = "RAGRS"
  infrastructure_encryption_enabled = true
  allow_nested_items_to_be_public   = false
  https_traffic_only_enabled        = true
  min_tls_version                   = "TLS1_2"
  shared_access_key_enabled         = true
  public_network_access_enabled     = true
  default_to_oauth_authentication   = false
  local_user_enabled                = false
  dns_endpoint_type                 = "Standard"

  blob_properties {
    versioning_enabled       = true
    change_feed_enabled      = false
    last_access_time_enabled = true
    delete_retention_policy {
      days                     = 365
      permanent_delete_enabled = false
    }
  }

  network_rules {
    default_action = "Deny"
    bypass = [
      "Logging",
      "Metrics",
      "AzureServices"
    ]
    ip_rules = (
      (var.enclave == "wdsf" || var.enclave == "thundercamp") ?
      null :
      split(",", data.azurerm_key_vault_secret.ingress_ips.value)
    )
    virtual_network_subnet_ids = [
      module.resources.subnet.id,
      module.resources.cmnsvc_subnet.id,
    ]
  }

  identity {
    type = "SystemAssigned"
  }

  tags = merge(
    module.tags.common_tags,
    { Service = "storage-account" }
  )

  lifecycle {
    ignore_changes = [
      customer_managed_key
    ]
  }
}

resource "azurerm_storage_container" "velero" {
  name                  = "velero"
  storage_account_id    = azurerm_storage_account.velero.id
  container_access_type = "private"

}

resource "azurerm_monitor_diagnostic_setting" "velero-storage-account" {
  count                      = (local.stream_logs) ? 1 : 0
  name                       = "velero-storage-account-diagnostics"
  target_resource_id         = azurerm_storage_account.velero.id
  log_analytics_workspace_id = module.resources.c1_log_analytics_workspace.id

  metric {
    category = "Transaction"
  }

  lifecycle {
    ignore_changes = [
      metric
    ]
  }
}

resource "azurerm_monitor_diagnostic_setting" "velero-storage-account-service" {
  for_each = toset((local.stream_logs ? ["blob", "queue", "table", "file"] : []))

  name                       = "velero-storage-account-${each.key}-diagnostics"
  target_resource_id         = "${azurerm_storage_account.velero.id}/${each.key}Services/default/"
  log_analytics_workspace_id = module.resources.c1_log_analytics_workspace.id

  enabled_log {
    category_group = "allLogs"
  }

  metric {
    category = "Transaction"
  }

  lifecycle {
    ignore_changes = [
      metric
    ]
  }
}

resource "azurerm_key_vault_access_policy" "velero-storage" {
  key_vault_id = azurerm_key_vault.default.id
  tenant_id    = module.resources.azure_config.tenant_id
  object_id    = azurerm_storage_account.velero.identity[0].principal_id

  secret_permissions = ["Get"]
  key_permissions = [
    "Get",
    "UnwrapKey",
    "WrapKey"
  ]
}

resource "azurerm_key_vault_key" "velero-storage" {
  name         = "velero-key"
  key_vault_id = azurerm_key_vault.default.id
  key_type     = "RSA"
  key_size     = 2048
  key_opts = [
    "decrypt",
    "encrypt",
    "sign",
    "unwrapKey",
    "verify",
    "wrapKey"
  ]

  depends_on = [
    azurerm_key_vault_access_policy.service_principal,
    azurerm_key_vault_access_policy.velero-storage
  ]

  tags = merge(
    module.tags.common_tags,
    { Service = "keyvault-key" }
  )
}

resource "azurerm_storage_account_customer_managed_key" "velero-storage" {
  storage_account_id = azurerm_storage_account.velero.id
  key_vault_id       = azurerm_key_vault.default.id
  key_name           = azurerm_key_vault_key.velero-storage.name
}


resource "azurerm_storage_account" "aks-fileshare" {
  name                              = module.name-map.aks_fileshare_storage_account_name
  resource_group_name               = local.default_resource_group
  location                          = var.location
  account_kind                      = "StorageV2"
  account_tier                      = "Standard"
  account_replication_type          = "LRS"
  infrastructure_encryption_enabled = true
  allow_nested_items_to_be_public   = false
  https_traffic_only_enabled        = true
  min_tls_version                   = "TLS1_2"
  shared_access_key_enabled         = true
  public_network_access_enabled     = true
  default_to_oauth_authentication   = false
  local_user_enabled                = false
  dns_endpoint_type                 = "Standard"

  blob_properties {
    versioning_enabled       = true
    change_feed_enabled      = false
    last_access_time_enabled = true
    delete_retention_policy {
      days                     = 365
      permanent_delete_enabled = false
    }
  }

  share_properties {
    retention_policy {
      days = 365
    }
  }

  network_rules {
    default_action = "Deny"
    bypass = [
      "Logging",
      "Metrics",
      "AzureServices"
    ]
    ip_rules = (
      (var.enclave == "wdsf" || var.enclave == "thundercamp") ?
      null :
      split(",", data.azurerm_key_vault_secret.ingress_ips.value)
    )
    virtual_network_subnet_ids = [
      module.resources.subnet.id,
      module.resources.cmnsvc_subnet.id,
    ]
  }

  identity {
    type = "SystemAssigned"
  }

  tags = merge(
    module.tags.common_tags,
    { Service = "storage-account" }
  )

  lifecycle {
    ignore_changes = [
      customer_managed_key,
    ]
  }
}

resource "azurerm_monitor_diagnostic_setting" "aks-fileshare-storage-account" {
  count                      = (local.stream_logs) ? 1 : 0
  name                       = "aks-fileshare-storage-account-diagnostics"
  target_resource_id         = azurerm_storage_account.aks-fileshare.id
  log_analytics_workspace_id = module.resources.c1_log_analytics_workspace.id

  metric {
    category = "Transaction"
  }

  lifecycle {
    ignore_changes = [
      metric
    ]
  }
}

resource "azurerm_monitor_diagnostic_setting" "aks-fileshare-storage-account-service" {
  for_each = toset((local.stream_logs ? ["blob", "queue", "table", "file"] : []))

  name                       = "aks-fileshare-storage-account-${each.key}-diagnostics"
  target_resource_id         = "${azurerm_storage_account.aks-fileshare.id}/${each.key}Services/default/"
  log_analytics_workspace_id = module.resources.c1_log_analytics_workspace.id

  enabled_log {
    category_group = "allLogs"
  }

  metric {
    category = "Transaction"
  }

  lifecycle {
    ignore_changes = [
      metric
    ]
  }
}

resource "azurerm_key_vault_access_policy" "aks-fileshare-storage" {
  key_vault_id = azurerm_key_vault.default.id
  tenant_id    = module.resources.azure_config.tenant_id
  object_id    = azurerm_storage_account.aks-fileshare.identity[0].principal_id

  secret_permissions = ["Get"]
  key_permissions = [
    "Get",
    "UnwrapKey",
    "WrapKey"
  ]
}

resource "azurerm_key_vault_key" "aks-fileshare-storage" {
  name         = "aks-fileshare-key"
  key_vault_id = azurerm_key_vault.default.id
  key_type     = "RSA"
  key_size     = 2048
  key_opts = [
    "decrypt",
    "encrypt",
    "sign",
    "unwrapKey",
    "verify",
    "wrapKey"
  ]

  depends_on = [
    azurerm_key_vault_access_policy.service_principal,
    azurerm_key_vault_access_policy.aks-fileshare-storage
  ]

  tags = merge(
    module.tags.common_tags,
    { Service = "keyvault-key" }
  )
}

resource "azurerm_storage_account_customer_managed_key" "aks-fileshare-storage" {
  storage_account_id = azurerm_storage_account.aks-fileshare.id
  key_vault_id       = azurerm_key_vault.default.id
  key_name           = azurerm_key_vault_key.aks-fileshare-storage.name
}


resource "azurerm_storage_account" "loki" {
  name                              = module.name-map.loki_storage_account_name
  resource_group_name               = local.default_resource_group
  location                          = var.location
  account_kind                      = "StorageV2"
  account_tier                      = "Standard"
  account_replication_type          = "RAGRS"
  infrastructure_encryption_enabled = true
  allow_nested_items_to_be_public   = false
  https_traffic_only_enabled        = true
  min_tls_version                   = "TLS1_2"
  shared_access_key_enabled         = true
  public_network_access_enabled     = true
  default_to_oauth_authentication   = false
  local_user_enabled                = false
  dns_endpoint_type                 = "Standard"

  blob_properties {
    versioning_enabled       = true
    change_feed_enabled      = false
    last_access_time_enabled = true
    delete_retention_policy {
      days                     = 365
      permanent_delete_enabled = false
    }
  }

  network_rules {
    default_action = "Deny"
    bypass = [
      "Logging",
      "Metrics",
      "AzureServices"
    ]
    ip_rules = (
      (var.enclave == "wdsf" || var.enclave == "thundercamp") ?
      null :
      split(",", data.azurerm_key_vault_secret.ingress_ips.value)
    )
    virtual_network_subnet_ids = [
      module.resources.subnet.id,
      module.resources.cmnsvc_subnet.id,
    ]
  }

  identity {
    type = "SystemAssigned"
  }

  tags = merge(
    module.tags.common_tags,
    { Service = "storage-account" }
  )

  lifecycle {
    ignore_changes = [
      customer_managed_key
    ]
  }
}

resource "azurerm_storage_container" "loki" {
  name                  = "loki"
  storage_account_id    = azurerm_storage_account.loki.id
  container_access_type = "private"

}

resource "azurerm_storage_container" "loki-chunks" {
  name                  = "chunks"
  storage_account_id    = azurerm_storage_account.loki.id
  container_access_type = "private"

}

resource "azurerm_storage_container" "loki-ruler" {
  name                  = "ruler"
  storage_account_id    = azurerm_storage_account.loki.id
  container_access_type = "private"

}

resource "azurerm_monitor_diagnostic_setting" "loki-storage-account" {
  count                      = (local.stream_logs) ? 1 : 0
  name                       = "loki-storage-account-diagnostics"
  target_resource_id         = azurerm_storage_account.loki.id
  log_analytics_workspace_id = module.resources.c1_log_analytics_workspace.id

  metric {
    category = "Transaction"
  }

  lifecycle {
    ignore_changes = [
      metric
    ]
  }
}

resource "azurerm_monitor_diagnostic_setting" "loki-storage-account-service" {
  for_each = toset((local.stream_logs ? ["blob", "queue", "table", "file"] : []))

  name                       = "loki-storage-account-${each.key}-diagnostics"
  target_resource_id         = "${azurerm_storage_account.loki.id}/${each.key}Services/default/"
  log_analytics_workspace_id = module.resources.c1_log_analytics_workspace.id

  enabled_log {
    category_group = "allLogs"
  }

  metric {
    category = "Transaction"
  }

  lifecycle {
    ignore_changes = [
      metric
    ]
  }
}

resource "azurerm_key_vault_access_policy" "loki-storage" {
  key_vault_id = azurerm_key_vault.default.id
  tenant_id    = module.resources.azure_config.tenant_id
  object_id    = azurerm_storage_account.loki.identity[0].principal_id

  secret_permissions = ["Get"]
  key_permissions = [
    "Get",
    "UnwrapKey",
    "WrapKey"
  ]
}

resource "azurerm_key_vault_key" "loki-storage" {
  name         = "loki-key"
  key_vault_id = azurerm_key_vault.default.id
  key_type     = "RSA"
  key_size     = 2048
  key_opts = [
    "decrypt",
    "encrypt",
    "sign",
    "unwrapKey",
    "verify",
    "wrapKey"
  ]

  depends_on = [
    azurerm_key_vault_access_policy.service_principal,
    azurerm_key_vault_access_policy.loki-storage
  ]

  tags = merge(
    module.tags.common_tags,
    { Service = "keyvault-key" }
  )
}

resource "azurerm_storage_account_customer_managed_key" "loki-storage" {
  storage_account_id = azurerm_storage_account.loki.id
  key_vault_id       = azurerm_key_vault.default.id
  key_name           = azurerm_key_vault_key.loki-storage.name
}
