locals {
  key_vault_unique_id = coalesce(
    var.key_vault_unique_id,
    try(
      data.terraform_remote_state.az.outputs.key_vault_unique_id,
      "0001"
    )
  )
  kv_secret_twistlock_license = coalesce(
    var.kv_secret_twistlock_license,
    try(
      data.terraform_remote_state.az.outputs.kv_secret_twistlock_license,
      "twistlock-license"
    )
  )
  kubernetes_version = coalesce(
    var.kubernetes_version,
    try(
      data.terraform_remote_state.az.outputs.kubernetes_version,
      "1.34"
    )
  )
  invoke_runbook_post_kv_privte_link = coalesce(
    var.invoke_runbook_post_kv_privte_link,
    try(
      data.terraform_remote_state.az.outputs.invoke_runbook_post_kv_privte_link,
      "0"
    )
  )
  invoke_runbook_post_aks_cluster = coalesce(
    var.invoke_runbook_post_aks_cluster,
    try(
      data.terraform_remote_state.az.outputs.invoke_runbook_post_aks_cluster,
      "0"
    )
  )
  invoke_runbook_post_aks_cluster_kms_setup = coalesce(
    var.invoke_runbook_post_aks_cluster_kms_setup,
    try(
      data.terraform_remote_state.az.outputs.invoke_runbook_post_aks_cluster_kms_setup,
      "0"
    )
  )
  aks_node_pools = {
    blue01 = {
      enabled            = true
      vm_size            = "Standard_D16ds_v4"
      max_count          = 3
      min_count          = 1
      max_pods           = 150
      os_disk_size_gb    = 256
      os_sku             = "AzureLinux"
      use_dedicated_host = true
      node_labels = {
        "node-pool" = "blue01",
        "noms"      = "blue01"
      }
      node_taints = [
        "node-pool=blue01:NoSchedule",
        "noms=blue01:NoSchedule"
      ]
    },
    overflow01 = {
      enabled            = contains(["prod", "test"], var.stage)
      vm_size            = "Standard_E80ids_v4"
      max_count          = 3
      min_count          = 0
      max_pods           = 250
      os_disk_size_gb    = 256
      os_sku             = "AzureLinux"
      use_dedicated_host = false
      node_labels = {
        "node-pool" = "overflow01",
        "noms"      = "blue01"
      }
      node_taints = ["tier=overflow:PreferNoSchedule"]
    }
  }
  aks_node_pool_map = {
    for key, value in local.aks_node_pools : key => value
    if lookup(var.node_pool_enabled_overrides, key, value.enabled)
  }
  aks_use_kmsv2 = coalesce(
    var.aks_use_kmsv2,
    try(
      data.terraform_remote_state.az.outputs.aks_use_kmsv2,
      true
    )
  )
  aks_enable_ssh = coalesce(
    var.aks_enable_ssh,
    try(
      data.terraform_remote_state.az.outputs.aks_enable_ssh,
      contains(["test", "prod"], var.stage) ? false : true
    )
  )
  helm_release = coalesce(
    var.helm_release,
    try(
      data.terraform_remote_state.az.outputs.helm_release,
      "core-app"
    )
  )
  stream_logs = coalesce(
    var.stream_logs,
    try(
      data.terraform_remote_state.az.outputs.stream_logs,
      contains(["test", "prod"], var.stage) ? true : false
    )
  )
  traefik_external_ingress_enabled = coalesce(
    var.traefik_external_ingress_enabled,
    try(
      data.terraform_remote_state.az.outputs.traefik_external_ingress_enabled,
      contains(["test", "prod"], var.stage) ? true : false
    )
  )
}
