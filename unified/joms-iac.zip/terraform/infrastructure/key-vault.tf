resource "azurerm_key_vault" "default" {
  name                = module.name-map.key_vault_name
  location            = var.location
  resource_group_name = local.default_resource_group
  tenant_id           = module.resources.azure_config.tenant_id
  sku_name            = "premium" # Premium SKU for HSM (Hardware Security Modules) and advanced features

  # NIST 800-53: Protect against accidental deletion
  purge_protection_enabled = true

  soft_delete_retention_days = (
    contains(["prod", "test"], var.stage) ?
    90 :
    7
  )

  # NIST 800-53: Encryption at Rest using Azure Managed Keys
  enabled_for_disk_encryption = true

  # Allow Azure compute resource fetch secrets frm KV during deployment
  enabled_for_deployment = true

  enable_rbac_authorization = false # NIST 800-53: Use RBAC for access control

  # Secure network access using private endpoints (Optional)
  public_network_access_enabled = false # NIST 800-53: Disable public network access

  network_acls {
    bypass         = "AzureServices"
    default_action = "Deny"
    virtual_network_subnet_ids = [
      module.resources.subnet.id,
      module.resources.cmnsvc_subnet.id
    ]
  }

  tags = merge(
    module.tags.common_tags,
    { Service = "azure-keyvault" }
  )
}

resource "azurerm_private_endpoint" "keyvault_default" {
  name                = "${lower(var.project)}-${lower(var.environment_name)}-kv-private-endpoint"
  location            = var.location
  resource_group_name = local.default_resource_group
  subnet_id           = module.resources.subnet.id

  private_service_connection {
    name                           = "${lower(var.project)}-${lower(var.environment_name)}-kv-service-connection"
    private_connection_resource_id = azurerm_key_vault.default.id
    is_manual_connection           = false
    subresource_names              = ["vault"]
  }

   tags = merge(
    module.tags.common_tags,
    { Service = "azure-private-endpoint" }
  )
}

data "azurerm_private_dns_zone" "keyvault" {
  name                = "privatelink.vaultcore.azure.net"
  resource_group_name = local.global_resource_group
}

resource "azurerm_private_dns_a_record" "keyvault" {
  name                = lower(module.name-map.key_vault_name)
  zone_name           = data.azurerm_private_dns_zone.keyvault.name
  resource_group_name = local.global_resource_group
  ttl                 = 300
  records = [
    azurerm_private_endpoint.keyvault_default.private_service_connection[0].private_ip_address
  ]

   tags = merge(
    module.tags.common_tags,
    { Service = "dns-record" }
  )
}

# NIST 800-53: Diagnostic settings for audit logs
resource "azurerm_monitor_diagnostic_setting" "keyvault" {
  count                      = (local.stream_logs) ? 1 : 0
  name                       = "keyvault-diagnostics"
  target_resource_id         = azurerm_key_vault.default.id
  log_analytics_workspace_id = module.resources.c1_log_analytics_workspace.id

  # Enable logging for the AuditEvent category
  enabled_log {
    category = "AuditEvent"
  }

  # Enable metrics for AllMetrics category
  metric {
    category = "AllMetrics"
  }
}

resource "azurerm_key_vault_access_policy" "service_principal" {
  key_vault_id = azurerm_key_vault.default.id

  tenant_id = module.resources.azure_config.tenant_id
  object_id = module.resources.azure_config.object_id

  secret_permissions = [
    "Backup",
    "Delete",
    "Get",
    "List",
    "Purge",
    "Recover",
    "Restore",
    "Set"
  ]

  key_permissions = [
    "Create",
    "Delete",
    "Get",
    "Purge",
    "Recover",
    "Update",
    "List",
    "Decrypt",
    "Sign",
    "GetRotationPolicy",
    "SetRotationPolicy",
    "WrapKey",
    "UnwrapKey",
  ]

  certificate_permissions = [
    "Backup",
    "Create",
    "Delete",
    "DeleteIssuers",
    "Get",
    "GetIssuers",
    "Import",
    "List",
    "ListIssuers",
    "ManageContacts",
    "ManageIssuers",
    "Purge",
    "Recover",
    "Restore",
    "SetIssuers",
    "Update",
  ]
}

resource "azurerm_key_vault_access_policy" "aks-control-plane" {
  count        = module.resources.control_plane_managed_identity != null ? 1 : 0
  key_vault_id = azurerm_key_vault.default.id
  tenant_id    = module.resources.azure_config.tenant_id
  object_id    = module.resources.control_plane_managed_identity.principal_id
  key_permissions = [
    "Encrypt",
    "Decrypt",
    "Get",
    "WrapKey",
    "UnwrapKey",
  ]
}

resource "azurerm_key_vault_access_policy" "aks-kubelet" {
  count        = module.resources.kubelet_managed_identity != null ? 1 : 0
  key_vault_id = azurerm_key_vault.default.id
  tenant_id    = module.resources.azure_config.tenant_id
  object_id    = module.resources.kubelet_managed_identity.principal_id
  key_permissions = [
    "Encrypt",
    "Decrypt",
    "Get",
    "WrapKey",
    "UnwrapKey",
  ]
}

resource "azurerm_key_vault_key" "aks_kms_key" {
  name         = "kms-keyvault-key"
  key_vault_id = azurerm_key_vault.default.id
  key_type     = "RSA"
  key_size     = 2048

  rotation_policy {
    automatic {
      time_before_expiry = "P30D"
    }

    expire_after         = "P90D"
    notify_before_expiry = "P29D"
  }

  key_opts = [
    "decrypt",
    "encrypt",
    "sign",
    "unwrapKey",
    "verify",
    "wrapKey",
  ]

  tags = merge(
    module.tags.common_tags,
    { Service = "key-vault-key" }
  )

  depends_on = [
    azurerm_key_vault_access_policy.service_principal,
    azurerm_private_dns_a_record.keyvault,
    module.invoke_runbook_post_kv_privte_link,
  ]
}
