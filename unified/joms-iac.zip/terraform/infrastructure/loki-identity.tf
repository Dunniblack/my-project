resource "azurerm_federated_identity_credential" "loki" {
  count               = var.mi_loki_name != "" ? 1 : 0
  name                = "aks-${lower(var.environment_name)}-loki-federated-identity"
  resource_group_name = var.mi_resource_group_name
  audience            = ["api://AzureADTokenExchange"]
  issuer              = azurerm_kubernetes_cluster.default.oidc_issuer_url
  parent_id           = module.resources.loki_managed_identity.id
  subject             = "system:serviceaccount:loki:loki"
}
