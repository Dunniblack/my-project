# In C1, Setup Azure Automation Account Diagnostic Settings
resource "azurerm_monitor_diagnostic_setting" "aaa" {
  count                          =  (var.enclave == "wdsf") ? 0 : 1
  name                           = "aaa-diagnostics"
  target_resource_id             = module.resources.c1_automation_account.id
  log_analytics_workspace_id     = module.resources.c1_log_analytics_workspace.id

  # Enable logging for select categories
  enabled_log {
    category_group = "allLogs"
  }

  # Enable metrics for AllMetrics category
  metric {
    category = "AllMetrics"
  }
}
