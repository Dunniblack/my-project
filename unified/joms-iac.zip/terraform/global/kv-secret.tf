resource "azurerm_key_vault_secret" "dod_ca_certs" {
  name         = "dod-ca-certs"
  value        = file("${path.module}/../../certs/DoD_CAs.pem")
  key_vault_id = module.resources.c1_key_vault.id

  tags = merge(
    module.tags.common_tags,
    { Service = "key-vault-secret" }
  )

  depends_on = [
    azurerm_key_vault_access_policy.service_principal
  ]
}
