# 1 Year Retention
module "one_year_retention_law_tables" {
  source = "../modules/string-to-object-map"
  properties = {
    # Configure default retention to 30 days
    active_retention : 30
  }
  string_key = "name"
  input_strings = [
    "AKSAuditAdmin",
    "AKSControlPlane",
    "Alert",
    "AZKVAuditLogs",
    "ContainerLog",
    "ContainerLogV2",
    "KubeEvents",
    "KubeHealth",
    "KubeNodeInventory",
    "KubePodInventory",
    "Syslog"
  ]
  # Tables that require a different active retention period
  objects_to_append = [
    {
      name : "AKSAudit",
      active_retention : 90
    },
    {
      name : "AzureActivity",
      active_retention : 90
    }
  ]
}

# 1 Year Retention in C1 Only
module "one_year_retention_law_tables_c1_only" {
  source = "../modules/string-to-object-map"
  properties = {
    # Configure default retention to 30 days
    active_retention : 30
  }
  string_key = "name"
  input_strings = [
    "CommonSecurityLog",
    "DnsEvents",
    "Event",
    "LinuxAuditLog",
    "NetworkMonitoring",
    "SecurityAlert",
    "SecurityBaseline",
    "SecurityBaselineSummary",
    "SecurityDetection",
    "SecurityEvent",
    "SecurityRecommendation",
    "SecurityRegulatoryCompliance",
    "SecureScoreControls",
    "SecureScores",
    "WindowsFirewall"
  ]
}

locals {
  # 6 Months Retention
  six_months_retention_law_tables = [
    "AppCenterError",
    "ComputerGroup",
    "StorageBlobLogs",
    "StorageFileLogs",
    "StorageQueueLogs"
  ]
  # 6 Months Retention in C1 Only
  six_months_retention_law_tables_c1_only = [
    "ASRJobs",
    "ASRReplicatedItems",
    "AddonAzureBackupJobs",
    "AddonAzureBackupPolicy",
    "ConfigurationChange",
    "ConfigurationData",
    "CoreAzureBackup",
    "VMBoundPort",
    "VMComputer",
    "VMConnection",
    "VMProcess",
    "W3CIISLog"
  ]

  # 3 Months Retention
  three_months_retention_law_tables = [
    "AzureMetrics",
    "Heartbeat",
    "InsightsMetrics",
    "Perf"
  ]
  # 3 Months Retention in C1 Only
  three_months_retention_law_tables_c1_only = [
    "AzureMetricsV2",
    "LAQueryLogs",
    "LASummaryLogs",
    "Update",
    "UpdateRunProgress",
    "UpdateSummary"
  ]
}

resource "azurerm_log_analytics_workspace_table" "law_audit_retention_one_year" {
  for_each = merge(
    module.one_year_retention_law_tables.objects_by_key,
    var.enclave == "c1" ? module.one_year_retention_law_tables_c1_only.objects_by_key : {}
  )

  workspace_id = module.resources.c1_log_analytics_workspace.id
  name         = each.value.name

  retention_in_days       = each.value.active_retention
  total_retention_in_days = 365
}

resource "azurerm_log_analytics_workspace_table" "law_audit_retention_six_months" {
  for_each = toset(concat(
    local.six_months_retention_law_tables,
    var.enclave == "c1" ? local.six_months_retention_law_tables_c1_only : []
  ))

  workspace_id = module.resources.c1_log_analytics_workspace.id
  name         = each.value

  retention_in_days       = 30
  total_retention_in_days = 180
}

resource "azurerm_log_analytics_workspace_table" "law_audit_retention_three_months" {
  for_each = toset(concat(
    local.three_months_retention_law_tables,
    var.enclave == "c1" ? local.three_months_retention_law_tables_c1_only : []
  ))

  workspace_id = module.resources.c1_log_analytics_workspace.id
  name         = each.value

  retention_in_days       = 30
  total_retention_in_days = 90
}
