output "acr_public" {
  value = local.acr_public
}

output "acr_vnet_link_subnet_ids" {
  value = local.acr_vnet_link_subnet_ids
}

output "create_c1_guardrails" {
  value = local.create_c1_guardrails
}

output "invoke_runbook_post_acr_private_link" {
  value = local.invoke_runbook_post_acr_private_link
}

output "vnet_map_to_acr_private_ips" {
  value = try(local.vnet_map_to_private_ips, {})
}

output "global_storage_account_name" {
  value = azurerm_storage_account.global-storage-account.name
}

output "drift_storage_container_name" {
  value = azurerm_storage_container.drift-container.name
}

output "k8s_tls_alert_container_name" {
  value = azurerm_storage_container.k8s-tls-alert-container.name
}

output "k8s_credentials_alert_container_name" {
  value = azurerm_storage_container.k8s-credentials-alert-container.name
}

output "oscap_image_scans_container_name" {
  value = azurerm_storage_container.oscap-image-scans-container.name
}

output "core_key_vault_name" {
  value = var.core_key_vault_name
}
