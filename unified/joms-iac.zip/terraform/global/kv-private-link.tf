
resource "azurerm_private_dns_zone" "keyvault" {
  name                = "privatelink.vaultcore.azure.net"
  resource_group_name = local.global_resource_group

  tags = merge(
    module.tags.common_tags,
    { Service = "private-dns-zone" }
  )
}

resource "azurerm_private_dns_zone_virtual_network_link" "keyvault_link_default" {
  name                  = "keyvault-link-default"
  private_dns_zone_name = azurerm_private_dns_zone.keyvault.name
  virtual_network_id    = module.resources.vnet.id
  registration_enabled  = false
  resource_group_name   = local.global_resource_group


  tags = merge(
    module.tags.common_tags,
    { Service = "private-dns-zone-virtual-network-link" }
  )
}
