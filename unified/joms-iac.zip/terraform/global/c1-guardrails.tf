# Create C1 guardrails, if needed

data "azurerm_key_vault_secret" "ingress_ips" {
  name         = "ingress-ips"
  key_vault_id = module.resources.c1_key_vault.id
}

## Storage Account
resource "azurerm_storage_account" "guardrail" {
  count                             = local.create_c1_guardrails ? 1 : 0
  name                              = module.name-map.guardrail_storage_account_name
  resource_group_name               = local.global_resource_group
  location                          = var.location
  account_kind                      = "StorageV2"
  account_tier                      = "Standard"
  account_replication_type          = "RAGRS"
  infrastructure_encryption_enabled = true
  allow_nested_items_to_be_public   = false
  https_traffic_only_enabled        = true
  min_tls_version                   = "TLS1_2"
  shared_access_key_enabled         = true
  public_network_access_enabled     = true
  default_to_oauth_authentication   = false
  local_user_enabled                = false
  dns_endpoint_type                 = "Standard"

  blob_properties {
    versioning_enabled       = true
    change_feed_enabled      = false
    last_access_time_enabled = true
    delete_retention_policy {
      days                     = 365
      permanent_delete_enabled = false
    }
  }

  network_rules {
    default_action = "Deny"
    bypass = [
      "Logging",
      "Metrics",
      "AzureServices"
    ]
    ip_rules = split(",", data.azurerm_key_vault_secret.ingress_ips.value)
    virtual_network_subnet_ids = [
      module.resources.subnet.id,
      module.resources.cmnsvc_subnet.id,
    ]
  }

  identity {
    type = "SystemAssigned"
  }

  tags = merge(
    module.tags.common_tags,
    { Service = "storage-account" }
  )
}

## Key Vault 
resource "azurerm_key_vault" "guardrail-keyvault" {
  count               = local.create_c1_guardrails ? 1 : 0
  name                = module.name-map.guardrail_kv_name
  location            = var.location
  resource_group_name = local.global_resource_group
  tenant_id           = module.resources.azure_config.tenant_id
  sku_name            = "premium" # Premium SKU for HSM (Hardware Securty Modules) and advanced features

  # NIST 800-53: Protect against accidental deletion
  purge_protection_enabled = true

  soft_delete_retention_days = (
    contains(["prod", "test"], var.stage) ?
    90 :
    7
  )

  # NIST 800-53: Encryption at Rest using Azure Managed Keys
  enabled_for_disk_encryption = true

  # Allow Azure compute resource fetch secrets frm KV during deployment
  enabled_for_deployment = true

  enable_rbac_authorization = false # NIST 800-53: Use RBAC for access control

  # Secure network access using private endpoints (Optional)
  public_network_access_enabled = false # NIST 800-53: Disable public network access

  network_acls {
    bypass         = "AzureServices"
    default_action = "Deny"
    virtual_network_subnet_ids = [
      module.resources.subnet.id,
      module.resources.cmnsvc_subnet.id
    ]
  }

  tags = merge(
    module.tags.common_tags,
    { Service = "key-vault" }
  )
}

## Log Analytics Workspace
resource "azurerm_log_analytics_workspace" "guardrail-la-workspace" {
  count               = local.create_c1_guardrails ? 1 : 0
  name                = "guardrail-la-workspace"
  location            = var.location
  resource_group_name = local.global_resource_group
  sku                 = "PerGB2018"
  retention_in_days   = 30

  tags = merge(
    module.tags.common_tags,
    { Service = "log-analytics-workspace" }
  )
}
