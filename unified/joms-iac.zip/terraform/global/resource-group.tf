locals {
  global_resource_group = var.global_resource_group_name
}
