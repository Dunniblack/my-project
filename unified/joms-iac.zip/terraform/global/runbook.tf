data "local_file" "update_bastion_hosts_file" {
  filename = "../../scripts/ps/runbooks/update-bastion-hosts-file.ps1"
}

data "local_file" "custom_hosts_entry" {
  filename = "../../scripts/ps/runbooks/custom-hosts-entry.ps1"
}

data "local_file" "install_client_tools" {
  filename = "../../scripts/ps/runbooks/update-client-tools.ps1"
}

data "local_file" "ado_agent_pool_monitor_script" {
  filename = "../../scripts/ps/runbooks/monitor-ado-agents.ps1"
}

resource "azurerm_automation_schedule" "hourly" {
  count                   = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name                    = "Hourly"
  resource_group_name     = var.aa_resource_group_name
  automation_account_name = var.automation_account_name
  frequency               = "Hour"
  interval                = 1
  timezone                = "Etc/UTC"
  start_time              = timeadd(timestamp(), "10m")
  description             = "Runs hourly"

  lifecycle {
    ignore_changes = [
      start_time
    ]
  }
}

resource "azurerm_automation_schedule" "daily_9am" {
  count                   = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name                    = "Daily-9AM-UTC"
  resource_group_name     = var.aa_resource_group_name
  automation_account_name = var.automation_account_name
  frequency               = "Day"
  interval                = 1
  timezone                = "Etc/UTC"
  start_time              = timeadd(timestamp(), "10m")
  description             = "Runs daily at 9:00 AM UTC"

  lifecycle {
    ignore_changes = [
      start_time
    ]
  }
}

resource "azurerm_automation_runbook" "update_bastion_hosts_file" {
  count                   = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name                    = "update-bastion-hosts-file"
  location                = var.location
  resource_group_name     = var.aa_resource_group_name
  automation_account_name = var.automation_account_name
  log_verbose             = "true"
  log_progress            = "true"
  description             = "Runbook to update hosts file on C1 bastion/ADO agent machines."
  runbook_type            = "PowerShell72"
  content                 = data.local_file.update_bastion_hosts_file.content

  tags = merge(
    module.tags.common_tags,
    { Service = "automation-runbook" }
  )
}

resource "azurerm_automation_job_schedule" "update_bastion_hosts_file" {
  count                   = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  resource_group_name     = var.aa_resource_group_name
  automation_account_name = var.automation_account_name
  schedule_name           = azurerm_automation_schedule.hourly[0].name
  runbook_name            = azurerm_automation_runbook.update_bastion_hosts_file[0].name

  parameters = {
    enclave = var.enclave
  }
}


resource "azurerm_automation_runbook" "custom_hosts_entry" {
  count                   = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name                    = "custom-hosts-entry"
  location                = var.location
  resource_group_name     = var.aa_resource_group_name
  automation_account_name = var.automation_account_name
  log_verbose             = "true"
  log_progress            = "true"
  description             = "Runbook to add custm hosts entries on C1 bastion/ADO agent machines."
  runbook_type            = "PowerShell72"
  content                 = data.local_file.custom_hosts_entry.content

  tags = merge(
    module.tags.common_tags,
    { Service = "automation-runbook" }
  )
}

resource "azurerm_automation_runbook" "update_client_tools" {
  count                   = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name                    = "update-client-tools"
  location                = var.location
  resource_group_name     = var.aa_resource_group_name
  automation_account_name = var.automation_account_name
  log_verbose             = "true"
  log_progress            = "true"
  description             = "Runbook to update client tools on C1 bastions."
  runbook_type            = "PowerShell72"
  content                 = data.local_file.install_client_tools.content

  tags = merge(
    module.tags.common_tags,
    { Service = "automation-runbook" }
  )
}

resource "azurerm_automation_runbook" "ado_agent_pool_monitor" {
  count                   = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name                    = "monitor-ado-agents"
  location                = var.location
  resource_group_name     = var.aa_resource_group_name
  automation_account_name = var.automation_account_name
  log_verbose             = "true"
  log_progress            = "true"
  description             = "Monitors ADO agent pools for offline agents and sends alerts."
  runbook_type            = "PowerShell72"
  content                 = data.local_file.ado_agent_pool_monitor_script.content

  tags = merge(
    module.tags.common_tags,
    {
      Service = "automation-runbook"
    }
  )
}

resource "azurerm_automation_job_schedule" "ado_agent_pool_monitor_daily" {
  count                   = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  resource_group_name     = var.aa_resource_group_name
  automation_account_name = var.automation_account_name
  schedule_name           = azurerm_automation_schedule.daily_9am[0].name
  runbook_name            = azurerm_automation_runbook.ado_agent_pool_monitor[0].name

  parameters = {
    stage                       = var.stage
    keyvaultname                = var.core_key_vault_name
    resourcegroupname           = local.global_resource_group
    actiongroupname             = "DevOps-Team"
    bastionvmpattern            = var.bastion_vm_pattern
    bastionresourcegrouppattern = var.bastion_resource_group_pattern
    adopatsecretname            = var.ado_pat_secret_name
    poolnamepattern             = "${var.functional_area}-${var.c1_project}*"
  }
}
