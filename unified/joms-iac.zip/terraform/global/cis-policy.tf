data "azurerm_policy_set_definition" "cis_benchmark" {
  display_name =  "CIS Microsoft Azure Foundations Benchmark v1.3.0"
}

resource "azurerm_resource_group_policy_assignment" "cis_benchmark" {
  count                = var.enclave == "wdsf" ? 1 : 0
  name                 = "cis-benchmark"
  resource_group_id    = module.resources.resource_group.id
  policy_definition_id = data.azurerm_policy_set_definition.cis_benchmark.id
}
