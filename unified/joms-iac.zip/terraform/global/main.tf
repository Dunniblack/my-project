terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.58.0"
    }
  }
  backend "azurerm" {
    access_key = "{{ ARM_ACCESS_KEY }}"
  }
}

provider "azurerm" {
  subscription_id                 = var.subscription_id
  storage_use_azuread             = true
  resource_provider_registrations = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? "none" : "all"
  metadata_host                   = "${var.metadata_host}/"
  features {}
}

data "terraform_remote_state" "az" {
  backend = "azurerm"
  config = {
    resource_group_name  = var.tfstate_resource_group
    storage_account_name = var.tfstate_storage_account
    container_name       = var.tfstate_container
    key = (
      (var.enclave == "wdsf" || var.enclave == "thundercamp") ?
      "${var.tfstate_key}env:${var.environment_name}" :
      var.tfstate_key
    )
    access_key = "{{ ARM_ACCESS_KEY }}"
  }
}

module "name-map" {
  source = "../modules/name-map"

  environment_name = var.environment_name
  parent_module    = var.parent_module
  stage            = var.stage
  project          = var.project
  c1_project       = var.c1_project
  functional_area  = var.functional_area
  location         = var.location
  impact_level     = var.impact_level
}

module "resources" {
  source = "../modules/resources"

  resource_group_name = var.vnet_resource_group_name
  vnet_name           = var.vnet_name
  subnet_name         = var.subnet_name

  cmnsvc_resource_group_name = var.cmnsvc_resource_group_name
  cmnsvc_vnet_name           = var.cmnsvc_vnet_name
  cmnsvc_subnet_name         = var.cmnsvc_subnet_name

  core_key_vault_name    = var.core_key_vault_name
  kv_resource_group_name = var.kv_resource_group_name

  log_analytics_workspace_name = var.log_analytics_workspace_name
  la_resource_group_name       = var.la_resource_group_name

  automation_account_name = var.automation_account_name
  aa_resource_group_name  = var.aa_resource_group_name
}

module "alerts" {
  source = "../modules/alerts"

  stage                                 = var.stage
  enclave                               = var.enclave
  location                              = var.location
  global_resource_group                 = local.global_resource_group
  c1_log_analytics_workspace_id         = module.resources.c1_log_analytics_workspace.id
  common_tags                           = module.tags.common_tags
  global_storage_account_name           = azurerm_storage_account.global-storage-account.name
  drift_container_name                  = azurerm_storage_container.drift-container.name
  k8s_tls_alert_container_name          = azurerm_storage_container.k8s-tls-alert-container.name
  k8s_credentials_alert_container_name  = azurerm_storage_container.k8s-credentials-alert-container.name
}

module "tags" {
  source = "../modules/tags"

  enclave          = var.enclave
  parent_module    = var.parent_module
  environment_name = var.environment_name
}

module "invoke_runbook_post_acr_private_link" {
  for_each = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? [] : toset([local.invoke_runbook_post_acr_private_link])
  source   = "../modules/invoke-runbook"

  enclave                 = var.enclave
  automation_account_name = var.automation_account_name
  aa_resource_group_name  = var.aa_resource_group_name

  depends_on = [
    azurerm_private_dns_a_record.acr,
    azurerm_private_dns_a_record.acr-data,
  ]
}
