# Variables for Azure resources

variable "environment_name" {
  description = "The name of the Environment"
  type        = string
}

variable "parent_module" {
  description = "The name of the Parent Terraform Module."
  type        = string
}

variable "stage" {
  description = "The stage of the Environment (dev, test, prod)"
  type        = string
}

variable "project" {
  description = "The Project Name"
  type        = string
  default     = "JOMS"
}

variable "c1_project" {
  description = "The C1 Project Name"
  type        = string
  default     = "JOMSMVP"
}

variable "enclave" {
  description = "The enclave that we're executing the logic (i.e. 'wdsf', 'c1')."
  type        = string
  default     = "c1"
  validation {
    condition     = contains(["wdsf", "c1", "thundercamp"], var.enclave)
    error_message = "The enclave  must be one of the follwing: \"wdsf\", \"c1\", \"thundercamp\""
  }
}

variable "functional_area" {
  description = "The Functional Area of the environment (AFMC)"
  type        = string
  default     = "AFMC"
}

variable "location" {
  description = "The Azure location where resources will be created."
  type        = string
  default     = "USGov Virginia"
}

variable "subscription_id" {
  description = "The Subscription ID for Azure."
  type        = string
}

variable "global_resource_group_name" {
  description = "The name of the Global Resource Group."
  type        = string
  default     = ""
}

variable "aks_resource_group_name" {
  description = "The name of the AKS Resource Group."
  type        = string
}

variable "tfstate_resource_group" {
  description = "The name of the TF State Resource Group."
  type        = string
}

variable "tfstate_storage_account" {
  description = "The name of the TF State Storage Account."
  type        = string
}

variable "tfstate_container" {
  description = "The name of the TF State Container."
  type        = string
}

variable "tfstate_key" {
  description = "The name of the TF State Key."
  type        = string
}

variable "vnet_resource_group_name" {
  description = "The name of the VNet Resource Group."
  type        = string
}

variable "vnet_name" {
  type        = string
  description = "The Virtual Network Name."
}

variable "subnet_name" {
  type        = string
  description = "The Subnet Name."
}

variable "cmnsvc_vnet_name" {
  type        = string
  description = "The Virtual Network Name of the C1 Common Services."
}

variable "cmnsvc_resource_group_name" {
  description = "The name of the Resource Group of the C1 Common Services."
  type        = string
}

variable "cmnsvc_subnet_name" {
  type        = string
  description = "The Subnet Nameo f the C1 Common Services"
}

variable "core_key_vault_name" {
  type        = string
  description = "The C1 Key Vault Name."
}

variable "kv_resource_group_name" {
  type        = string
  description = "The name of the C1 Key Vault Resource Group."
}

variable "log_analytics_workspace_name" {
  type        = string
  description = "The Log Analytics Workspace Name."
}

variable "la_resource_group_name" {
  type        = string
  description = "The name of the C1 Log Analytics Workspace Resource Group."
}

variable "automation_account_name" {
  type        = string
  description = "The C1 Automation Account Name."
}

variable "aa_resource_group_name" {
  type        = string
  description = "The name of the C1 Automation Account Resource Group."
}

variable "admin_aad_group_ids" {
  description = "CSV list of Azure Active Directory Group IDs of Admin Users."
  type        = string
}

variable "read_only_aad_group_id" {
  description = "The Azure Active Directory Group ID of Read Only Users."
  type        = string
  default     = null
}

variable "acr_public" {
  description = "True/False flag to determine if ACR is open to public network."
  type        = bool
  default     = null
}

variable "acr_vnet_link_subnet_ids" {
  description = "CSV list of Subnet IDs to create ACR VNet Links."
  type        = string
  default     = null
}

variable "create_c1_guardrails" {
  description = "True/False flag to determine if we should create C1 guardrails."
  type        = bool
  default     = null
}

variable "impact_level" {
  description = "The IL5/IL6 deployment."
  type        = string
  default     = "IL5"
}

variable "metadata_host" {
  description = "Metadata_host endpoint"
  type        = string
  default     = "management.usgovcloudapi.net"
}

variable "invoke_runbook_post_acr_private_link" {
  description = "Triggers runbook post ACR Private Link creation."
  type        = string
  default     = null
}

variable "bastion_vm_pattern" {
  description = "Pattern to match bastion VM names"
  type        = string
  default     = "BST"

}

variable "bastion_resource_group_pattern" {
  description = "Pattern to match bastion resource group names"
  type        = string
  default     = "APP-RGP-01"
}

variable "ado_pat_secret_name" {
  description = "Name of the ADO PAT secret in Key Vault"
  type        = string
  default     = "git-credentials"
}
