locals {
  acr_public = coalesce(
    var.acr_public,
    try(
      data.terraform_remote_state.az.outputs.acr_public,
      false
    )
  )
  acr_vnet_link_subnet_ids = coalesce(
    var.acr_vnet_link_subnet_ids,
    try(
      data.terraform_remote_state.az.outputs.acr_vnet_link_subnet_ids,
      module.resources.subnet.id
    )
  )
  create_c1_guardrails = coalesce(
    var.create_c1_guardrails,
    try(
      data.terraform_remote_state.az.outputs.create_c1_guardrails,
      false
    )
  )
  invoke_runbook_post_acr_private_link = coalesce(
    var.invoke_runbook_post_acr_private_link,
    try(
      data.terraform_remote_state.az.outputs.invoke_runbook_post_acr_private_link,
      "0"
    )
  )
}
