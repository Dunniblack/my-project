resource "azurerm_storage_account" "global-storage-account" {
  name                              = module.name-map.global_storage_account_name
  resource_group_name               = local.global_resource_group
  location                          = var.location
  account_kind                      = "StorageV2"
  account_tier                      = "Standard"
  account_replication_type          = "RAGRS"
  infrastructure_encryption_enabled = true
  allow_nested_items_to_be_public   = false
  https_traffic_only_enabled        = true
  min_tls_version                   = "TLS1_2"
  shared_access_key_enabled         = true
  public_network_access_enabled     = true
  default_to_oauth_authentication   = false
  local_user_enabled                = false
  dns_endpoint_type                 = "Standard"

  blob_properties {
    versioning_enabled       = true
    change_feed_enabled      = false
    last_access_time_enabled = true
    delete_retention_policy {
      days                     = 7
      permanent_delete_enabled = true
    }
  }

  network_rules {
    # Allow broader access in WDSF and Thundercamp; restrict to approved IPs in other enclaves
    default_action = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? "Allow" : "Deny"
    bypass = [
      "Logging",
      "Metrics",
      "AzureServices"
    ]
    ip_rules = (
      (var.enclave == "wdsf" || var.enclave == "thundercamp") ?
      null :
      split(",", data.azurerm_key_vault_secret.ingress_ips.value)
    )
    virtual_network_subnet_ids = [
      module.resources.subnet.id,
      module.resources.cmnsvc_subnet.id,
    ]
  }

  identity {
    type = "SystemAssigned"
  }

  tags = merge(
    module.tags.common_tags,
    { Service = "storage-account" }
  )

  lifecycle {
    ignore_changes = [
      customer_managed_key
    ]
  }
}

resource "azurerm_key_vault_access_policy" "global-storage" {
  key_vault_id = module.resources.c1_key_vault.id
  tenant_id    = module.resources.azure_config.tenant_id
  object_id    = azurerm_storage_account.global-storage-account.identity[0].principal_id

  secret_permissions = ["Get"]
  key_permissions = [
    "Get",
    "UnwrapKey",
    "WrapKey"
  ]
}

resource "azurerm_key_vault_key" "global-storage" {
  name         = "global-storage-key"
  key_vault_id = module.resources.c1_key_vault.id
  key_type     = "RSA"
  key_size     = 2048
  key_opts = [
    "decrypt",
    "encrypt",
    "sign",
    "unwrapKey",
    "verify",
    "wrapKey"
  ]

  depends_on = [
    azurerm_key_vault_access_policy.service_principal,
    azurerm_key_vault_access_policy.global-storage
  ]

  tags = merge(
    module.tags.common_tags,
    { Service = "keyvault-key" }
  )
}

# Encrypt storage account using customer-managed key from Key Vault
resource "azurerm_storage_account_customer_managed_key" "global-storage" {
  storage_account_id = azurerm_storage_account.global-storage-account.id
  key_vault_id       = module.resources.c1_key_vault.id
  key_name           = azurerm_key_vault_key.global-storage.name
}

resource "azurerm_storage_container" "drift-container" {
  name                  = "drift"
  storage_account_id    = azurerm_storage_account.global-storage-account.id
  container_access_type = "private"
}

resource "azurerm_storage_container" "k8s-tls-alert-container" {
  name                  = "k8s-tls-alert"
  storage_account_id    = azurerm_storage_account.global-storage-account.id
  container_access_type = "private"
}

resource "azurerm_storage_container" "k8s-credentials-alert-container" {
  name                  = "k8s-credentials-alert"
  storage_account_id    = azurerm_storage_account.global-storage-account.id
  container_access_type = "private"
}

resource "azurerm_storage_container" "oscap-image-scans-container" {
  name                  = "oscap-image-scans"
  storage_account_id    = azurerm_storage_account.global-storage-account.id
  container_access_type = "private"
}

resource "azurerm_monitor_diagnostic_setting" "global-storage-account" {
  name                       = "global-storage-account-diagnostics"
  target_resource_id         = azurerm_storage_account.global-storage-account.id
  log_analytics_workspace_id = module.resources.c1_log_analytics_workspace.id

  enabled_metric {
    category = "Transaction"
  }

  lifecycle {
    # Ignore metric changes to exclude storage account from Azure's automatic metric updates
    ignore_changes = [
      metric
    ]
  }
}

resource "azurerm_monitor_diagnostic_setting" "global-storage-account-service" {
  name                       = "global-storage-account-blob-diagnostics"
  target_resource_id         = "${azurerm_storage_account.global-storage-account.id}/blobServices/default/"
  log_analytics_workspace_id = module.resources.c1_log_analytics_workspace.id

  enabled_log {
    category_group = "allLogs"
  }

  enabled_metric {
    category = "Transaction"
  }

  lifecycle {
    # Ignore metric changes to exclude storage account BLOB service from Azure's automatic metric updates
    ignore_changes = [
      metric
    ]
  }
}
