resource "azurerm_user_assigned_identity" "acr" {
  count               = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  location            = var.location
  name                = "${module.name-map.container_registry_name}-identity"
  resource_group_name = local.global_resource_group

  tags = merge(
    module.tags.common_tags,
    { Service = "user-assigned-identity" }
  )
}

resource "azurerm_key_vault_access_policy" "acr" {
  count        = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  key_vault_id = module.resources.c1_key_vault.id
  tenant_id    = module.resources.azure_config.tenant_id
  object_id    = azurerm_user_assigned_identity.acr.0.principal_id

  key_permissions = [
    "Get",
    "UnwrapKey",
    "WrapKey"
  ]

}

resource "azurerm_key_vault_key" "acr" {
  count        = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name         = "${module.name-map.container_registry_name}-encryption-key"
  key_vault_id = module.resources.c1_key_vault.id
  key_type     = "RSA"
  key_size     = 2048

  key_opts = [
    "decrypt",
    "encrypt",
    "sign",
    "unwrapKey",
    "verify",
    "wrapKey",
  ]

  rotation_policy {
    automatic {
      time_before_expiry = "P30D"
    }

    expire_after         = "P90D"
    notify_before_expiry = "P29D"
  }

  tags = merge(
    module.tags.common_tags,
    { Service = "key-vault-key" }
  )

  depends_on = [
    azurerm_key_vault_access_policy.service_principal
  ]

}

resource "azurerm_container_registry" "acr" {
  count                         = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name                          = module.name-map.container_registry_name
  resource_group_name           = local.global_resource_group
  location                      = var.location
  sku                           = "Premium"
  admin_enabled                 = true
  public_network_access_enabled = local.acr_public
  anonymous_pull_enabled        = false
  export_policy_enabled         = local.acr_public
  quarantine_policy_enabled     = false
  #Content trust is currently not supported for encryption enabled registries.
  trust_policy_enabled     = false
  zone_redundancy_enabled  = true
  retention_policy_in_days = 30

  identity {
    type = "UserAssigned"
    identity_ids = [
      azurerm_user_assigned_identity.acr.0.id
    ]
  }

  # 400 Bad Request - IP Range cannot overlap with private or reserved IPs 10.0.0.0/8
  #network_rule_set {
  #  default_action = "Deny"
  #  ip_rule {
  #    action  = "Allow"
  #    ip_range = module.resources.vnet.address_space.0
  #  }
  #}

  encryption {
    key_vault_key_id   = azurerm_key_vault_key.acr.0.id
    identity_client_id = azurerm_user_assigned_identity.acr.0.client_id
  }

  tags = merge(
    module.tags.common_tags,
    { Service = "container-registry" }
  )
}

resource "azurerm_monitor_diagnostic_setting" "acr" {
  count                      = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name                       = "acr-diagnostics"
  target_resource_id         = azurerm_container_registry.acr.0.id
  log_analytics_workspace_id = module.resources.c1_log_analytics_workspace.id

  enabled_log {
    category_group = "allLogs"
  }

  metric {
    category = "AllMetrics"
  }
}

resource "azurerm_private_dns_zone" "acr" {
  count               = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name                = "privatelink.azurecr.us"
  resource_group_name = local.global_resource_group

  tags = merge(
    module.tags.common_tags,
    { Service = "private-dns-zone" }
  )
}

resource "azurerm_private_endpoint" "acr" {
  for_each = (
    (var.enclave == "wdsf" || var.enclave == "thundercamp") ? {} :
    { for idx, id in split(",", local.acr_vnet_link_subnet_ids): id => idx }
  )
  name                = "${module.name-map.container_registry_name}-private-endpoint-${each.value}"
  resource_group_name = local.global_resource_group
  location            = var.location
  subnet_id           = each.key

  private_service_connection {
    name                           = "${module.name-map.container_registry_name}-service-connection-${each.value}"
    private_connection_resource_id = azurerm_container_registry.acr.0.id
    is_manual_connection           = false
    subresource_names = [
      "registry"
    ]
  }

  tags = merge(
    module.tags.common_tags,
    { Service = "private-endpoint" }
  )
}

locals {
  acr_data_endpoint = "${module.name-map.container_registry_name}.${lower(replace(var.location," ",""))}.data"
  acr_pull_username = "acr-read-token"

  acr_ips = [ for private_endpoint in azurerm_private_endpoint.acr:
    try(private_endpoint.custom_dns_configs[
      index(private_endpoint.custom_dns_configs.*.fqdn,
      "${module.name-map.container_registry_name}.azurecr.us")
    ].ip_addresses.0, "0.0.0.0") ]
  acr_data_ips = [ for private_endpoint in azurerm_private_endpoint.acr:
    try(private_endpoint.custom_dns_configs[
      index(private_endpoint.custom_dns_configs.*.fqdn,
      "${local.acr_data_endpoint}.azurecr.us")
    ].ip_addresses.0, "0.0.0.0") ]


  vnet_ids = [ for idx, subnet_id in split(",", local.acr_vnet_link_subnet_ids):
    replace(dirname(dirname(subnet_id)),"\\","/") ]

  vnet_map_to_private_ips = {
      for idx, vnet in local.vnet_ids:
      vnet => {
        acr_repo_private_ip = try(local.acr_ips[idx], "0.0.0.0")
        acr_data_private_ip = try(local.acr_data_ips[idx], "0.0.0.0")
      }
    }
}

resource "azurerm_private_dns_a_record" "acr" {
  count               = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name                = lower(module.name-map.container_registry_name)
  zone_name           = azurerm_private_dns_zone.acr.0.name
  resource_group_name = local.global_resource_group
  ttl                 = 300
  records             = local.acr_ips

  tags = merge(
    module.tags.common_tags,
    { Service = "private-dns-a-record" }
  )
}

resource "azurerm_private_dns_a_record" "acr-data" {
  count               = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name                = lower(local.acr_data_endpoint)
  zone_name           = azurerm_private_dns_zone.acr.0.name
  resource_group_name = local.global_resource_group
  ttl                 = 300
  records             = local.acr_data_ips

  tags = merge(
    module.tags.common_tags,
    { Service = "private-dns-a-record" }
  )
}

resource "azurerm_private_dns_zone_virtual_network_link" "acr_link" {
  for_each = (
    (var.enclave == "wdsf" || var.enclave == "thundercamp") ? {} :
    { for idx, vnet_id in local.vnet_ids: vnet_id => idx }
  )
  name                  = "acr-link-${each.value}"
  resource_group_name   = local.global_resource_group
  private_dns_zone_name = azurerm_private_dns_zone.acr.0.name
  virtual_network_id    = each.key
  registration_enabled  = false

  tags = merge(
    module.tags.common_tags,
    { Service = "private-dns-zone-virtual-network-link" }
  )
}

resource "azurerm_key_vault_secret" "acr-user-1" {
  count        = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name         = "acr-user-1"
  value        = azurerm_container_registry.acr.0.admin_username
  key_vault_id = module.resources.c1_key_vault.id

  tags = merge(
    module.tags.common_tags,
    { Service = "key-vault-secret" }
  )

  depends_on = [
    azurerm_key_vault_access_policy.service_principal
  ]
}

resource "azurerm_key_vault_secret" "acr-password-1" {
  count        = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name         = "acr-password-1"
  value        = azurerm_container_registry.acr.0.admin_password
  key_vault_id = module.resources.c1_key_vault.id

  tags = merge(
    module.tags.common_tags,
    { Service = "key-vault-secret" }
  )

  depends_on = [
    azurerm_key_vault_access_policy.service_principal
  ]
}

resource "azurerm_container_registry_scope_map" "acr-read" {
  count               = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1

  name                    = "repo-read-all-scope-map"
  container_registry_name = module.name-map.container_registry_name
  resource_group_name     = local.global_resource_group
  actions = [
    "repositories/*/content/read",
    "repositories/*/metadata/read"
  ]
}

resource "azurerm_container_registry_token" "default" {
  count               = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1

  name                    = local.acr_pull_username
  container_registry_name = module.name-map.container_registry_name
  resource_group_name     = local.global_resource_group
  scope_map_id            = azurerm_container_registry_scope_map.acr-read.0.id
}

resource "azurerm_container_registry_token_password" "default" {
  count               = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1

  container_registry_token_id = azurerm_container_registry_token.default.0.id

  password1 {}
}

resource "azurerm_key_vault_secret" "acr-pull-username-1" {
  count        = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name         = "acr-pull-username-1"
  value        = local.acr_pull_username
  key_vault_id = module.resources.c1_key_vault.id

  tags = merge(
    module.tags.common_tags,
    { Service = "key-vault-secret" }
  )

  depends_on = [
    azurerm_key_vault_access_policy.service_principal
  ]
}

resource "azurerm_key_vault_secret" "acr-pull-password-1" {
  count        = (var.enclave == "wdsf" || var.enclave == "thundercamp") ? 0 : 1
  name         = "acr-pull-password-1"
  value        = azurerm_container_registry_token_password.default.0.password1.0.value
  key_vault_id = module.resources.c1_key_vault.id

  tags = merge(
    module.tags.common_tags,
    { Service = "key-vault-secret" }
  )

  depends_on = [
    azurerm_key_vault_access_policy.service_principal
  ]
}
