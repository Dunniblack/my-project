# Introduction
Infrastructure as Code (IaC) repository for the JOMS Mission Planning Application.

## Pipelines
- Azure DevOps Pipeline (Cloud 1)
- Jenkins Pipeline (WDSF/ThunderCamp)

## DevOps Tooling
- Docker / BuildX
- ImgPkg / Kbld
- KubeCtl
- Kubelogin
- Terraform / Terraform-bundle
- Helm
- YQ
- Velero

## Programming Languages
- HashiCorp Configuration Language (HCL)
- PowerShell
- Shell

# Prerequisites
The below items should be in place prior to executing the IaC.

## Infrastructure - Core Resources
The below core resources are typically built-out by the CSP vendor (WDFS, C1, ThunderCamp).
Naming convetions vary by CSP vendor.
- Azure Resource Group
- Azure Storage Account
- Azure Key Vault
- Azure Log Analytics
- Azure Virtual Network

- CIDR Block Size: At least /20

- Subnets

    - AKS Subnet:

      - CIDR Block Size: At least /21

      - Ensure the following Service Endpoints are added:

        - Microsoft.KeyVault

        - Microsoft.Storage

      - Ensure the NSGs outbound connections support [AKS API Server VNet Integration](https://learn.microsoft.com/en-us/azure/aks/api-server-vnet-integration)

        - Allow outbound ports: 443,4443,9988

    - AKS API Server Subnet:

      - Run the command:

      ```bash
      az network vnet subnet create --resource-group <RG-Name> --vnet-name <vNet-Name> --name api-server-subnet-iac --address-prefixes 172.18.16.0/26 --delegations Microsoft.ContainerService/managedClusters
      ```

        - Update the `<RG-Name>`, `<vNet-Name>` and `172.18.16.0/26` as needed.

        - Makesure the Address Prfixes uses a CIDR block of `/26` to make sure enough IPs are available.

Note: We'll place the name of the resources in the Terraform Variable file mentioned in the section below.

## Enable AKS API Server VNet Integration
Run the below commands to enable [AKS API Server VNet Integration](https://learn.microsoft.com/en-us/azure/aks/api-server-vnet-integration)
```bash
# Enable AKS API Server VNet Integration
az feature register --namespace "Microsoft.ContainerService" --name "EnableAPIServerVnetIntegrationPreview"
# Verify the AKS API Server VNet Integration shows "Registerd" status
az feature show --namespace "Microsoft.ContainerService" --name "EnableAPIServerVnetIntegrationPreview"

```

## Azure Service Princiapal

We'll need to create an Azure Service Principal with the correct permissions to provision the Azure resources.
Azure permissions are handled differently depending on the enclave (WDSF, C1 or ThunderCamp).

### WDSF / ThunderCamp Permissions

Roles assigned at the RG and Virtual Network level.

| Role                                           | Scope          |
| ---------------------------------------------- | -------------- |
| Azure Kubernetes Service Cluster Admin Role    | resourceGroups |
| Azure Kubernetes Service Contributor Role      | resourceGroups |
| Azure Kubernetes Service RBAC Cluster Admin    | resourceGroups |
| Kubernetes Extension Contributor               | resourceGroups |
| Storage Account Contributor                    | resourceGroups |
| Monitoring Contributor                         | resourceGroups |
| Reader                                         | resourceGroups |
| Contributor                                    | resourceGroups |
| Key Vault Contributor                          | resourceGroups |
| Key Vault Crypto User                          | resourceGroups |
| Disk Encryption Set Operator for Managed Disks | resourceGroups |
| Contributor                                    | vNet           |

### C1 Permissions

Refer to the following link.
[Cloud One Azure IL4/5 Permissions FAQ](https://c1snow.cce.af.mil/cloudone?id=kb_article_view&sysparm_article=KB0010860)

## Azure Managed Identities

The follow Managed Identities should be created and assigned the respective Roles.

**Control Plane Managed Identity (JOMSMVP-AKS-CP-IDENTITY)**

| Role                       | Scope              |
| -------------------------- | ------------------ |
| Contributor                | AKS resourceGroup  |
| Network Contributor        | vNet resourceGroup |
| Managed Idenetity Operator | Kubelet MSI        |

**Kubelet Managed Identity (JOMSMVP-AKS-KUBELET-IDENTITY)**

| Role    | Scope             |
| ------- | ----------------- |
| AcrPull | ACR resourceGroup |

**Velero Managed Identity (JOMSMVP-AKS-VELERO-IDENTITY)**

| Role                       | Scope                  |
| -------------------------- | ---------------------- |
| Read/Write Compute         | AKS resourceGroup      |
| Read/Write Storage Account | AKS resourceGroup      |
| Read/Write Compute         | AKS Node resourceGroup |
| Read/Write Storage Account | AKS Node resourceGroup |

**Loki Managed Identity (JOMSMVP-AKS-LOKI-IDENTITY)**

| Role                       | Scope             |
| -------------------------- | ----------------- |
| Read/Write Storage Account | AKS resourceGroup |


**External Secrets Managed Identity (JOMSMVP-AKS-ESO-IDENTITY)**

* No Role Assignments needed.
* Access is controlled with AKV Access Policies, managed with Terraform.

## Terraform Setup

### Storage Account Container

Create a Container within the Core Resource Storage Account (mentioned in the Prerequisites section above).
Container name 'terraformbackend'.

### Terraform Variables File

* Based on the file 'terraform/.default.vars', create a new file with the correct respective values based io the Resources mentioned in Prerequisites section above.
* Name the file '.tfvars'.

For example, if we're planning to deploy Terraform Resources using the 'MVP' Terraform Workspace, then name the file 'MVP.tfvars'.
**We'll need a Global.tfvars file for deploying Terrform Global resources.**

* Upload Terraform Variables file to the 'terraformbackend' Container, created in the previous section.

## Automation Pipelines

We recommend setting up one of the below automation pipelines to execute the IaC.

* Jenkins (WDSF/ThunderCamp)
* Azure DevOps (C1)

## Credentials / Secrets

The following credentials will need to be setup, in order to execute the IaC.

## Credential Store

If using Azure DevOps, store these credentials in the Azure Key Vault Core Resources.
Mentioned in the prequisite section above.

| Key                                                             | Value Description                                                                             |
| --------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| container-access-key-1                                          | Storage Account Access Key for the Terraform Remote Backend                                   |
| k8s-credential-alert-container-key                              | Storage Account Access Key for the target STIG 60-day rotation metric container storage area  |
| DevopsAlertUrl                                                  | HTTPS URL to be used to send alerts to the DevOps team                                        |
| git-credentials                                                 | The Username and Password Git Credentials                                                     |
| helm-credentials                                                | The Username and Password Helm Credentials                                                    |
| hosts-override                                                  | List of IPs and hostnames to override, comma separated (Last entry must be the helm registry) |
| ingress-ips                                                     | Ingress IPs CIDR Blocks to whitelist, comma separated                                         |
| * keycloak-idp-config-${enclave}                                | Default Keycloak SAML IdP config for an enclave                                               |
| * keycloak-idp-config-${enclave}-${lower(var.environment_name)} | Overridden Keycloak SAML IdP config for an enclave and env name                               |
| spAppId                                                         | Service Principal Application ID                                                              |
| spAppKey                                                        | Service Principal Application Key                                                             |
| repo-helm                                                       | Helm Repo Connection info                                                                     |
| repo-joms-iac                                                   | JOMS IaC Repo (Git) Connection info                                                           |
| tenant-id                                                       | Azure Tenant ID                                                                               |
| monitored-terraform-workspaces                                  | Comma separated list of Terraform workspaces to be monitored for drift                        |
| tfstate-container                                               | Storage Account Container Name for the Terraform Remote Backend                               |
| tfstate-resource-group                                          | Storage Account Resource Group Name for the Terraform Remote Backend                          |
| tfstate-storage-account                                         | Storage Account Name for the Terraform Remote Backend                                         |
| twistlock-license                                               | The Twistlock / PrismaCloud License Key                                                       |

* At least one of keycloak-idp-config-${enclave} or keycloak-idp-config-${enclave}-${lower(var.environment_name)} must be provided.

# Build the Infrastructure and deploy the software

Note: The below steps have been automated with the `deploy-all` Jenkins/ADO Pipelines.

## 1 - Global Infrastructure

Execute the following Jenkins Job/ADO Pipeline with the following Parameters:

```text
# First Run Terraform Plan to make sure everything looks good.
Execute-Terraform, Module: global, Action: plan, Workspace: MVP
# Once the TF Plan has been verifies, apply the Terraform.
Execute-Terraform, Module: global, Action: apply, Workspace: MVP

```

## 2 - Cluster Infrastructure

Execute the following Jenkins Job/ADO Pipeline with the following Parameters:

```text
# First Run Terraform Plan to make sure everything looks good.
Execute-Terraform, Module: infrastructure, Action: plan, Workspace: MVP
# Once the TF Plan has been verifies, apply the Terraform.
Execute-Terraform, Module: infrastructure, Action: apply, Workspace: MVP
# Execute the infrastructure TF module twice for circular dependicies
Execute-Terraform, Module: infrastructure, Action: apply, Workspace: MVP, Generate Certs: true
# Once the cluster has been created, ask C1 to mirror the Velero Managed Identity Role from the
# AKS Resource group to the AKS Node Resource Group

```

## 3 - Cluster Software

Execute the following Jenkins Job/ADO Pipeline with the following Parameters:

```text
# First Run Terraform Plan to make sure everything looks good.
Execute-Terraform, Module: software, Action: plan, Workspace: MVP
# Once the TF Plan has been verifies, apply the Terraform.
Execute-Terraform, Module: software, Action: apply, Workspace: MVP

```

## Local Admin Grafana Login

If the Local Admin Grafana Login is enabled, run the below GitBash command to setup the local admin PW.

```bash
GRAFANA_PASSWORD=$(kubectl -n grafana get secret core-app-grafana -o jsonpath="{.data.admin-password}" | base64 -d)
kubectl exec -n grafana core-app-grafana-0 -c grafana -- grafana cli admin reset-admin-password "$GRAFANA_PASSWORD"
echo "$GRAFANA_PASSWORD"
```

## STIG Compliance - Management Tooling 60-Day Credential Rotation

To meet the STIG 60-day credential rotation security mandate for admin accounts, use the standardized automated pipelines or cron routines. This solution handles password modifications natively within the pipeline runners and updates the target Azure Key Vault.

### On-Demand Automation (Jenkins & ADO Parameters)

Each pipeline provide parameters to execute target-specific rotation scripts on-demand.

* WDSF Jenkins parameter flag: `ROTATE_CREDENTIALS` (boolean toggle) combined with the `TARGET_TOOL` choice selection.
* C1 Azure DevOps parameter flags: `Rotate_Credentials` (boolean) and `Target_Tool` (string).

### Execution Architecture Workflow

When the rotation stage evaluates to true, the pipeline executes the matching step payload:

1. Authenticates to the cluster context natively via the runner identity.
2. Isolates the active tool controller pod replica in the target namespace (e.g., namespace `cattle-system` with label `app=core-app-rancher`).
3. Executes the internal admin password reset binary breakout command inside the primary container shell context.
4. Resolves the target Azure Key Vault vault, and persists the extracted secure token string value to secret path `<targettool>-admin-password` (which automatically updates the key vault metadata `Updated` timestamp).

### Continuous Compliance Monitoring (Nightly Audit Cron)

A separate daily midnight cron pipeline (`ado-pipelines/check-credential-expiry.yml`) runs the compliance auditor engine script:

1. Queries the Key Vault secret wrapper metadata for the target tool payload.
2. If the secret is missing (initial pre-rotation state), it dynamically connects to the cluster via `kubectl` to look up the application deployment context `creationTimestamp` to establish the baseline age.
3. Evaluates the tracking age. If it crosses the warning threshold of 55 days, a localized JSON report is written to the `k8s-credentials-alert` blob container.
4. The blob modification triggers an Azure Monitor KQL Scheduled Query rule alert routed directly to the `DevOps-Team` Action Group.

### Post-Automation Manual Validation Checklist (Rancher UI)

Using manual verification steps ensures a presentational health gate check and maintains human-in-the-loop integrity before downstream synchronization tasks:

1. Grab the generated string securely out of the cluster's specific Azure Key Vault instance secret payload (`rancher-admin-password`).
2. Establish a port-forward proxy to the Rancher service endpoint using your local terminal context:
```bash

# Map local network routing
kubectl port-forward svc/core-app-rancher 8443:443 -n cattle-system

```

3. Open a browser context inside the Bastion host session and target the localhost web interface address: `https://localhost:8443`.
4. Successfully authenticate as user `admin` using the fetched string to prove local container modifications matched presentational layer parameters.
5. In the top-right console, go to **User Settings -> API Keys** to delete expired legacy token records and provision fresh operational credentials to complete the cycle (we currently have none, but if you see any one apart from the UI session API key, rotate them).