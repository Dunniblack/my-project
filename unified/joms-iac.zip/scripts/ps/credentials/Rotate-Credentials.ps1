<#
.SYNOPSIS
    K8S Management Tools Credential Rotation Script
#>
param(
    [Parameter(Mandatory = $true)] [string]$ClusterName,
    [Parameter(Mandatory = $true)] [string]$ResourceGroupName,
    [Parameter(Mandatory = $true)] [string]$TargetTool,
    [Parameter(Mandatory = $true)] [string]$KeyVaultName,
    [Parameter(Mandatory = $true)] [string]$BinDir
)

. "$PSScriptRoot/../functions/CommonUtilities.ps1"
$ErrorActionPreference = "Stop"

# ─────────────────────────────────────────────────────────────────────────
# Make kubectl.exe and kubelogin.exe (downloaded by the Jenkins 'Download
# Dependencies' stage into $BinDir) resolvable via PATH for this session,
# and use a workspace-local kubeconfig so the agent's ~/.kube/config is
# not polluted. Mirrors the pattern established by Set-AksServerId.ps1.
# ─────────────────────────────────────────────────────────────────────────
$env:KUBECONFIG = "$BinDir\kubeconfig"
$env:Path += ";$BinDir"
if (Test-Path $env:KUBECONFIG) {
    Remove-Item $env:KUBECONFIG -Force
}

# Handle casing bug
$toolLower = $TargetTool.ToLower()

# KeyVaultName now passed as parameter from Terraform output

Write-Host "`n=========================================="
Write-Host "Standardized Credential Rotation Pipeline"
Write-Host "Cluster   : $ClusterName"
Write-Host "Target    : $toolLower"
Write-Host "Key Vault : $KeyVaultName"
Write-Host "==========================================`n"

Write-Host "Authenticating to AKS cluster $ClusterName..."
$null = Exec az aks get-credentials --resource-group $ResourceGroupName --name $ClusterName --overwrite-existing --format azure
$null = Exec "$BinDir\kubelogin.exe" convert-kubeconfig -l azurecli

# Patch the kubeconfig so the kubelogin exec plugin is referenced by its
# full path. kubectl invokes the exec plugin via PATH lookup when reading
# the kubeconfig; with $BinDir
(Get-Content $env:KUBECONFIG).Replace('kubelogin', "$BinDir\kubelogin.exe") | `
    Set-Content $env:KUBECONFIG

$newPassword = $null

switch ($toolLower) {
    "rancher" {
        Write-Host "Locating Rancher controller pod..."
        $podOutput = Exec kubectl -n cattle-system get pods -l app=rancher --no-headers
        $podName = ($podOutput -split '\s+')[0]

        if (-not $podName) { throw "Rancher controller pod not found." }

        Write-Host "Executing reset-password inside pod: $podName"
        $rawOutput = Exec kubectl -n cattle-system exec $podName -c rancher -- reset-password

        if ($rawOutput -match "New password for default administrator \(.*\):\s*(.*)") {
            $newPassword = $matches[1].Trim()
        }
        else { throw "Failed to parse Rancher output. Trace: $rawOutput" }
    }
    "argocd" {
        Write-Host "Nullifying active password strings from argocd secrets using JSON patch..."

        # Store JSON in variable to completely avoid PowerShell quote-mangling across the pipeline
        $patchJson = @"
[
  {
    "op": "replace",
    "path": "/data/admin.password",
    "value": null
  },
  {
    "op": "replace",
    "path": "/data/admin.passwordMtime",
    "value": null
  }
]
"@

        # Nullify argocd-secret using JSON patch type
        $null = Exec kubectl patch secret argocd-secret -n argocd --type='json' -p $patchJson

        Write-Host "Executing rollout restart on core-app-argocd-server..."
        $null = Exec kubectl -n argocd rollout restart deployment/core-app-argocd-server
        $null = Exec kubectl -n argocd rollout status deployment/core-app-argocd-server

        Write-Host "Retrieving newly generated password from argocd-initial-admin-secret..."
        $base64Pass = Exec kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}"

        if ([string]::IsNullOrEmpty($base64Pass)) {
            throw "ArgoCD initial admin secret password field is empty or failed to auto-regenerate."
        }

        # Decodes the payload into clean plaintext string
        $newPassword = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($base64Pass)).Trim()
    }
    default { throw "Unsupported tool specified: $toolLower" }
}

Write-Host "Updating Azure Key Vault secret '$toolLower-admin-password'..."
$SecretValue = ConvertTo-SecureString $newPassword -AsPlainText -Force
Set-AzKeyVaultSecret -VaultName $KeyVaultName -Name "$toolLower-admin-password" -SecretValue $SecretValue | Out-Null
Write-Host "Key Vault updated successfully. 60-day STIG compliance clock reset for $toolLower."
exit 0