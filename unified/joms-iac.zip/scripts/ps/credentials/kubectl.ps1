# "keycloak" {
  Write-Host "`n=========================================="
  Write-Host "Keycloak Credential Rotation Pipeline"
  Write-Host "==========================================`n"

  $namespace = "auth"

  # Helper function to extract Kubernetes secret data cleanly
  function Get-K8sSecretData {
      param([string]$SecretName, [string]$Key)
      $b64 = kubectl get secret $SecretName -n $namespace -o jsonpath="{.data.$Key}"
      if ([string]::IsNullOrEmpty($b64)) { throw "Secret $SecretName or key $Key not found." }
      return [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($b64)).Trim()
  }

  # Helper function to force ESO regeneration of immutable secrets
  function Reset-EsoSecret {
      param([string]$SecretName)
      Write-Host "Deleting immutable secret $SecretName to trigger ESO regeneration..."
      $null = kubectl delete secret $SecretName -n $namespace --ignore-not-found

      Write-Host "Waiting for ESO to regenerate $SecretName..."
      $timeout = 60
      $elapsed = 0
      while ($elapsed -lt $timeout) {
          $exists = kubectl get secret $SecretName -n $namespace --ignore-not-found
          if ($exists) {
              Write-Host "  -> Secret $SecretName regenerated successfully."
              return $true
          }
          Start-Sleep -Seconds 5
          $elapsed += 5
      }
      throw "Timed out waiting for ESO to regenerate secret $SecretName."
  }

  # -------------------------------------------------------------------
  # 1. Capture OLD Admin Password
  # -------------------------------------------------------------------
  Write-Host "Capturing current admin password for kcadm authentication..."
  $oldAdminPass = Get-K8sSecretData -SecretName "keycloak-admin-password" -Key "keycloak-admin-password"

  # -------------------------------------------------------------------
  # 2. Rotate DB Password & Restart DB
  # -------------------------------------------------------------------
  Reset-EsoSecret -SecretName "keycloak-pgpass"

  Write-Host "Restarting keycloak-db StatefulSet to trigger entrypoint ALTER USER..."
  $null = kubectl rollout restart statefulset/keycloak-db -n $namespace
  $null = kubectl rollout status statefulset/keycloak-db -n $namespace --timeout=120s
  Write-Host "Database password successfully rotated in PostgreSQL."

  # -------------------------------------------------------------------
  # 3. Rotate Admin Password & Capture NEW Password
  # -------------------------------------------------------------------
  Reset-EsoSecret -SecretName "keycloak-admin-password"
  $newAdminPass = Get-K8sSecretData -SecretName "keycloak-admin-password" -Key "keycloak-admin-password"

  # -------------------------------------------------------------------
  # 4. Pre-set NEW Admin Password in running Keycloak Pod
  # -------------------------------------------------------------------
  Write-Host "Locating running Keycloak pod..."
  # Adjust label selector if your chart uses a different label
  $kcPod = (kubectl -n $namespace get pods -l "app.kubernetes.io/name=keycloak" -o jsonpath='{.items[0].metadata.name}').Trim()
  if (-not $kcPod) {
      # Fallback to common label if standard isn't found
      $kcPod = (kubectl -n $namespace get pods -l "app=keycloak" -o jsonpath='{.items[0].metadata.name}').Trim()
  }
  if (-not $kcPod) { throw "No running Keycloak pod found in namespace $namespace." }

  Write-Host "Pre-setting new admin password in Keycloak via kcadm.sh in pod $kcPod..."

  # Using localhost:8080 inside the pod to bypass Ingress/TLS termination
  # Added --insecure to handle internal self-signed certs if HTTPS is forced on port 8443
  $kcCmd = "/opt/keycloak/bin/kcadm.sh config credentials --realm master --user admin --password '$oldAdminPass' --server http://localhost:8080 --insecure && /opt/keycloak/bin/kcadm.sh set-password -r master --username admin --new-password '$newAdminPass'"

  kubectl -n $namespace exec $kcPod -- /bin/sh -c $kcCmd
  Write-Host "Keycloak internal admin password successfully updated."

  # -------------------------------------------------------------------
  # 5. Restart Keycloak Deployment
  # -------------------------------------------------------------------
  Write-Host "Restarting Keycloak Deployment to pick up new DB password and run bootstrap..."
  # Adjust deployment name if your chart names it differently
  $null = kubectl rollout restart deployment/keycloak -n $namespace
  $null = kubectl rollout status deployment/keycloak -n $namespace --timeout=300s

  Write-Host "Keycloak credential rotation completed successfully."
# }