```ps1
PS C:\Users\anuoluwapo.ikudaisi\Documents\Projects\IAC Project\scripts\ps\credentials> kubectl get pod keycloak-68ddf45744-x97n7 -n auth -o yaml
apiVersion: v1
kind: Pod
metadata:
  annotations:
    kubernetes.io/limit-ranger: 'LimitRanger plugin set: cpu limit for init container
      init-certs; cpu limit for init container init-cloud1-certs; cpu limit for init
      container liquibase'
    maintainers: CMP / Bacon
  creationTimestamp: "2026-06-23T15:52:45Z"
  generateName: keycloak-68ddf45744-
  generation: 1
  labels:
    app.kubernetes.io/component: service
    app.kubernetes.io/instance: core-app
    app.kubernetes.io/managed-by: Helm
    app.kubernetes.io/name: keycloak
    app.kubernetes.io/part-of: noms-infrastructure
    app.kubernetes.io/version: 6.3.0
    app.noms.io/discovery-name: keycloak
    extracomponents/checksum: 70f589eec29fc1edba20c17b8962b78345943ff0c80897ec50dab390ba84129
    helm.sh/chart: keycloak-8.0.0-develop.9
    ldap: external-ldap
    ocsp: external-ocsp
    partOf: noms-infrastructure
    pod-template-hash: 68ddf45744
    priorityClassName: none
  name: keycloak-68ddf45744-x97n7
  namespace: auth
  ownerReferences:
  - apiVersion: apps/v1
    blockOwnerDeletion: true
    controller: true
    kind: ReplicaSet
    name: keycloak-68ddf45744
    uid: b1b061d3-1d2a-4712-8086-648141bc666d
  resourceVersion: "6921969"
  uid: b38d1d3e-dfb5-4648-b8d8-0c997b14b50d
spec:
  affinity:
    podAffinity:
      preferredDuringSchedulingIgnoredDuringExecution:
      - podAffinityTerm:
          labelSelector:
            matchExpressions:
            - key: app.kubernetes.io/name
              operator: In
              values:
              - noms-postgis-db
          topologyKey: kubernetes.io/hostname
        weight: 100
  containers:
  - command:
    - /bin/sh
    - -c
    - /script/keycloak-bootstrap.sh & /script/startup.sh
    env:
    - name: JAVA_OPTS_APPEND
      value: -Dcom.redhat.fips=true -Dorg.infinispan.security.fips.enable=true
    - name: KC_OPTS
      value: -Djava.security.properties=/tmp/kcadm.java.security
    - name: KC_HTTPS_KEY_STORE_FILE
      value: /noms-certs/noms-server.bcfks
    - name: KC_HTTPS_KEY_STORE_TYPE
      value: BCFKS
    - name: POD_NAMESPACE
      valueFrom:
        fieldRef:
          apiVersion: v1
          fieldPath: metadata.namespace
    - name: USER_DB_URL
      valueFrom:
        configMapKeyRef:
          key: user-service-db
          name: infrastructure-databases-env
    - name: KC_DB_URL_HOST
      valueFrom:
        configMapKeyRef:
          key: keycloak-db
          name: infrastructure-databases-env
    - name: KC_TRUSTSTORE_PATHS
      value: /noms-certs/,/dod-root-certs/,/cloud1-certs/
    - name: LDAP_URL
      value: ldaps://$(LDAP_DOMAIN_NAME):1636
    - name: KC_HOSTNAME_STRICT
      value: "false"
    - name: KC_DB
      value: postgres
    - name: KC_CACHE
      value: local
    - name: KC_DB_USERNAME
      value: keycloak
    - name: USER_DB_LOGIN
      value: keycloak_token_enhancer
    - name: KC_HTTP_RELATIVE_PATH
      value: /auth/keycloak/auth
    - name: FORCE_INIT
      value: "false"
    - name: KC_HTTPS_CLIENT_AUTH
      value: none
    - name: KC_HEALTH_ENABLED
      value: "true"
    - name: KC_METRICS_ENABLED
      value: "true"
    - name: ENABLED_EVENT_TYPES
      value: enabledEventTypes=["AUTHREQID_TO_TOKEN","AUTHREQID_TO_TOKEN_ERROR","CLIENT_DELETE_ERROR","CLIENT_INFO","CLIENT_INFO_ERROR","CLIENT_INITIATED_ACCOUNT_LINKING_ERROR","CLIENT_LOGIN","CLIENT_LOGIN_ERROR","CLIENT_REGISTER_ERROR","CLIENT_UPDATE_ERROR","CODE_TO_TOKEN_ERROR","CUSTOM_REQUIRED_ACTION_ERROR","DELETE_ACCOUNT","DELETE_ACCOUNT_ERROR","EXECUTE_ACTION_TOKEN_ERROR","EXECUTE_ACTIONS_ERROR","FEDERATED_IDENTITY_LINK_ERROR","GRANT_CONSENT","GRANT_CONSENT_ERROR","IDENTITY_PROVIDER_FIRST_LOGIN","IDENTITY_PROVIDER_FIRST_LOGIN_ERROR","IDENTITY_PROVIDER_LINK_ACCOUNT","IDENTITY_PROVIDER_LINK_ACCOUNT_ERROR","IDENTITY_PROVIDER_LOGIN","IDENTITY_PROVIDER_LOGIN_ERROR","IDENTITY_PROVIDER_POST_LOGIN_ERROR","IDENTITY_PROVIDER_RESPONSE_ERROR","IDENTITY_PROVIDER_RETRIEVE_TOKEN","IDENTITY_PROVIDER_RETRIEVE_TOKEN_ERROR","IMPERSONATE","IMPERSONATE_ERROR","INTROSPECT_TOKEN_ERROR","INVALID_SIGNATURE","INVALID_SIGNATURE_ERROR","LOGIN","LOGIN_ERROR","LOGOUT","LOGOUT_ERROR","OAUTH2_DEVICE_AUTH","OAUTH2_DEVICE_AUTH_ERROR","OAUTH2_DEVICE_CODE_TO_TOKEN_ERROR","OAUTH2_DEVICE_VERIFY_USER_CODE","OAUTH2_DEVICE_VERIFY_USER_CODE_ERROR","PERMISSION_TOKEN_ERROR","PUSHED_AUTHORIZATION_REQUEST","PUSHED_AUTHORIZATION_REQUEST_ERROR","REFRESH_TOKEN_ERROR","REGISTER_ERROR","REGISTER_NODE_ERROR","REMOVE_FEDERATED_IDENTITY_ERROR","REMOVE_TOTP_ERROR","RESET_PASSWORD_ERROR","RESTART_AUTHENTICATION","RESTART_AUTHENTICATION_ERROR","REVOKE_GRANT_ERROR","SEND_IDENTITY_PROVIDER_LINK_ERROR","SEND_RESET_PASSWORD_ERROR","SEND_VERIFY_EMAIL_ERROR","TOKEN_EXCHANGE","TOKEN_EXCHANGE_ERROR","UNREGISTER_NODE_ERROR","UPDATE_CONSENT_ERROR","UPDATE_EMAIL_ERROR","UPDATE_PASSWORD","UPDATE_PASSWORD_ERROR","UPDATE_PROFILE_ERROR","UPDATE_TOTP_ERROR","USER_INFO_REQUEST_ERROR","VALIDATE_ACCESS_TOKEN_ERROR","VERIFY_EMAIL_ERROR","VERIFY_PROFILE_ERROR"]
    - name: KC_TRANSACTION_XA_ENABLED
      value: "true"
    - name: ASPNETCORE_URLS
      value: https://+:8443
    image: nexus.seicdevops.com/docker-dev-share/noms/keycloak:6.3.0
    imagePullPolicy: IfNotPresent
    livenessProbe:
      failureThreshold: 3
      httpGet:
        path: /auth/keycloak/auth/health/live
        port: 9000
        scheme: HTTPS
      periodSeconds: 10
      successThreshold: 1
      timeoutSeconds: 5
    name: keycloak
    ports:
    - containerPort: 8443
      name: auth
      protocol: TCP
    - containerPort: 8444
      name: port1
      protocol: TCP
    readinessProbe:
      failureThreshold: 3
      httpGet:
        path: /auth/keycloak/auth/health/ready
        port: 9000
        scheme: HTTPS
      initialDelaySeconds: 30
      periodSeconds: 10
      successThreshold: 1
      timeoutSeconds: 1
    resources:
      limits:
        cpu: "2"
        memory: 1500Mi
      requests:
        cpu: 250m
        memory: 1000Mi
    securityContext:
      allowPrivilegeEscalation: false
    startupProbe:
      exec:
        command:
        - echo
        - started
      failureThreshold: 78
      initialDelaySeconds: 1
      periodSeconds: 10
      successThreshold: 1
      timeoutSeconds: 1
    terminationMessagePath: /dev/termination-log
    terminationMessagePolicy: File
    volumeMounts:
    - mountPath: /secrets/client-secrets/noms/argocd
      name: argocd-client-secret-volume
      readOnly: true
      subPath: argocd
    - mountPath: /secrets/client-secrets/noms/grafana
      name: grafana-client-secret-volume
      readOnly: true
      subPath: grafana
    - mountPath: /secrets/keycloak-admin/keycloak-admin-password
      name: keycloak-admin-password-volume
      readOnly: true
      subPath: keycloak-admin-password
    - mountPath: /secrets/client-secrets/noms/minio
      name: minio-password-volume
      readOnly: true
      subPath: minio
    - mountPath: /secrets/user-secrets-required/noms/nomsadmin
      name: nomsadmin-password-volume
      readOnly: true
      subPath: nomsadmin
    - mountPath: /secrets/client-secrets/noms/rancher
      name: rancher-client-secret-volume
      readOnly: true
      subPath: rancher
    - mountPath: /secrets/user-secrets-required/noms/service-account-manager
      name: service-account-manager-volume
      readOnly: true
      subPath: service-account-manager
    - mountPath: /secrets/client-secrets/noms/prismacloud
      name: twistlock-client-secret-volume
      readOnly: true
      subPath: prismacloud
    - mountPath: /secrets/certstore-password
      name: certstore-password-volume
      readOnly: true
      subPath: certstore-password
    - mountPath: /secrets/server.ssl.trust-store-password
      name: certstore-password-volume
      readOnly: true
      subPath: server.ssl.trust-store-password
    - mountPath: /secrets/server__ssl__trust-store-password
      name: certstore-password-volume
      readOnly: true
      subPath: server__ssl__trust-store-password
    - mountPath: /secrets/server__ssl__key-store-password
      name: certstore-password-volume
      readOnly: true
      subPath: server__ssl__key-store-password
    - mountPath: /secrets/Kestrel__Certificates__Default__Password
      name: certstore-password-volume
      readOnly: true
      subPath: Kestrel__Certificates__Default__Password
    - mountPath: /secrets/keycloak-db/keycloak
      name: keycloak-pgpass-volume
      readOnly: true
      subPath: keycloak
    - mountPath: /liquibase-secrets/liquibase_noms_users
      name: liquibase-noms-users-volume
      readOnly: true
      subPath: liquibase_noms_users
    - mountPath: /secrets/user-federation-secrets/noms/noms-ldap
      name: noms-manager-password-volume
      readOnly: true
      subPath: noms-ldap
    - mountPath: /secrets/token-enhancer/user-db
      name: noms-postgis-keycloak-token-enhancer-volume
      readOnly: true
      subPath: user-db
    - mountPath: /noms-certs
      mountPropagation: None
      name: service-certs
    - mountPath: /data
      name: data
    - mountPath: /script
      mountPropagation: None
      name: keycloak-bootstrap-script
    - mountPath: /cloud1-certs
      name: cloud1-certs
    - mountPath: components
      name: keycloak-components
    - mountPath: /dod-root-certs
      name: dodroot-certs
    - mountPath: /unused-dir/
      name: liquibase-changelog-volume-v2
    - mountPath: /var/run/secrets/kubernetes.io/serviceaccount
      name: kube-api-access-2wmxp
      readOnly: true
  dnsPolicy: ClusterFirst
  enableServiceLinks: true
  imagePullSecrets:
  - name: image-pull-credentials
  initContainers:
  - args:
    - -c
    - "password=$(cat /secrets/certstore-password) \nrm -f $truststore_jks \nrm -f
      $truststore_p12\nrm -f $keystore_p12 \ncp /var/run/secrets/noms-certs/services_serving_certs/*
      /noms-certs/ \nopenssl pkcs12 -nomac -export -inkey $keyfile -in $crtfile -out
      $keystore_p12 -password pass:$password -name 'noms server certificate' -chain
      -CAfile /var/run/secrets/noms-certs/services_serving_certs/noms-cacert.pem -caname
      'noms ca certificate'\ncp /var/run/secrets/noms-certs/services_serving_certs/noms-cacert.pem
      $certsDir/cacert.pem\nkeytool -noprompt -importkeystore -srckeystore $JAVA_HOME/jre/lib/security/cacerts
      -srcstoretype JKS -srcstorepass changeit -destkeystore $truststore_jks -deststorepass
      $password -v -J-Dcom.redhat.fips=false \nkeytool -noprompt -importkeystore -srckeystore
      $JAVA_HOME/jre/lib/security/cacerts -srcstoretype JKS -srcstorepass changeit
      -destkeystore $truststore_p12 -deststorepass $password -v -J-Dcom.redhat.fips=false
      \nkeytool -noprompt -importkeystore -srckeystore $keystore_p12 -srcstoretype
      PKCS12 -destkeystore $truststore_jks -storepass $password -srcstorepass $password
      \ -v -J-Dcom.redhat.fips=false \nkeytool -noprompt -importkeystore -srckeystore
      $keystore_p12 -srcstoretype PKCS12 -destkeystore $truststore_p12 -storepass
      $password -srcstorepass $password  -v -J-Dcom.redhat.fips=false \ncd $certsDir
      \ncat $ca_bundle | awk 'split_after==1{n++;split_after=0}/-----END CERTIFICATE-----/
      {split_after=1}{if(length($0) > 0) print > \"cert\" n \".pem\"}' \n[[ -f /etc/ssl/certs/ca-certificates.crt
      ]] && cat /etc/ssl/certs/ca-certificates.crt $ca_bundle /noms-certs/cacert.pem
      > /noms-certs/ca-bundle.crt\n[[ -f /etc/pki/tls/certs/ca-bundle.crt ]] && cat
      /etc/pki/tls/certs/ca-bundle.crt $ca_bundle /noms-certs/cacert.pem > /noms-certs/ca-bundle.crt\nfor
      file in *.pem; do keytool -import -noprompt -keystore $truststore_jks -file
      $file -storepass $password -alias service-$file  -v -J-Dcom.redhat.fips=false;
      done \nfor file in *.pem; do keytool -import -noprompt -keystore $truststore_p12
      -file $file -storepass $password -alias service-$file  -v -J-Dcom.redhat.fips=false;
      done \nkeytool -noprompt -importkeystore -srckeystore $truststore_jks -srcstoretype
      JKS -destkeystore $keystore_p12 -deststoretype PKCS12 -storepass $password -srcstorepass
      $password  -v -J-Dcom.redhat.fips=false \ncp $keystore_p12 /noms-certs/noms-server.p12
      \nchmod 600 /noms-certs/* \nls $certsDir"
    command:
    - /bin/sh
    env:
    - name: ca_bundle
      value: /var/run/secrets/kubernetes.io/serviceaccount/ca.crt
    - name: keyfile
      value: /var/run/secrets/noms-certs/services_serving_certs/tls.key
    - name: crtfile
      value: /var/run/secrets/noms-certs/services_serving_certs/tls.crt
    - name: keystore_p12
      value: /noms-certs/noms-server-linux-dotnet.p12
    - name: truststore_jks
      value: /noms-certs/truststore.jks
    - name: truststore_p12
      value: /noms-certs/truststore.p12
    - name: certsDir
      value: /noms-certs
    image: nexus.seicdevops.com/docker-dev-share/noms/init-certs:5.2.0
    imagePullPolicy: IfNotPresent
    name: init-certs
    resources:
      limits:
        cpu: "1"
        memory: 256Mi
      requests:
        cpu: 1m
        memory: 32Mi
    securityContext:
      allowPrivilegeEscalation: false
    terminationMessagePath: /dev/termination-log
    terminationMessagePolicy: File
    volumeMounts:
    - mountPath: /noms-certs/
      name: service-certs
    - mountPath: /var/run/secrets/noms-certs/services_serving_certs/
      name: noms-custom-certs
    - mountPath: /secrets
      name: certstore-password-volume
    - mountPath: /var/run/secrets/kubernetes.io/serviceaccount
      name: kube-api-access-2wmxp
      readOnly: true
  - command:
    - /bin/sh
    - -c
    - password=$(cat /secrets/certstore-password) && ls -al /noms-certs && keytool
      -import -noprompt -keystore /noms-certs/truststore.p12 -file /cloud1-certs/cloud1-cert-chain.pem
      -storepass $password -alias cloud1-cert-chain.pem
    image: nexus.seicdevops.com/docker-dev-share/noms/init-certs:5.2.0
    imagePullPolicy: IfNotPresent
    name: init-cloud1-certs
    resources:
      limits:
        cpu: "1"
        memory: 256Mi
      requests:
        cpu: 1m
        memory: 128Mi
    securityContext:
      allowPrivilegeEscalation: false
    terminationMessagePath: /dev/termination-log
    terminationMessagePolicy: File
    volumeMounts:
    - mountPath: /cloud1-certs
      name: cloud1-certs
    - mountPath: /noms-certs
      name: service-certs
    - mountPath: /secrets
      name: certstore-password-volume
    - mountPath: /var/run/secrets/kubernetes.io/serviceaccount
      name: kube-api-access-2wmxp
      readOnly: true
  - args:
    - -c
    - |
      pw=$(cat /liquibase-secrets/liquibase_noms_users) && /liquibase/docker-entrypoint.sh --username=liquibase_noms_users --password=$pw --search-path=/user-service-db/,/liquibase/changelogs.d/v2 update --url=jdbc:postgresql://noms-postgis-db:5432/noms_users
    command:
    - /bin/sh
    env:
    - name: LIQUIBASE_COMMAND_CHANGELOG_FILE
      value: root.yml
    image: nexus.seicdevops.com/docker-dev-share/noms/liquibase-user-service:2.1.0
    imagePullPolicy: IfNotPresent
    name: liquibase
    resources:
      limits:
        cpu: "1"
        memory: 512Mi
      requests:
        cpu: 15m
        memory: 128M
    terminationMessagePath: /dev/termination-log
    terminationMessagePolicy: File
    volumeMounts:
    - mountPath: /user-service-db/
      name: liquibase-changelog-volume-v2
    - mountPath: /secrets/client-secrets/noms/argocd
      name: argocd-client-secret-volume
      readOnly: true
      subPath: argocd
    - mountPath: /secrets/client-secrets/noms/grafana
      name: grafana-client-secret-volume
      readOnly: true
      subPath: grafana
    - mountPath: /secrets/keycloak-admin/keycloak-admin-password
      name: keycloak-admin-password-volume
      readOnly: true
      subPath: keycloak-admin-password
    - mountPath: /secrets/client-secrets/noms/minio
      name: minio-password-volume
      readOnly: true
      subPath: minio
    - mountPath: /secrets/user-secrets-required/noms/nomsadmin
      name: nomsadmin-password-volume
      readOnly: true
      subPath: nomsadmin
    - mountPath: /secrets/client-secrets/noms/rancher
      name: rancher-client-secret-volume
      readOnly: true
      subPath: rancher
    - mountPath: /secrets/user-secrets-required/noms/service-account-manager
      name: service-account-manager-volume
      readOnly: true
      subPath: service-account-manager
    - mountPath: /secrets/client-secrets/noms/prismacloud
      name: twistlock-client-secret-volume
      readOnly: true
      subPath: prismacloud
    - mountPath: /secrets/certstore-password
      name: certstore-password-volume
      readOnly: true
      subPath: certstore-password
    - mountPath: /secrets/server.ssl.trust-store-password
      name: certstore-password-volume
      readOnly: true
      subPath: server.ssl.trust-store-password
    - mountPath: /secrets/server__ssl__trust-store-password
      name: certstore-password-volume
      readOnly: true
      subPath: server__ssl__trust-store-password
    - mountPath: /secrets/server__ssl__key-store-password
      name: certstore-password-volume
      readOnly: true
      subPath: server__ssl__key-store-password
    - mountPath: /secrets/Kestrel__Certificates__Default__Password
      name: certstore-password-volume
      readOnly: true
      subPath: Kestrel__Certificates__Default__Password
    - mountPath: /secrets/keycloak-db/keycloak
      name: keycloak-pgpass-volume
      readOnly: true
      subPath: keycloak
    - mountPath: /liquibase-secrets/liquibase_noms_users
      name: liquibase-noms-users-volume
      readOnly: true
      subPath: liquibase_noms_users
    - mountPath: /secrets/user-federation-secrets/noms/noms-ldap
      name: noms-manager-password-volume
      readOnly: true
      subPath: noms-ldap
    - mountPath: /secrets/token-enhancer/user-db
      name: noms-postgis-keycloak-token-enhancer-volume
      readOnly: true
      subPath: user-db
    - mountPath: /var/run/secrets/kubernetes.io/serviceaccount
      name: kube-api-access-2wmxp
      readOnly: true
  nodeName: aks-systempool-15555520-vmss000000
  nodeSelector:
    kubernetes.io/os: linux
  preemptionPolicy: PreemptLowerPriority
  priority: 0
  restartPolicy: Always
  schedulerName: default-scheduler
  securityContext:
    runAsNonRoot: true
    runAsUser: 10000
    seccompProfile:
      type: RuntimeDefault
  serviceAccount: core-app-keycloak
  serviceAccountName: core-app-keycloak
  terminationGracePeriodSeconds: 30
  tolerations:
  - effect: NoExecute
    key: node.kubernetes.io/not-ready
    operator: Exists
    tolerationSeconds: 300
  - effect: NoExecute
    key: node.kubernetes.io/unreachable
    operator: Exists
    tolerationSeconds: 300
  - effect: NoSchedule
    key: node.kubernetes.io/memory-pressure
    operator: Exists
  volumes:
  - name: argocd-client-secret-volume
    secret:
      defaultMode: 420
      items:
      - key: argocd-client-secret
        path: argocd
      optional: false
      secretName: argocd-client-secret
  - name: grafana-client-secret-volume
    secret:
      defaultMode: 420
      items:
      - key: grafana-client-secret
        path: grafana
      optional: false
      secretName: grafana-client-secret
  - name: keycloak-admin-password-volume
    secret:
      defaultMode: 420
      optional: false
      secretName: keycloak-admin-password
  - name: minio-password-volume
    secret:
      defaultMode: 420
      items:
      - key: minio-password
        path: minio
      optional: false
      secretName: minio-password
  - name: nomsadmin-password-volume
    secret:
      defaultMode: 420
      items:
      - key: nomsadmin-password
        path: nomsadmin
      optional: false
      secretName: nomsadmin-password
  - name: rancher-client-secret-volume
    secret:
      defaultMode: 420
      items:
      - key: rancher-client-secret
        path: rancher
      optional: false
      secretName: rancher-client-secret
  - name: service-account-manager-volume
    secret:
      defaultMode: 420
      items:
      - key: service-account-manager
        path: service-account-manager
      optional: false
      secretName: service-account-manager
  - name: twistlock-client-secret-volume
    secret:
      defaultMode: 420
      items:
      - key: twistlock-client-secret
        path: prismacloud
      optional: false
      secretName: twistlock-client-secret
  - name: certstore-password-volume
    secret:
      defaultMode: 420
      items:
      - key: certstore-password
        path: certstore-password
      - key: certstore-password
        path: server.ssl.trust-store-password
      - key: certstore-password
        path: server__ssl__trust-store-password
      - key: certstore-password
        path: server__ssl__key-store-password
      - key: certstore-password
        path: Kestrel__Certificates__Default__Password
      optional: false
      secretName: certstore-password
  - name: keycloak-pgpass-volume
    secret:
      defaultMode: 420
      items:
      - key: keycloak-pgpass
        path: keycloak
      optional: false
      secretName: keycloak-pgpass
  - name: liquibase-noms-users-volume
    secret:
      defaultMode: 420
      items:
      - key: liquibase-noms-users
        path: liquibase_noms_users
      optional: false
      secretName: liquibase-noms-users
  - name: noms-manager-password-volume
    secret:
      defaultMode: 420
      items:
      - key: noms-manager-password
        path: noms-ldap
      optional: true
      secretName: noms-manager-password
  - name: noms-postgis-keycloak-token-enhancer-volume
    secret:
      defaultMode: 420
      items:
      - key: noms-postgis-keycloak-token-enhancer
        path: user-db
      optional: false
      secretName: noms-postgis-keycloak-token-enhancer
  - emptyDir: {}
    name: service-certs
  - name: noms-custom-certs
    secret:
      defaultMode: 420
      optional: false
      secretName: noms-certs
  - emptyDir: {}
    name: data
  - configMap:
      defaultMode: 420
      name: keycloak-config
    name: keycloak-config
  - configMap:
      defaultMode: 508
      name: keycloak-bootstrap-script
      optional: false
    name: keycloak-bootstrap-script
  - configMap:
      defaultMode: 420
      name: cloud1-certs
    name: cloud1-certs
  - configMap:
      defaultMode: 420
      name: keycloak-components
    name: keycloak-components
  - configMap:
      defaultMode: 420
      name: dodroot-certs
      optional: true
    name: dodroot-certs
  - configMap:
      defaultMode: 420
      name: keycloak-v2-change-logs
    name: liquibase-changelog-volume-v2
  - name: kube-api-access-2wmxp
    projected:
      defaultMode: 420
      sources:
      - serviceAccountToken:
          expirationSeconds: 3607
          path: token
      - configMap:
          items:
          - key: ca.crt
            path: ca.crt
          name: kube-root-ca.crt
      - downwardAPI:
          items:
          - fieldRef:
              apiVersion: v1
              fieldPath: metadata.namespace
            path: namespace
status:
  conditions:
  - lastProbeTime: null
    lastTransitionTime: "2026-06-23T15:53:19Z"
    observedGeneration: 1
    status: "True"
    type: PodReadyToStartContainers
  - lastProbeTime: null
    lastTransitionTime: "2026-06-23T16:00:03Z"
    observedGeneration: 1
    status: "True"
    type: Initialized
  - lastProbeTime: null
    lastTransitionTime: "2026-07-02T23:12:19Z"
    message: 'containers with unready status: [keycloak]'
    observedGeneration: 1
    reason: ContainersNotReady
    status: "False"
    type: Ready
  - lastProbeTime: null
    lastTransitionTime: "2026-07-02T23:12:19Z"
    message: 'containers with unready status: [keycloak]'
    observedGeneration: 1
    reason: ContainersNotReady
    status: "False"
    type: ContainersReady
  - lastProbeTime: null
    lastTransitionTime: "2026-06-23T15:52:45Z"
    observedGeneration: 1
    status: "True"
    type: PodScheduled
  containerStatuses:
  - allocatedResources:
      cpu: 250m
      memory: 1000Mi
    containerID: containerd://9d159b96d4e0ca9c0b7212619e20b4199cb7d34fa364e393b271602ad4f1a197
    image: nexus.seicdevops.com/docker-dev-share/noms/keycloak:6.3.0
    imageID: nexus.seicdevops.com/docker-dev-share/noms/keycloak@sha256:f9379a742a339dfe802fcb1afd0f1d0cfc1b8e0460f097b3e8da1d8b76cf6a76
    lastState:
      terminated:
        containerID: containerd://128ab8dfbb2ee745d4872725f0c8f2127b609b1e5d9702380e9eaf4d93c968d3
        exitCode: 137
        finishedAt: "2026-06-23T16:01:18Z"
        reason: Error
        startedAt: "2026-06-23T16:00:15Z"
    name: keycloak
    ready: false
    resources:
      limits:
        cpu: "2"
        memory: 1500Mi
      requests:
        cpu: 250m
        memory: 1000Mi
    restartCount: 1
    started: true
    state:
      running:
        startedAt: "2026-06-23T16:01:18Z"
    user:
      linux:
        gid: 0
        supplementalGroups:
        - 0
        uid: 10000
    volumeMounts:
    - mountPath: /secrets/client-secrets/noms/argocd
      name: argocd-client-secret-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/client-secrets/noms/grafana
      name: grafana-client-secret-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/keycloak-admin/keycloak-admin-password
      name: keycloak-admin-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/client-secrets/noms/minio
      name: minio-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/user-secrets-required/noms/nomsadmin
      name: nomsadmin-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/client-secrets/noms/rancher
      name: rancher-client-secret-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/user-secrets-required/noms/service-account-manager
      name: service-account-manager-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/client-secrets/noms/prismacloud
      name: twistlock-client-secret-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/certstore-password
      name: certstore-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/server.ssl.trust-store-password
      name: certstore-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/server__ssl__trust-store-password
      name: certstore-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/server__ssl__key-store-password
      name: certstore-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/Kestrel__Certificates__Default__Password
      name: certstore-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/keycloak-db/keycloak
      name: keycloak-pgpass-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /liquibase-secrets/liquibase_noms_users
      name: liquibase-noms-users-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/user-federation-secrets/noms/noms-ldap
      name: noms-manager-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/token-enhancer/user-db
      name: noms-postgis-keycloak-token-enhancer-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /noms-certs
      name: service-certs
    - mountPath: /data
      name: data
    - mountPath: /script
      name: keycloak-bootstrap-script
    - mountPath: /cloud1-certs
      name: cloud1-certs
    - mountPath: components
      name: keycloak-components
    - mountPath: /dod-root-certs
      name: dodroot-certs
    - mountPath: /unused-dir/
      name: liquibase-changelog-volume-v2
    - mountPath: /var/run/secrets/kubernetes.io/serviceaccount
      name: kube-api-access-2wmxp
      readOnly: true
      recursiveReadOnly: Disabled
  hostIP: 172.18.0.30
  hostIPs:
  - ip: 172.18.0.30
  initContainerStatuses:
  - allocatedResources:
      cpu: 1m
      memory: 32Mi
    containerID: containerd://27efc6edc1003e1fe1512e4e3e20a34237a79f29f031edf0f2fa25da978d2673
    image: nexus.seicdevops.com/docker-dev-share/noms/init-certs:5.2.0
    imageID: nexus.seicdevops.com/docker-dev-share/noms/init-certs@sha256:38c1c80e68b0d9e6a7d87cb590c9a36c9665a417a1894a5f77f95f0a6c4d171d
    lastState: {}
    name: init-certs
    ready: true
    resources:
      limits:
        cpu: "1"
        memory: 256Mi
      requests:
        cpu: 1m
        memory: 32Mi
    restartCount: 0
    started: false
    state:
      terminated:
        containerID: containerd://27efc6edc1003e1fe1512e4e3e20a34237a79f29f031edf0f2fa25da978d2673
        exitCode: 0
        finishedAt: "2026-06-23T15:53:31Z"
        reason: Completed
        startedAt: "2026-06-23T15:53:18Z"
    user:
      linux:
        gid: 10001
        supplementalGroups:
        - 10001
        uid: 10000
    volumeMounts:
    - mountPath: /noms-certs/
      name: service-certs
    - mountPath: /var/run/secrets/noms-certs/services_serving_certs/
      name: noms-custom-certs
    - mountPath: /secrets
      name: certstore-password-volume
    - mountPath: /var/run/secrets/kubernetes.io/serviceaccount
      name: kube-api-access-2wmxp
      readOnly: true
      recursiveReadOnly: Disabled
  - allocatedResources:
      cpu: 1m
      memory: 128Mi
    containerID: containerd://05ad68b2a35188e7140319a640f7e5378b17f5905d6be7c0c71894b183b5335f
    image: nexus.seicdevops.com/docker-dev-share/noms/init-certs:5.2.0
    imageID: nexus.seicdevops.com/docker-dev-share/noms/init-certs@sha256:38c1c80e68b0d9e6a7d87cb590c9a36c9665a417a1894a5f77f95f0a6c4d171d
    lastState: {}
    name: init-cloud1-certs
    ready: true
    resources:
      limits:
        cpu: "1"
        memory: 256Mi
      requests:
        cpu: 1m
        memory: 128Mi
    restartCount: 0
    started: false
    state:
      terminated:
        containerID: containerd://05ad68b2a35188e7140319a640f7e5378b17f5905d6be7c0c71894b183b5335f
        exitCode: 0
        finishedAt: "2026-06-23T15:53:33Z"
        reason: Completed
        startedAt: "2026-06-23T15:53:32Z"
    user:
      linux:
        gid: 10001
        supplementalGroups:
        - 10001
        uid: 10000
    volumeMounts:
    - mountPath: /cloud1-certs
      name: cloud1-certs
    - mountPath: /noms-certs
      name: service-certs
    - mountPath: /secrets
      name: certstore-password-volume
    - mountPath: /var/run/secrets/kubernetes.io/serviceaccount
      name: kube-api-access-2wmxp
      readOnly: true
      recursiveReadOnly: Disabled
  - allocatedResources:
      cpu: 15m
      memory: 128M
    containerID: containerd://0a0080748360bbf944ca79128d0a83a4502f9f00c0c4cd9d7e07331404aec4bf
    image: nexus.seicdevops.com/docker-dev-share/noms/liquibase-user-service:2.1.0
    imageID: nexus.seicdevops.com/docker-dev-share/noms/liquibase-user-service@sha256:b97707c2851a29bd79b793da34c543689422ec420893f256654ac026c3832410
    lastState: {}
    name: liquibase
    ready: true
    resources:
      limits:
        cpu: "1"
        memory: 512Mi
      requests:
        cpu: 15m
        memory: 128M
    restartCount: 6
    started: false
    state:
      terminated:
        containerID: containerd://0a0080748360bbf944ca79128d0a83a4502f9f00c0c4cd9d7e07331404aec4bf
        exitCode: 0
        finishedAt: "2026-06-23T16:00:03Z"
        reason: Completed
        startedAt: "2026-06-23T15:59:56Z"
    user:
      linux:
        gid: 0
        supplementalGroups:
        - 0
        uid: 10000
    volumeMounts:
    - mountPath: /user-service-db/
      name: liquibase-changelog-volume-v2
    - mountPath: /secrets/client-secrets/noms/argocd
      name: argocd-client-secret-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/client-secrets/noms/grafana
      name: grafana-client-secret-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/keycloak-admin/keycloak-admin-password
      name: keycloak-admin-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/client-secrets/noms/minio
      name: minio-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/user-secrets-required/noms/nomsadmin
      name: nomsadmin-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/client-secrets/noms/rancher
      name: rancher-client-secret-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/user-secrets-required/noms/service-account-manager
      name: service-account-manager-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/client-secrets/noms/prismacloud
      name: twistlock-client-secret-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/certstore-password
      name: certstore-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/server.ssl.trust-store-password
      name: certstore-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/server__ssl__trust-store-password
      name: certstore-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/server__ssl__key-store-password
      name: certstore-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/Kestrel__Certificates__Default__Password
      name: certstore-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/keycloak-db/keycloak
      name: keycloak-pgpass-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /liquibase-secrets/liquibase_noms_users
      name: liquibase-noms-users-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/user-federation-secrets/noms/noms-ldap
      name: noms-manager-password-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /secrets/token-enhancer/user-db
      name: noms-postgis-keycloak-token-enhancer-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /var/run/secrets/kubernetes.io/serviceaccount
      name: kube-api-access-2wmxp
      readOnly: true
      recursiveReadOnly: Disabled
  observedGeneration: 1
  phase: Running
  podIP: 10.244.0.200
  podIPs:
  - ip: 10.244.0.200
  qosClass: Burstable
  startTime: "2026-06-23T15:52:45Z"
```