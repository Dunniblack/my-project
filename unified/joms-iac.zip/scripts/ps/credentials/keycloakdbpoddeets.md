```ps1
PS C:\Users\anuoluwapo.ikudaisi\Documents\Projects\IAC Project\scripts\ps\credentials> kubectl get pod -n auth keycloak-db-0 -o yaml
apiVersion: v1
kind: Pod
metadata:
  annotations:
    kubectl.kubernetes.io/restartedAt: "2026-07-02T18:57:50-04:00"
    maintainers: CMP / Bacon
  creationTimestamp: "2026-07-02T22:57:51Z"
  generateName: keycloak-db-
  generation: 1
  labels:
    app.kubernetes.io/component: db
    app.kubernetes.io/instance: core-app
    app.kubernetes.io/managed-by: Helm
    app.kubernetes.io/name: keycloak-db
    app.kubernetes.io/part-of: noms-infrastructure
    app.kubernetes.io/version: 6.1.0
    app.noms.io/discovery-name: keycloak-db
    apps.kubernetes.io/pod-index: "0"
    controller-revision-hash: keycloak-db-66b9b6855
    helm.sh/chart: keycloak-db-5.0.0-develop.3
    partOf: noms-infrastructure
    priorityClassName: none
    statefulset.kubernetes.io/pod-name: keycloak-db-0
  name: keycloak-db-0
  namespace: auth
  ownerReferences:
  - apiVersion: apps/v1
    blockOwnerDeletion: true
    controller: true
    kind: StatefulSet
    name: keycloak-db
    uid: d7c1e880-7d12-446d-b69a-d899a3a3fda2
  resourceVersion: "6914629"
  uid: 36f93acc-da78-4f8b-bcc5-6d61148a304b
spec:
  containers:
  - env:
    - name: POD_NAMESPACE
      valueFrom:
        fieldRef:
          apiVersion: v1
          fieldPath: metadata.namespace
    - name: POPULATE_DATA
      value: "Y"
    - name: PGBACKREST
      value: "true"
    - name: POSTGRES_PASSWORD
      value: postgres
    - name: MODE
      value: postgres
    - name: PG_DATABASE
      value: unused
    - name: READINESS_USER
      value: postgres
    - name: READINESS_DATABASE
      value: postgres
    - name: PGDATA
      value: /pgdata/data
    image: nexus.seicdevops.com/docker-dev-share/noms/keycloak-db:6.1.0
    imagePullPolicy: IfNotPresent
    name: keycloak-db
    ports:
    - containerPort: 5432
      protocol: TCP
    resources:
      limits:
        cpu: 500m
        memory: 800Mi
      requests:
        cpu: 25m
        memory: 600Mi
    securityContext:
      allowPrivilegeEscalation: false
      runAsGroup: 70
    terminationMessagePath: /dev/termination-log
    terminationMessagePolicy: File
    volumeMounts:
    - mountPath: /pgsecrets/keycloak
      name: keycloak-pgpass-volume
      readOnly: true
      subPath: keycloak
    - mountPath: /var/run/secrets/service-cert
      mountPropagation: None
      name: service-certs
    - mountPath: /pgdata
      mountPropagation: None
      name: pgdata
      subPath: pgdata
    - mountPath: /backrestrepo
      mountPropagation: None
      name: pgdata
      subPath: backrestrepo
    - mountPath: /usr/local/bin/docker-entrypoint.sh
      name: pgstartup
      subPath: docker-entrypoint.sh
    - mountPath: /pgconf
      mountPropagation: None
      name: pgconf
      readOnly: true
    - mountPath: /var/run/secrets/kubernetes.io/serviceaccount
      name: kube-api-access-rjfnr
      readOnly: true
  dnsPolicy: ClusterFirst
  enableServiceLinks: true
  hostname: keycloak-db-0
  imagePullSecrets:
  - name: image-pull-credentials
  nodeName: aks-systempool-15555520-vmss000000
  nodeSelector:
    kubernetes.io/os: linux
  preemptionPolicy: PreemptLowerPriority
  priority: 0
  restartPolicy: Always
  schedulerName: default-scheduler
  securityContext:
    fsGroup: 70
    runAsNonRoot: true
    runAsUser: 70
    seccompProfile:
      type: RuntimeDefault
  serviceAccount: default
  serviceAccountName: default
  subdomain: keycloak-db
  terminationGracePeriodSeconds: 30
  tolerations:
  - effect: NoExecute
    key: node.kubernetes.io/not-ready
    operator: Exists
    tolerationSeconds: 300
  - effect: NoExecute
    key: node.kubernetes.io/unreachable
    operator: Exists
    tolerationSeconds: 300
  - effect: NoSchedule
    key: node.kubernetes.io/memory-pressure
    operator: Exists
  volumes:
  - configMap:
      defaultMode: 416
      name: keycloak-db-pgconf
      optional: false
    name: pgconf
  - name: pgdata
    persistentVolumeClaim:
      claimName: keycloak-db-pvc
  - name: keycloak-pgpass-volume
    secret:
      defaultMode: 420
      items:
      - key: keycloak-pgpass
        path: keycloak
      optional: false
      secretName: keycloak-pgpass
  - name: service-certs
    secret:
      defaultMode: 416
      optional: false
      secretName: noms-certs
  - configMap:
      defaultMode: 509
      name: keycloak-db-pgstartup
      optional: true
    name: pgstartup
  - name: kube-api-access-rjfnr
    projected:
      defaultMode: 420
      sources:
      - serviceAccountToken:
          expirationSeconds: 3607
          path: token
      - configMap:
          items:
          - key: ca.crt
            path: ca.crt
          name: kube-root-ca.crt
      - downwardAPI:
          items:
          - fieldRef:
              apiVersion: v1
              fieldPath: metadata.namespace
            path: namespace
status:
  conditions:
  - lastProbeTime: null
    lastTransitionTime: "2026-07-02T22:57:57Z"
    observedGeneration: 1
    status: "True"
    type: PodReadyToStartContainers
  - lastProbeTime: null
    lastTransitionTime: "2026-07-02T22:57:53Z"
    observedGeneration: 1
    status: "True"
    type: Initialized
  - lastProbeTime: null
    lastTransitionTime: "2026-07-02T22:57:57Z"
    observedGeneration: 1
    status: "True"
    type: Ready
  - lastProbeTime: null
    lastTransitionTime: "2026-07-02T22:57:57Z"
    observedGeneration: 1
    status: "True"
    type: ContainersReady
  - lastProbeTime: null
    lastTransitionTime: "2026-07-02T22:57:51Z"
    observedGeneration: 1
    status: "True"
    type: PodScheduled
  containerStatuses:
  - allocatedResources:
      cpu: 25m
      memory: 600Mi
    containerID: containerd://61713ca1a07d60a0c46b09d3e0b7a7b6fe0e20e6acd1f0b2894b087526a1afaf
    image: nexus.seicdevops.com/docker-dev-share/noms/keycloak-db:6.1.0
    imageID: nexus.seicdevops.com/docker-dev-share/noms/keycloak-db@sha256:d1437f0701cf83e5f6401cc7f06dbfbe8abf6fbe36fbd54b244869f175f78fb2
    lastState: {}
    name: keycloak-db
    ready: true
    resources:
      limits:
        cpu: 500m
        memory: 800Mi
      requests:
        cpu: 25m
        memory: 600Mi
    restartCount: 0
    started: true
    state:
      running:
        startedAt: "2026-07-02T22:57:57Z"
    user:
      linux:
        gid: 70
        supplementalGroups:
        - 70
        uid: 70
    volumeMounts:
    - mountPath: /pgsecrets/keycloak
      name: keycloak-pgpass-volume
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /var/run/secrets/service-cert
      name: service-certs
    - mountPath: /pgdata
      name: pgdata
    - mountPath: /backrestrepo
      name: pgdata
    - mountPath: /usr/local/bin/docker-entrypoint.sh
      name: pgstartup
    - mountPath: /pgconf
      name: pgconf
      readOnly: true
      recursiveReadOnly: Disabled
    - mountPath: /var/run/secrets/kubernetes.io/serviceaccount
      name: kube-api-access-rjfnr
      readOnly: true
      recursiveReadOnly: Disabled
  hostIP: 172.18.0.30
  hostIPs:
  - ip: 172.18.0.30
  observedGeneration: 1
  phase: Running
  podIP: 10.244.0.198
  podIPs:
  - ip: 10.244.0.198
  qosClass: Burstable
  startTime: "2026-07-02T22:57:53Z"
```