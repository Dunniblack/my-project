<#
.SYNOPSIS
    STIG 60-Day Credential Expiry Monitor
.DESCRIPTION
    Audits Key Vault for rotated credentials. If a credential has not yet been
    rotated (not in KV), it falls back to checking the creation age of the
    underlying Kubernetes deployment.
#>
param(
    [Parameter(Mandatory = $true)] [string]$Workspace,
    [Parameter(Mandatory = $true)] [string]$ClusterName,
    [Parameter(Mandatory = $true)] [string]$ResourceGroupName,
    [Parameter(Mandatory = $true)] [string]$StorageAccountName,
    [Parameter(Mandatory = $true)] [string]$ContainerName,
    [Parameter(Mandatory = $false)] [string]$StorageAccountKey = ''
)

. "$PSScriptRoot/../functions/CommonUtilities.ps1"
$ErrorActionPreference = "Stop"

$workspaceUpper = $Workspace.ToUpper()
$KeyVaultName = "DEJOMSMVP$($workspaceUpper[0])IL5KVT"
$CurrentDateStr = Get-Date -Format "yyyyMMdd-HHmm"
$WarningThresholdDays = 55
$ExpiringCreds = @()

Write-Host "`n=========================================="
Write-Host "STIG 60-Day Credential Expiry Monitor"
Write-Host "Key Vault : $KeyVaultName"
Write-Host "Cluster   : $ClusterName"
Write-Host "Storage   : $StorageAccountName / $ContainerName"
Write-Host "==========================================`n"

# Authenticate to AKS to support deployment age fallback checks
Write-Host "Authenticating to AKS cluster $ClusterName..."
$null = Exec az aks get-credentials --resource-group $ResourceGroupName --name $ClusterName --overwrite-existing
$null = Exec kubelogin convert-kubeconfig -l azurecli

# Map tools to their core deployments for age tracking when KV secret is absent
$trackedSecrets = @{
    "rancher-admin-password" = @{ Namespace = "cattle-system"; Deployment = "core-app-rancher" }
    # Example for future extensibility:
    # "argocd-admin-password" = @{ Namespace = "argocd"; Deployment = "core-app-argocd-server" }
}

foreach ($secretName in $trackedSecrets.Keys) {
    $ageDays = $null
    $source = ""

    try {
        # 1. Attempt to fetch from Key Vault (Post-Rotation State)
        $secret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $secretName -ErrorAction Stop
        $ageDays = (New-TimeSpan -Start $secret.Updated.DateTime -End (Get-Date)).Days
        $source = "Azure Key Vault"
    }
    catch {
        # 2. Secret not found in KV (Initial Pre-Rotation State)
        Write-Host "  [INFO] $secretName not found in Key Vault. Checking initial deployment age via kubectl..."

        $ns = $trackedSecrets[$secretName].Namespace
        $deploy = $trackedSecrets[$secretName].Deployment

        try {
            $creationTimeStr = Exec kubectl get deployment $deploy -n $ns -o jsonpath='{.metadata.creationTimestamp}'

            if (-not [string]::IsNullOrWhiteSpace($creationTimeStr)) {
                $creationTimeStr = $creationTimeStr -replace "'", ""
                $creationDate = [datetime]$creationTimeStr
                $ageDays = (New-TimeSpan -Start $creationDate -End (Get-Date)).Days
                $source = "Cluster Deployment ($deploy)"
            } else {
                Write-Warning "  [WARN] Could not retrieve creation timestamp for deployment '$deploy' in namespace '$ns'."
            }
        } catch {
            Write-Warning "  [WARN] Failed to query kubectl for '$deploy'. Is the tool deployed?"
        }
    }

    if ($null -ne $ageDays) {
        Write-Host "Secret: $secretName | Age: $ageDays Days | Source: $source"

        if ($ageDays -ge $WarningThresholdDays) {
            $ExpiringCreds += [PSCustomObject]@{
                Workspace  = $workspaceUpper
                SecretName = $secretName
                AgeDays    = $ageDays
                Status     = if ($ageDays -ge 60) { "EXPIRED" } else { "EXPIRING_SOON" }
            }
        }
    }
}

if ($ExpiringCreds.Count -gt 0) {
    $ReportName = "credential_alert_$($workspaceUpper)_$CurrentDateStr.json"
    $TempPath = Join-Path $env:TEMP $ReportName
    $ExpiringCreds | ConvertTo-Json -Depth 5 | Set-Content -Path $TempPath -Encoding UTF8

    Write-Host "`nUploading findings to blob to trigger Azure Monitor Action Group..."
    $uploadArgs = @('--account-name', $StorageAccountName, '--container-name', $ContainerName, '--name', "alerts/$ReportName", '--file', $TempPath, '--overwrite')
    if ($StorageAccountKey) { $uploadArgs += '--account-key', $StorageAccountKey } else { $uploadArgs += '--auth-mode', 'login' }

    $null = Exec az storage blob upload @uploadArgs
    Write-Host "Upload successful. Azure Monitor alert rule will trigger."
    Remove-Item -Path $TempPath -Force -ErrorAction SilentlyContinue
} else {
    Write-Host "`nAll tracked credentials are well within the 60-day STIG limit."
}
exit 0
