kubectl delete secret keycloak-pgpass -n auth
$epoch = [DateTimeOffset]::Now.ToUnixTimeSeconds()
kubectl annotate externalsecret keycloak-pgpass -n auth force-sync="$epoch" --overwrite
Start-Sleep -Seconds 120
kubectl get secret keycloak-pgpass -n auth -o yaml