# Generate CSR and private key

$ErrorActionPreference = 'Stop'

# Import common functions
. "$PSScriptRoot/../functions/CommonUtilities.ps1"

if($args.length -lt 1) {
    Write-Output "Generate a Certificate Signing Request (CSR) and private key."
    Write-Output "Usage: Generate-Csr.ps1 <CNAME> [<SAN> <SAN> ...]"
    Write-Output "Inputs:"
    Write-Output "  CNAME: Primary domain name"
    Write-Output "  SAN: Subject Alternative Name CNAME, as described above."
    Write-Output "Outputs:"
    Write-Output "  CSR: <CNAME>.csr"
    Write-Output "  Private Key: <CNAME>.key"
    exit 1
}

$DIR="$PSScriptRoot\..\..\..\certs"
$OpenSsl = 'C:\Program Files\Git\usr\bin\openssl.exe'
$OpenSslCnf = "$DIR\openssl.cnf"

$CNAME=$args[0]
$CSR="$DIR\$CNAME.csr"
$KEY="$DIR\$CNAME.key"

if(Test-Path $OpenSslCnf) {
    Remove-Item $OpenSslCnf -Force
}

Write-Output "Generating openssl.cnf for $CNAME"

$OpenSslCnfContent = @"
[ req ]
default_bits       = 2048
distinguished_name = req_distinguished_name
req_extensions     = req_ext

[ req_distinguished_name ]
countryName        = Country Name (2 letter code)
organizationName   = Organization Name (eg, company)
commonName         = Common Name

[ req_ext ]
subjectAltName     = @alt_names
keyUsage           = critical, nonRepudiation, digitalSignature, keyEncipherment, keyAgreement
extendedKeyUsage   = critical, serverAuth

[alt_names]
DNS.1 = $CNAME
"@

Set-Content -Path $OpenSslCnf $OpenSslCnfContent

$index=1
if ($args.Length -gt 1) {
    $SANS=$args[1..($args.Length-1)]
    $SANS | ForEach-Object {
        $index++
        Add-Content $OpenSslCnf "DNS.$index = $_"
    }
}

Write-Output "Generating CSR for $CNAME with SAN config:"
Get-Content $OpenSslCnf | Select-String 'DNS'

# Remove old CSR
if(Test-Path $CSR) {
    Remove-Item $CSR -Force
}

if(Test-Path $KEY) {
    Write-Output "Using existing RSA key: $($CNAME).key"
} else {
    Write-Output  "Generating new RSA key: $($CNAME).key"
    Exec $OpenSsl genrsa -out "$KEY" 2048
}

Exec $OpenSsl req -new `
  -out "$CSR" `
  -key "$KEY" `
  -sha256 `
  -nodes `
  -subj "/C=US/O=U.S. Government/OU=DoD/OU=PKI/OU=USAF/CN=$CNAME" `
  -config $OpenSslCnf


Write-Output "Validating CSR for $($CNAME).csr:"
Exec $OpenSsl req -verify -noout -text -in "$CSR"
