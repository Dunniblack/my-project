# Generate Certs
[CmdletBinding()]
param (
    [Parameter(Mandatory = $false)]
    [string]$Suffix = $null,
    [Parameter(Mandatory = $true)]
    [string]$RootDomain,
    [Parameter(Mandatory = $true)]
    [string]$KeyVault
)

$ErrorActionPreference = 'Stop'

# Import common functions
. "$PSScriptRoot/../functions/CommonUtilities.ps1"

$DIR = "$PSScriptRoot\..\..\..\certs"

# Add suffix to domain, if needed
if ($Suffix) {
    # Add special logic to handle PreProd domains
    if ($Suffix -eq "prepr") {
        $Suffix = "preprod"
    }
    $RootDomain = "-$Suffix.$RootDomain"
}
else {
    $RootDomain = ".$RootDomain"
}
$CNAME = "mps$RootDomain"

$CSR = "$CNAME.csr"
$CRT = "$CNAME.main.crt"
$CAS = "$CNAME.ca.crt"
$KEY = "$CNAME.key"
$PEM = "$CNAME.pem"
$P12 = "weather-private-cert"

# Common Name and SANs
$DomainNames = @(
    $CNAME,
    "mps-argo$RootDomain"
    "mps-grafana$RootDomain"
    "mps-prismacloud$RootDomain"
    "mps-rancher$RootDomain"
)

Write-Output "Download Certs, if they exist.."
$KeyVaultSecrets = (az keyvault secret list --vault-name $KeyVault 2>&1)
if ($KeyVaultSecrets | Select-String "ERROR") {
    $KeyVaultSecrets
    exit 1
}

@($CSR, $CRT, $KEY, $CAS) | ForEach-Object {
    $file = $_
    $filePath = "$DIR\$file"
    $secretName = "cert-$($file.Replace('.','-'))"
    $KeyVaultSecret = $KeyVaultSecrets | ConvertFrom-Json | where { $_.name -eq $secretName }

    if ($KeyVaultSecret) {
        Write-Output "Certificate secret found for $file! Downloading.."
        if (Test-Path $filePath) {
            Remove-Item $filePath -Force
        }
        try {
            Exec az keyvault secret download `
                --file $filePath `
                --name $secretName `
                --vault-name $KeyVault
        }
        catch {
            Write-Output "Cert file failed to download from Key Vault: $file"
            $_
            exit 1
        }
    }
    else {
        Write-Output "Cert secret doesn't exist in Key Vault: cert-$file"
    }
}

Write-Output "Generate a CSR"
Exec "$PSScriptRoot\Generate-Csr.ps1" @DomainNames

Write-Output "Generate a Self-Signed Cert, if it doesn't exist"
if (-Not (Test-Path "$DIR\$CRT" )) {
    Exec "$PSScriptRoot\SelfSign-Csr.ps1" @DomainNames
}

Write-Output "Upload the Certificate Secrets"
@($CSR, $CRT, $KEY) | ForEach-Object {
    $file = $_
    $filePath = "$DIR\$file"
    $secretName = "cert-$($file.Replace('.','-'))"
    Write-Output "Uploading Cert secret: $secretName"
    Exec az keyvault secret set `
        --file $filePath `
        --name $secretName `
        --vault-name $KeyVault `
        1>$null
}

Write-Output "Upload the Certificate Bundle"
Get-Content "$DIR\$CRT" | Set-Content "$DIR\$PEM"
Get-Content "$DIR\$KEY" | Add-Content "$DIR\$PEM"

Write-Output "Uploading Key Vault Cert (tls-cert) with Common Name: $CNAME"
Exec az keyvault certificate import `
    --file "$DIR\$PEM" `
    --name "tls-cert" `
    --vault-name $KeyVault `
    1>$null


Write-Output "Create PFX Certificate"

# Remove old P12 file, if it exists
Try {
    Remove-Item "$DIR\$P12" -Force
}
Catch {}

# In order to use the legacy providers, we must
# execute OpenSSL via bash.exe

$Bash = "C:\Program Files\Git\bin\bash.exe"
$OpenSsl = "'/c/Program Files/Git/usr/bin/openssl.exe'"
$BashDir = $DIR.Replace("C:", "/c").Replace("\", "/")

$Command = "$OpenSsl pkcs12 -export"
$Command += " -inkey $BashDir/$KEY"
$Command += " -in $BashDir/$CRT"
if ((Test-Path "$DIR\$CAS") -and `
    (Get-Content "$DIR\$CAS")) {
    $Command += " -certfile $BashDir/$CAS"
}
$Command += " -keypbe AES-256-CBC"
$Command += " -certpbe AES-256-CBC"
$Command += " -macalg SHA256"
$Command += " -out $BashDir/$P12"
$Command += " --passout pass:"

Exec $Bash -c $Command

Write-Output "Uploading Key Vault PFX/P12 Cert Secret"
$file = "$DIR\$P12"
$secretName = $P12.Replace('.', '-')
$secretValue = [Convert]::ToBase64String([IO.File]::ReadAllBytes($file))
Exec az keyvault secret set `
    --value $secretValue `
    --name $secretName `
    --vault-name $KeyVault `
    1>$null
