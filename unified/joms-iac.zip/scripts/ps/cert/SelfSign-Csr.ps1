# Generate Self-Signed Certificate

$ErrorActionPreference = 'Stop'

# Import common functions
. "$PSScriptRoot/../functions/CommonUtilities.ps1"

if ($args.length -lt 1) {
    Write-Output "Self-sign the CSR with SAN support."
    Write-Output "Usage: SelfSign-Csr.ps1 <CNAME>"
    Write-Output "Inputs:"
    Write-Output "  CNAME: Primary domain name"
    Write-Output "Outputs:"
    Write-Output "  Cert: <CNAME>.crt"
    exit 1
}

$DIR = "$PSScriptRoot\..\..\..\certs"
$OpenSsl = 'C:\Program Files\Git\usr\bin\openssl.exe'
$OpenSslCnf = "$DIR\\openssl.cnf"

$CNAME = $args[0]
$CSR = "$DIR\$CNAME.csr"
$CRT = "$DIR\$CNAME.main.crt"
$KEY = "$DIR\$CNAME.key"

if (Test-Path $OpenSslCnf) {
    Remove-Item $OpenSslCnf -Force
}

Write-Output "Generating openssl.cnf for $CNAME"

$OpenSslCnfContent = @"
[ req ]
default_bits       = 2048
distinguished_name = req_distinguished_name
req_extensions     = req_ext

[ req_distinguished_name ]
countryName        = Country Name (2 letter code)
organizationName   = Organization Name (eg, company)
commonName         = Common Name

[ req_ext ]
subjectAltName     = @alt_names
keyUsage           = critical, nonRepudiation, digitalSignature, keyEncipherment, keyAgreement
extendedKeyUsage   = critical, serverAuth

[ alt_names ]
DNS.1 = $CNAME
"@

Set-Content $OpenSslCnf $OpenSslCnfContent

$index = 1
if ($args.Length -gt 1) {
    $SANS = $args[1..($args.Length - 1)]
    $SANS | ForEach-Object {
        $index++
        Add-Content $OpenSslCnf "DNS.$index = $_"
    }
}

Exec $OpenSsl x509 `
    -req `
    -days 3650 `
    -in "$CSR" `
    -signkey "$KEY" `
    -out "$CRT" `
    -extfile $OpenSslCnf `
    -extensions req_ext

Write-Output "Validating Cert $($CNAME).crt:"
Exec $OpenSsl x509 -text -noout -in "$CRT"
