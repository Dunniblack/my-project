# This script is needed to move TF resources from old TF resource type to new ones
# For example, this will move 'kubernetes_namespace.all' to 'kubernetes_namespace_v1.all'
function Move-TerraformResources {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$terraform
    )

    # Define namespaces
    $init_namespaces = @(
        "argocd",
        "kyverno"
    )
    $akv_sp_namespaces = @(
        "auth",
        "ingress",
        "twistlock",
        "cd1-blue",
        "cd1-green"
    ) + $init_namespaces
    $namespaces = @(
        "cattle-global-data",
        "cattle-system",
        "cert-manager",
        "external-secrets",
        "grafana",
        "loki",
        "velero"
    ) + $akv_sp_namespaces

    # Move all the Namespaces
    $namespaces | ForEach-Object {
        $TFResource = "kubernetes_namespace.all[`"`"`"$_`"`"`"]"
        Write-Host "TFResource: $TFResource"

        Write-Host "Remove the old Terraform Resource type from state"
        & "$terraform" state rm $TFResource 2>$null


        if ($LASTEXITCODE -eq 0) {
            Write-Host "Import the new Terraform resource type into state"
            & "$terraform" import `
                -var-file="..\.default.tfvars" `
                -input=false `
                $TFResource.Replace("namespace", "namespace_v1") `
                $_
        }
    }

    # Move all the akv-service-principal secrets
    $akv_sp_namespaces | ForEach-Object {
        $TFResource = "kubernetes_secret.akv-service-principal[`"`"`"$_`"`"`"]"
        Write-Host "TFResource: $TFResource"

        Write-Host "Remove the old Terraform Resource type from state"
        & "$terraform" state rm $TFResource 2>$null


        if ($LASTEXITCODE -eq 0) {
            Write-Host "Import the new Terraform resource type into state"
            & "$terraform" import `
                -var-file="..\.default.tfvars" `
                -input=false `
                $TFResource.Replace("secret", "secret_v1") `
                "$_/akv-service-principal"
        }
    }

    # Move all the image-pull-credentials secrets
    $init_namespaces | ForEach-Object {
        $TFResource = "kubernetes_secret.image-pull-credentials[`"`"`"$_`"`"`"]"
        Write-Host "TFResource: $TFResource"

        Write-Host "Remove the old Terraform Resource type from state"
        & "$terraform" state rm $TFResource 2>$null


        if ($LASTEXITCODE -eq 0) {
            Write-Host "Import the new Terraform resource type into state"
            & "$terraform" import `
                -var-file="..\.default.tfvars" `
                -input=false `
                $TFResource.Replace("secret", "secret_v1") `
                "$_/image-pull-credentials"
        }
    }

    # Define the other secrets
    $secrets = @(
        "loki-storage-credentials",
        "repo-helm",
        "repo-helm-oci[0]",
        "repo-joms-iac"
    )

    # Move all the other secrets
    $secrets | ForEach-Object {
        $TFResource = "kubernetes_secret.$_"
        Write-Host "TFResource: $TFResource"

        Write-Host "Remove the old Terraform Resource type from state"
        & "$terraform" state rm $TFResource 2>$null


        if ($LASTEXITCODE -eq 0) {
            Write-Host "Import the new Terraform resource type into state"
            & "$terraform" import `
                -var-file="..\.default.tfvars" `
                -input=false `
                $TFResource.Replace("secret", "secret_v1") `
                "$(($_.Split("-")[0]).Replace("repo","argocd"))/$($_.Split("[")[0])"
        }
    }

    # Move the storage class
    $TFResource = "kubernetes_storage_class.aks-fileshare"
    Write-Host "TFResource: $TFResource"

    Write-Host "Remove the old Terraform Resource type from state"
    & "$terraform" state rm $TFResource 2>$null


    if ($LASTEXITCODE -eq 0) {
        Write-Host "Import the new Terraform resource type into state"
        & "$terraform" import `
            -var-file="..\.default.tfvars" `
            -input=false `
            $TFResource.Replace("storage_class", "storage_class_v1") `
            azurefile
    }
}