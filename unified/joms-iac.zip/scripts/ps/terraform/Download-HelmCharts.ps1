# Download the Helm Chart using IMGPKG
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPlainTextForPassword', 'REGISTRY_PASSWORD', 
    Justification = 'Password is stored in plain text before being passed to this script and would need to be converted back to plain text in this script')]
param (
    [Parameter(Mandatory = $true)]
    [string]$REGISTRY_USERNAME,
    [Parameter(Mandatory = $true)]
    [string]$REGISTRY_PASSWORD,
    [Parameter(Mandatory = $true)]
    [string]$REGISTRY_DOMAIN,
    [Parameter(Mandatory = $true)]
    [string]$BinDir,
    [Parameter(Mandatory = $false)]
    [string]$ImgPgkBundles = "joms/noms-cluster-base-bundle:8.3.0",
    [Parameter(Mandatory = $false)]
    [string]$HelmChart = "noms-cluster-base-8.3.0.tgz"
)

$ErrorActionPreference = 'Stop'

# Import common functions
. "$PSScriptRoot/../functions/CommonUtilities.ps1"

$dockerPath = "$BinDir\\docker.exe"
$imgpkgPath = "$BinDir\\imgpkg.exe"

Write-Host "Setup Source Registry Env Vars"
$env:IMGPKG_REGISTRY_USERNAME_0 = "$REGISTRY_USERNAME"
$env:IMGPKG_REGISTRY_PASSWORD_0 = "$REGISTRY_PASSWORD"
$env:IMGPKG_REGISTRY_HOSTNAME_0 = "$REGISTRY_DOMAIN"

Write-Host "Perform Docker Login to Source Registry"
Exec "$dockerPath" login `
    --username $env:IMGPKG_REGISTRY_USERNAME_0 `
    --password $env:IMGPKG_REGISTRY_PASSWORD_0 `
    $env:IMGPKG_REGISTRY_HOSTNAME_0

foreach ($repo in -split $ImgPgkBundles) {
    Write-Host "============================================"
    $repoInfo = $repo.split(":")
    $repoName = $repoInfo[0]
    if ($repoInfo.length -eq 1) {
        Write-Host "Resolve to the latest tag, if not specified."

        $TagListUrl = "$TagListUrlPrefix/$repoName/$TagListUrlSuffix"
        #"TagListUrl: $TagListUrl"
        $Result = $(Invoke-WebRequest -Uri $TagListUrl -Headers $headers)
        $Tags = ($Result.Content | ConvertFrom-Json).tags
        if ($Tags[0].GetType().Name -eq "PSCustomObject") {
            $Tags = $Tags.Name
        }
        $Tags = $Tags | Where-Object { $_ -notlike "sha256*" }
        Write-Host "Available Tags: $Tags"

        $Tag = $Tags[-1]
    }
    else {
        $Tag = $repoInfo[-1]
    }
    $RepoTag = "$($repoName):$Tag"
    Write-Host "Bundle Source: $env:IMGPKG_REGISTRY_HOSTNAME_0/$RepoTag"

    Write-Host "Pull the Image"
    Exec "$imgpkgPath" pull `
        -b "$env:IMGPKG_REGISTRY_HOSTNAME_0/$RepoTag" `
        -o "$repoName\" `
        2>&1

    Write-Host "Copy the Helm chart to workspace: $HelmChart"
    Copy-Item -Path ".\$repoName\$HelmChart" ".\$HelmChart"
}