[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$Enclave,

    [Parameter(Mandatory = $false)]
    [string]$AdditionalWorkspaces = "",

    [Parameter(Mandatory = $true)]
    [string]$TfStateStorageAccount,

    [Parameter(Mandatory = $true)]
    [string]$TfStateContainer,

    [Parameter(Mandatory = $true)]
    [string]$ArmAccessKey,

    [Parameter(Mandatory = $false)]
    [string]$KeyVaultSecretName = "monitored-terraform-workspaces",

    [Parameter(Mandatory = $false)]
    [bool]$DebugMode = $false
)

$ErrorActionPreference = "Stop"


. "$PSScriptRoot/../functions/CommonUtilities.ps1"
. "$PSScriptRoot/../functions/TerraformTools.ps1"
. "$PSScriptRoot/../functions/AzStorageAccountTools.ps1"

function Write-Debug {
    [cmdletbinding()]
    Param (
        [Parameter(Mandatory = $true, Position = 0)]
        [String]$Message
    )

    if ($DebugMode) {
        Write-Host $Message
    }
}

if ($DebugMode) {
    Write-Debug "Downloading Global state..."
}
$TfStorageAccountInfo = New-StorageAccountInfo `
    -Name $TfStateStorageAccount `
    -Container $TfStateContainer `
    -AccountKey $ArmAccessKey

$GlobalOutputs = Get-TerraformStateOutputs `
    -TfStateStorageInfo $TfStorageAccountInfo `
    -Enclave $Enclave `
    -TfModule "global" `
    -TfWorkspace "Global"

# Extract KeyVault Name
$KeyVaultName = ""
if ($GlobalOutputs.ContainsKey("core_key_vault_name")) {
    $KeyVaultName = $GlobalOutputs["core_key_vault_name"]
}

if ([string]::IsNullOrWhiteSpace($KeyVaultName)) {
    Write-Debug "Error: Could not find 'core_key_vault_name' in Global state"
    exit 1
}

Write-Debug "Found KeyVault: $KeyVaultName"

# Retrieve Workspaces from KeyVault
Write-Debug "Retrieving workspaces to monitor from KeyVault secret '$KeyVaultSecretName'..."
try {
    # Redirect stderr to null to prevent az warnings from polluting, but capture stdout
    $SecretValue = (az keyvault secret show --name $KeyVaultSecretName --vault-name $KeyVaultName --query "value" -o tsv 2>$null)
}
catch {
    Write-Debug "Failed to retrieve secret from KeyVault: $_"
    $SecretValue = ""
}

if ([string]::IsNullOrWhiteSpace($SecretValue)) {
    Write-Debug "Secret '$KeyVaultSecretName' is empty."
    Write-Debug "Continuing with no pre-configured workspaces to monitor."
    $KVWorkspaces = @()
}
else {
    $KVWorkspaces = $SecretValue -split ','
}

# Normalize manually supplied workspaces from a comma-delimited string.
$ManualWorkspaces = @()
if (-not [string]::IsNullOrWhiteSpace($AdditionalWorkspaces)) {
    $ManualWorkspaces = $AdditionalWorkspaces -split ','
}

# Merge with Additional Workspaces
$TargetWorkspaces = $KVWorkspaces + $ManualWorkspaces

if ($TargetWorkspaces.Count -eq 0) {
    Write-Debug "No workspaces found to process."
}

# Remove duplicates and trim
$TargetWorkspaces = $TargetWorkspaces | ForEach-Object { $_.Trim() } | Select-Object -Unique

# Build Target List
$Targets = @()

# Add Global as a target (Always included)
$Targets += [PSCustomObject]@{
    Module    = "global"
    Workspace = "Global"
}

# Add an infrastructure and software target for each workspace
foreach ($ws in $TargetWorkspaces) {
    if (-not [string]::IsNullOrWhiteSpace($ws)) {
        # Infrastructure Module
        $Targets += [PSCustomObject]@{
            Module    = "infrastructure"
            Workspace = $ws
        }
        # Software Module
        $Targets += [PSCustomObject]@{
            Module    = "software"
            Workspace = $ws
        }
    }
}


# Convert to JSON and output - ensure it's always an array even with one element
# Write-Output prevents PowerShell from unwrapping single-element arrays
Write-Output -NoEnumerate $Targets | ConvertTo-Json -Depth 2 -Compress

# Explicitly signal success
exit 0
