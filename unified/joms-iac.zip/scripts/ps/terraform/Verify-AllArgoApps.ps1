# Verify all ArgoCD Applications are in Healthy status
[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$BinDir,
    [Parameter(Mandatory = $false)]
    [string]$ArgocdNamespace = "argocd"
)

$ErrorActionPreference = "Stop"

# Import common functions
. "$PSScriptRoot/../functions/CommonUtilities.ps1"

## Make sure ArgoCD Applications are in Healthy status
$RetryAttempts = 0
$MaxRetryAttempts = 120
$SleepSeconds = 30
$ResourcesNotReady = "NoResourcesAreReadyByDefault"

While ($ResourcesNotReady -and `
    ($RetryAttempts -le $MaxRetryAttempts)) {
    $RetryAttempts++
    Start-Sleep $SleepSeconds

    Write-Host "Checking for ArgoCD Applications not in Healthy status.."
    $ResourcesNotReady = Exec "$BinDir\kubectl.exe" -n $ArgocdNamespace get application --no-headers `
        -o=custom-columns='Name:.metadata.name,Status:.status.health.status' `
    | Where-Object { !( $_ | Select-String " Healthy") }

}

if ($RetryAttempts -gt $MaxRetryAttempts) {
    Write-Host "Maximum Retry attempts reached checking for ArgoCD Applciations in Healthy Status. Exiting.."
    exit -1
}

Write-Host "All ArgoCD Applications have moved to Healthy status!"
Exec "$BinDir\kubectl.exe" -n $ArgocdNamespace get application
