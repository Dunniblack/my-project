[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$resourceGroupName,
    [Parameter(Mandatory = $true)]
    [string]$aksClusterName,
    [Parameter(Mandatory = $true)]
    [string]$workspaceResourceId
)

$ErrorActionPreference = 'Stop'

# Import common functions
. "$PSScriptRoot/../functions/CommonUtilities.ps1"

Write-Host "Checking status of monitoring addon for cluster '$aksClusterName'..."

try {
    $addonProfile = Exec az aks show --resource-group $resourceGroupName --name $aksClusterName --query "addonProfiles.omsagent" | ConvertFrom-Json
}
catch {
    Write-Error "An error occurred while checking cluster status: $($_.Exception.Message)"
    exit 1
}

if ($addonProfile -and $addonProfile.enabled -eq $true) {
    Write-Host "Monitoring addon is enabled. Skipping ahead..."
}
else {
    Write-Host "Monitoring addon is not enabled. Enabling it now..."

    try {
        # enable the addon
        Exec az aks enable-addons --resource-group $resourceGroupName --name $aksClusterName --addons monitoring --workspace-resource-id $workspaceResourceId
        Write-Host "AKS monitoring addon re-enabled successfully."
    }
    catch {
        Write-Error "An error occurred while enabling monitoring addon: $($_.Exception.Message)"
        exit 1
    }

}