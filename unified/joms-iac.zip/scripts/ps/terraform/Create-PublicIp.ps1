# Create a Public IP, if one doesn't already exist
[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$publicIpName,
    [Parameter(Mandatory = $true)]
    [string]$resourceGroupName
)

$ErrorActionPreference = 'Stop'

# Import common functions
. "$PSScriptRoot/../functions/CommonUtilities.ps1"

Write-Host "Public IP Name : $publicIpName"

# Check if Public IP already exists
try {
    $publicIp = (Exec az network public-ip show -g $resourceGroupName -n $publicIpName)
}
catch {
    $publicIp = $null
}

if ($publicIp) {
    Write-Host "Public IP already exists, continuing.."
}
else {
    Write-Host "Creating Public IP.."
    Exec az network public-ip create --name $publicIpName `
        --resource-group $resourceGroupName
}
