$Hashtable = @{}
Get-ChildItem env:*_VERSION* | ForEach-Object {
    $Hashtable[$_.Key] = $_.Value
}
$Hashtable | ConvertTo-Json
