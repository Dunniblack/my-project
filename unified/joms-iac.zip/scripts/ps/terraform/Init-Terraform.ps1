# Initialize Terraform
[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$TfModule,
    [Parameter(Mandatory = $true)]
    [string]$TfWorkspace,
    [Parameter(Mandatory = $true)]
    [string]$BinDir,
    [Parameter(Mandatory = $true)]
    [string]$TfStateResourceGroup,
    [Parameter(Mandatory = $true)]
    [string]$TfStateStorageAccount,
    [Parameter(Mandatory = $true)]
    [string]$TfStateContainer,
    [Parameter(Mandatory = $true)]
    [string]$ArmAccessKey,
    [Parameter(Mandatory = $true)]
    [string]$MetadataHost
)

$ErrorActionPreference = 'Stop'

# Import common functions
. "$PSScriptRoot/../functions/CommonUtilities.ps1"

Write-Host "Initializing Terraform"
$terraform = "$BinDir\terraform.exe"
$pluginDir = "$BinDir\plugins\"

if (Test-Path $terraform) {
    Set-Location terraform/$TfModule

    # Add the ARM_ACCESS_KEY to main.tf file
    (Get-Content .\main.tf).Replace('{{ ARM_ACCESS_KEY }}', $ArmAccessKey) `
    | Set-Content .\main.tf

    Exec "$terraform" init -plugin-dir="$pluginDir" -input=false -no-color `
        -backend-config="resource_group_name=$TfStateResourceGroup" `
        -backend-config="storage_account_name=$TfStateStorageAccount" `
        -backend-config="container_name=$TfStateContainer" `
        -backend-config="key=$TfModule/$TfWorkspace.tfstate" `
        -backend-config="metadata_host=$MetadataHost"


    Write-Host "Terraform initialized successfully."
}
else {
    Write-Error "Terraform not found at: $terraform"; exit 1
}