param (
    [Parameter(Mandatory = $true)]
    [string]$resourceGroupName,
    [Parameter(Mandatory = $true)]
    [string]$aksClusterName,
    [Parameter(Mandatory = $true)]
    [string]$apiServerSubnetId,
    [Parameter(Mandatory = $true)]
    [string]$keyVaultResourceId,
    [Parameter(Mandatory = $true)]
    [string]$keyVaultKeyUri,
    [Parameter(Mandatory = $true)]
    [string]$AksKmsV2Setup,
    [Parameter(Mandatory = $false)]
    [string]$AzCliAksPreviewVersion = "19.0.0b28"
)

$ErrorActionPreference = 'Stop'

# Import common functions
. "$PSScriptRoot/../functions/CommonUtilities.ps1"

Write-Host "AksName : $aksClusterName"
try {
    if ($AksKmsV2Setup.ToLower() -eq "true") {
        Write-Host "KMS feature is already enabled. Continuing..."
    }
    else {
        Write-Host "KMS feature is not enabled. Enabling KMS feature... see value below"
        Exec az extension add --name aks-preview --version $AzCliAksPreviewVersion
        Exec az aks update --name $aksClusterName `
            --resource-group $resourceGroupName `
            --enable-apiserver-vnet-integration `
            --apiserver-subnet-id $apiServerSubnetId 1> $null
        Exec az aks update --name $aksClusterName `
            --resource-group $resourceGroupName `
            --enable-azure-keyvault-kms `
            --azure-keyvault-kms-key-id $keyVaultKeyUri `
            --azure-keyvault-kms-key-vault-network-access "Private" `
            --azure-keyvault-kms-key-vault-resource-id $keyVaultResourceId 1>$null
        Exec az extension remove --name aks-preview
        Write-Host "KMS feature has been successfully enabled."
    }
}
catch {
    # Handle errors
    Write-Error "An error occurred: $($_.Exception.Message)"
    exit 1
}