$ErrorActionPreference = 'Stop'

# Import common functions
. "$PSScriptRoot/../functions/CommonUtilities.ps1"

Set-Location $env:WORKING_DIR/../..

$Date = (Get-Date).ToString('yyyyMMdd.hhmmss')
$Branch = "$($env:WORKSPACE)-config"

Exec git config core.autocrlf false
Exec git config http.sslVerify false
Exec git config push.autoSetupRemote true

Exec git config user.name "joms-iac"
Exec git config user.email "joms-iac@us.af.mil"

try {
    # These commands are allowed to fail when the branch doesn't exist
    Exec git fetch
    Exec git reset --hard
    Exec git symbolic-ref HEAD:refs/heads/$Branch
}
catch {}

$RemoteOriginUrl = (Exec git config remote.origin.url)
if (($RemoteOriginUrl -split '@').length -ne 1) {
    $RemoteOriginUrl = "https://$($RemoteOriginUrl[1])"
}
Write-Host "RemoteOriginUrl: $RemoteOriginUrl"


$AuthParameters = @()
if ($env:ENCLAVE -eq "wdsf") {
    $RemoteOriginUrlCreds = $RemoteOriginUrl.Replace('https://', "https://$($env:GIT_UN):$($env:GIT_PW)@")
    Write-Host "RemoteOriginUrlCreds: $RemoteOriginUrlCreds"
    Exec git config remote.origin.url $RemoteOriginUrlCreds
}
else {
    $patB64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("$($env:GIT_UN):$($env:GIT_PW)"))
    $AuthParameters += "-c"
    $AuthParameters += "http.extraHeader=`"Authorization: Basic $patB64`""
}

Set-Content -Path '.gitignore' -Value (
    Get-Content -Path '.gitignore' | `
        Select-String -Pattern 'argo-app' -NotMatch
)
Write-Output "Config updates - $Date" > argo-app/.gitkeep

Exec git add .gitignore
Exec git add argo-app/.

Exec git commit -m "Config updates - $Date"

Exec git @AuthParameters push --set-upstream origin HEAD:refs/heads/$Branch --force
Exec git config remote.origin.url $RemoteOriginUrl
