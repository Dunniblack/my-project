# Get the list of available internal IPs
$ErrorActionPreference = 'Stop'

# Import common functions
. "$PSScriptRoot/../functions/CommonUtilities.ps1"

$query = [Console]::In.ReadLine() | ConvertFrom-JSON

$AvailableIps = (Exec az network vnet `
        subnet list-available-ips `
        --resource-group $query.resource_group `
        --vnet-name $query.vnet_name `
        --name $query.subnet_name `
        -o json `
    | ConvertFrom-Json)

$Hashtable = @{
    internal_ip = "null"
}
Try {
    # Try to get the first available IP, if possible
    $Hashtable = @{
        internal_ip = $AvailableIps[0]
    }
}
Catch {}
$Hashtable | ConvertTo-Json
