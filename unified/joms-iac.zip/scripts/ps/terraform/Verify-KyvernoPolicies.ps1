# Verify the Kyverno Policies are in Ready status
# and make sure Labels are applied
[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$BinDir,
    [Parameter(Mandatory = $false)]
    [string]$ArgocdNamespace = "argocd"
)

$ErrorActionPreference = "Stop"

# Import common functions
. "$PSScriptRoot/../functions/CommonUtilities.ps1"

## Make sure Kyverno Policies are Ready
$RetryAttempts = 0
$MaxRetryAttempts = 40
$SleepSeconds = 30
$ResourcesNotReady = "NoResourcesAreReadyByDefault"
$ClusterPoliciesExist = $null

While ($ResourcesNotReady -and `
    ($RetryAttempts -le $MaxRetryAttempts)) {
    $RetryAttempts++
    Start-Sleep $SleepSeconds

    if ($ClusterPoliciesExist) {
        Write-Host "Checking for Kyverno Policies not in Ready status.."
        $ResourcesNotReady = Exec "$BinDir\kubectl.exe" get clusterpolicy --no-headers `
            -o=custom-columns='Name:.metadata.name,Status:.status.conditions[*].message' `
        | Where-Object { !( $_ | Select-String " Ready") }
    }
    else {
        Write-Host "Checking to see if the ClusterPolicy API Resouce Exists.."
        $ClusterPoliciesExist = Exec "$BinDir\kubectl.exe" api-resources `
        | Select-String clusterpolicies
    }
}

if ($RetryAttempts -gt $MaxRetryAttempts) {
    Write-Host "Maximum Retry attempts reached checking for Kyverno Policies Ready Status. Exiting.."
    exit -1
}

## Make sure Label Jobs are complete
$RetryAttempts = 0
$ResourcesNotReady = "NoResourcesAreReadyByDefault"

While ($ResourcesNotReady -and `
    ($RetryAttempts -le $MaxRetryAttempts)) {
    $RetryAttempts++
    Start-Sleep $SleepSeconds

    Write-Host "Checking for Label Jobs not in Complete status.."
    $ResourcesNotReady = Exec "$BinDir\kubectl.exe" -n $ArgocdNamespace get jobs --no-headers `
        -o=custom-columns='Name:.metadata.name,Status:.status.succeeded'  `
    | Where-Object { !( $_ | Select-String " 1") }
}

if ($RetryAttempts -gt $MaxRetryAttempts) {
    Write-Host "Maximum Retry attempts reached checking for Label Jobs Complete status. Exiting.."
    exit -1
}

## Re-label Namespaces
Write-Host "Re-label all core-app namespaces to make sure Kyverno Policies will be applied: core-app=yes"
Exec "$BinDir\kubectl.exe" label --overwrite namespace --selector=core-app=true core-app=yes
Write-Host "Re-label all core-app namespaces to make sure Kyverno Policies will be applied: core-app=true"
Exec "$BinDir\kubectl.exe" label --overwrite namespace --selector=core-app=yes core-app=true


$CoreAppNamespaces = (
    Exec "$BinDir\kubectl.exe" get namespaces `
        -l "core-app=true" `
        --no-headers `
        -o=custom-columns='Name:.metadata.name'
) -Join ','

$CoreAppNamespaces.Split(',') | ForEach-Object {
    Write-Host "Re-label namespace $_"
    Exec "$BinDir\kubectl.exe" label --overwrite namespace "$_" "$_=false"
    Exec "$BinDir\kubectl.exe" label --overwrite namespace "$_" "$_=true"
}
