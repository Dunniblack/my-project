# Create KubConfig File, get Server Id, check for Admin permissions
[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$AksName,
    [Parameter(Mandatory = $true)]
    [string]$AksResourceGroup,
    [Parameter(Mandatory = $true)]
    [string]$BinDir,
    [Parameter(Mandatory = $true)]
    [ref]$Result
)

$ErrorActionPreference = 'Stop'

# Import common functions
. "$PSScriptRoot/../functions/CommonUtilities.ps1"

$env:KUBECONFIG = "$BinDir\kubeconfig"
$env:Path += ";$BinDir"
[hashtable]$Return = @{
    "AksUseServicePrincipal" = "false";
    "AksArgoCdDeployed"      = "false";
    "AksKmsV2Setup"          = "false";
}
try {
    if (Test-Path $env:KUBECONFIG) {
        Remove-Item $env:KUBECONFIG -Force
    }

    # Setup Kubeconfig file
    Exec az aks get-credentials `
        -n $AksName `
        -g $AksResourceGroup `
        --format azure
    Exec "$BinDir\kubelogin.exe" convert-kubeconfig -l azurecli

    # Specify the location of the kubelogin.exe binary
    (Get-Content $env:KUBECONFIG).Replace('kubelogin', "$BinDir\kubelogin.exe") | `
        Set-Content $env:KUBECONFIG

    # Get Server Id From the Kubeconfig
    $AksServerId = (((Get-Content $env:KUBECONFIG).Replace("$BinDir\kubelogin.exe", 'kubelogin') | `
                Select-String -Pattern '-')[-1] -Split '-')
    $AksServerId = ($AksServerId[1..($AksServerId.Length - 1)] -Join '-').Trim()
    $Return["AksServerId"] = $AksServerId

    # Check if AKS Local Accounts are disabled.
    $Return["AksLocalAccountsDisabled"] = (Exec az aks list `
            -g $AksResourceGroup `
            --query "[?name==``$AksName``].disableLocalAccounts" `
            -o tsv)
}
catch {
    Write-Host $_
    $Return["AksServerId"] = ""
    $Return["AksLocalAccountsDisabled"] = "true"
}
Write-Host "AksServerId: $($Return["AksServerId"])"
Write-Host "AksLocalAccountsDisabled: $($Return["AksLocalAccountsDisabled"])"

# Allow failures/warnings, handle issue with Try/Catch blocks
$ErrorActionPreference = 'SilentlyContinue'

try {
    # Check if the Service Principal has Cluster Admin permissions
    & "$BinDir\kubectl.exe" get clusterrolebinding aks-admin-binding-sp 2>$null
    if ($LASTEXITCODE -eq 0) {
        $Return["AksUseServicePrincipal"] = "true"
    }
    # Fetch AKS cluster details
    Write-Host "Retrieving AKS cluster details..."
    $aksClusterDetails = Exec az aks show --resource-group $AksResourceGroup `
        --name $AksName `
        --query "securityProfile.azureKeyVaultKms.enabled"
    if ($aksClusterDetails -eq 'true') {
        $Return["AksKmsV2Setup"] = "true"
    }
    else {
        $Return["AksKmsV2Setup"] = "false"
    }
    Write-Host "AksKmsV2Setup: $($Return["AksKmsV2Setup"])"
}
catch {
    # Handle errors
    Write-Host "An error occurred $_"
    $Return["AksUseServicePrincipal"] = "false"
}
Write-Host "AksUseServicePrincipal: $($Return["AksUseServicePrincipal"])"

try {
    # Check if the Argo CD API Already exists
    $ApiResources = (& "$BinDir\kubectl.exe" api-resources 2>$null)
    if ($ApiResources | Select-String 'argoproj.io/v1alpha1') {
        $Return["AksArgoCdDeployed"] = "true"
    }
}
catch {
    Write-Host $_
    $Return["AksArgoCdDeployed"] = "false"
}
Write-Host "AksArgoCdDeployed: $($Return["AksArgoCdDeployed"])"

try {
    # Get the Kubernetes API Server Endpoint IP
    $Return["AksKubeApiServerEndpointIp"] = (& "$BinDir\kubectl.exe" get endpointslice kubernetes -o jsonpath='{.endpoints[0].addresses[0]}' 2>$null)
}
catch {
    Write-Host $_
    $Return["AksKubeApiServerEndpointIp"] = ""
}
Write-Host "AksKubeApiServerEndpointIp: $($Return["AksKubeApiServerEndpointIp"])"

$Result.value = $Return