# Execute Terraform
[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [ValidateSet("iac", "mvcr", "dev", "test", "prod")]
    [string]$Stage,
    [Parameter(Mandatory = $true)]
    [string]$SubscriptionId,
    [Parameter(Mandatory = $true)]
    [string]$FuncArea,
    [Parameter(Mandatory = $true)]
    [string]$Project,
    [Parameter(Mandatory = $true)]
    [string]$C1Project,
    [Parameter(Mandatory = $true)]
    [string]$TfModule,
    [Parameter(Mandatory = $true)]
    [string]$TfWorkspace,
    [Parameter(Mandatory = $true)]
    [string]$TfAction,
    [Parameter(Mandatory = $true)]
    [string]$BinDir,
    [Parameter(Mandatory = $true)]
    [string]$IaCDir,
    [Parameter(Mandatory = $true)]
    [string]$TfDir,
    [Parameter(Mandatory = $false)]
    [string]$DefaultTfVarsFile = ".\terraform\.default.tfvars",
    [Parameter(Mandatory = $true)]
    [string]$TfStateResourceGroup,
    [Parameter(Mandatory = $true)]
    [string]$TfStateStorageAccount,
    [Parameter(Mandatory = $true)]
    [string]$TfStateContainer,
    [Parameter(Mandatory = $true)]
    [string]$ArmAccessKey,
    [Parameter(Mandatory = $true)]
    [AllowEmptyString()]
    [string]$TfVars,
    [Parameter(Mandatory = $true)]
    [AllowEmptyString()]
    [string]$AksServerId,
    [Parameter(Mandatory = $true)]
    [ValidateSet("true", "false")]
    [string]$AksUseServicePrincipal,
    [Parameter(Mandatory = $true)]
    [ValidateSet("true", "false")]
    [string]$AksLocalAccountsDisabled,
    [Parameter(Mandatory = $true)]
    [ValidateSet("true", "false")]
    [string]$AksArgoCdDeployed,
    [Parameter(Mandatory = $true)]
    [AllowEmptyString()]
    [string]$AksKubeApiServerEndpointIp,
    [Parameter(Mandatory = $true)]
    [string]$MetadataHost,
    [Parameter(Mandatory = $false)]
    [string]$AksKmsV2Setup,
    [Parameter(Mandatory = $true)]
    [ValidateSet("true", "false")]
    [string]$GenerateCerts = "false",
    [Parameter(Mandatory = $false)]
    [string]$RootDomain,
    [Parameter(Mandatory = $false)]
    [string]$PostPowerShellScripts
)
$ErrorActionPreference = "Continue"

. "$PSScriptRoot/../functions/CommonUtilities.ps1"
. "$PSScriptRoot/../functions/AzStorageAccountTools.ps1"
. "$PSScriptRoot/../functions/TerraformTools.ps1"
. "$PSScriptRoot/Move-TerraformResources.ps1"

# Guard against global module desctruction
if ($TfAction -eq 'destroy' -and $TfModule -eq 'global') {
    throw "The global module cannot be destroyed via this CI/CD job"
}

Write-Host "Running Terraform..."
$terraform = "$BinDir\terraform.exe"

# Capture Terraform state storage account info
$TfStorageAccountInfo = New-StorageAccountInfo `
    -Name $TfStateStorageAccount `
    -Container $TfStateContainer `
    -AccountKey $ArmAccessKey

Write-Host "Download Workspace Terraform Variables File, if one exists"
$DefaultTfVarsFileTmp = "$DefaultTfVarsFile.tmp"
if (Test-Path $DefaultTfVarsFileTmp) {
    Remove-Item $DefaultTfVarsFileTmp -Force
}
Write-Host "Downloading $TfWorkspace.tfvars in $env:ENCLAVE enclave"
Get-Blob -StorageAccountInfo $TfStorageAccountInfo `
    -BlobName "$TfWorkspace.tfvars" `
    -LocalFile $DefaultTfVarsFileTmp `
    -ErrorAction SilentlyContinue `
    1> $null

# If the TF Workspace Var File doesn't exist,
# default to the Global.tfvars file
if (-Not (Test-Path $DefaultTfVarsFileTmp)) {
    Write-Host "Download Global Terraform Variables File, if one exists"
    Get-Blob -StorageAccountInfo $TfStorageAccountInfo `
        -BlobName "Global.tfvars" `
        -LocalFile $DefaultTfVarsFileTmp `
        -ErrorAction SilentlyContinue `
        1> $null
}

Write-Host "============ Default TF Vars File ============="
if (Test-Path $DefaultTfVarsFileTmp) {
    Move-Item -Path $DefaultTfVarsFileTmp `
        -Destination $DefaultTfVarsFile -Force
}
Get-Content $DefaultTfVarsFile

# Export Terraform Variables
if ($TfVars) {
    $TfVars -Split ' ' |
    ForEach-Object {
        $KeyValue = $_ -Split '=', 2
        if ($KeyValue.Length -gt 1) {
            $Key = $KeyValue[0]
            $Value = $KeyValue[1].Trim()
            Invoke-Expression "`$env:$Key='$Value'"
        }
    }
}

$env:TF_VAR_environment_name = $TfWorkspace
$env:TF_VAR_parent_module = $TfModule
$env:TF_VAR_stage = $Stage
$env:TF_VAR_subscription_id = $SubscriptionId
$env:TF_VAR_functional_area = $FuncArea
$env:TF_VAR_project = $Project
$env:TF_VAR_c1_project = $C1Project
$env:TF_VAR_tfstate_resource_group = $TfStateResourceGroup
$env:TF_VAR_tfstate_storage_account = $TfStateStorageAccount
$env:TF_VAR_tfstate_container = $TfStateContainer
$env:TF_VAR_tfstate_key = "$TfModule/$TfWorkspace.tfstate"
$env:TF_VAR_aks_server_id = $AksServerId
$env:TF_VAR_aks_use_service_principal = $AksUseServicePrincipal
$env:TF_VAR_aks_argo_cd_deployed = $AksArgoCdDeployed
$env:TF_VAR_aks_kmsv2_setup = $AksKmsV2Setup
$env:TF_VAR_aks_kube_api_server_endpoint_ip = $AksKubeApiServerEndpointIp
$env:TF_VAR_metadata_host = $MetadataHost
$env:TF_VAR_root_domain = $RootDomain

# Set additional TF Flags based on Action
$TfFlags = Get-TerraformFlags -Action $TfAction -DefaultVarsFile "..\.default.tfvars"

Write-Host "=============== Terraform Flags ==============="
Write-Host $TfFlags
Write-Host "==============================================="

Write-Host "================= KUBECONFIG =================="
$env:KUBECONFIG = "$BinDir\kubeconfig"
Get-Content $env:KUBECONFIG
Write-Host "==============================================="


if (Test-Path $terraform) {
    Write-Host "Found Terraform at: $terraform"

    # Check if the Terraform directory exists
    if (Test-Path "$IaCDir/$TfDir") {
        Set-Location "$IaCDir/$TfDir"

        Write-Host "TfAction: $TfAction"
        # Handle drift detection as a first-class action without impacting existing flows
        if ($TfAction -eq "detect-drift") {
            Write-Host "Retrieving drift storage information from global Terraform state..."
            $GlobalOutputs = Get-TerraformStateOutputs `
                -TfStateStorageInfo $TfStorageAccountInfo `
                -Enclave $env:ENCLAVE `
                -TfModule 'global' `
                -TfWorkspace 'Global' `
                -ErrorAction Stop


            Write-Host "Executing Terraform drift detection..."
            $driftResult = Test-TerraformDrift `
                -Terraform $terraform `
                -Enclave $env:ENCLAVE `
                -Workspace $env:TF_Workspace `
                -Module $env:TF_Module `
                -DefaultVarsFile "..\.default.tfvars" `
                -ErrorAction Stop

            if ([bool]$driftResult.DriftDetected) {
                Write-Host "Publishing drift report..."

                # Capture drift storage account info
                $DriftStorageAccountInfo = New-StorageAccountInfo `
                    -Name $GlobalOutputs.global_storage_account_name `
                    -Container $GlobalOutputs.drift_storage_container_name

                Publish-DriftReport `
                    -DriftStorageInfo $DriftStorageAccountInfo `
                    -ReportData $driftResult.ReportObject `
                    -ErrorAction Stop
            }

            exit [int]$driftResult.ExitCode
        }

        # Check to see if we need to fix the AKS Service Prinicipal permissions.
        # When creating the AKS cluster for the first time,
        # we'll enable AKS Local Accounts to setup the Service Principal Admin permissions.
        # After the SP Admin permissions are setup, we'll disbale the AKS Local Accounts.
        if ($TfModule -eq "infrastructure") {
            Write-Host "AksServerId: $AksServerId"
            Write-Host "AksLocalAccountsDisabled: $AksLocalAccountsDisabled"
            Write-Host "AksUseServicePrincipal: $AksUseServicePrincipal"
            Write-Host "AksArgoCdDeployed: $AksArgoCdDeployed"

            $CleanupTfState = $false
            if ("$AksServerId" -eq "") {
                # AKS Cluster doesn't exist.
                # Create the AKS cluster with local accounts enabled and apply SP Admin permissions.
                # Make sure to clean-up the TF State file, prioir to running TF, to prevent TF errors.
                $CleanupTfState = $true
            }
            else {
                if ([System.Convert]::ToBoolean($AksLocalAccountsDisabled) -and
                    (-not [System.Convert]::ToBoolean($AksUseServicePrincipal))) {
                    # AKS Cluster exists with Local Accounts disabled.
                    # However, the Service principal doesn't have the correct permissions.
                    # Terraform will re-enable the AKS local accounts to apply the SP permissions.
                    # Make sure to clean-up the TF State file, prioir to running TF, to prevent TF errors.
                    $CleanupTfState = $true
                }
            }
            if ($CleanupTfState) {
                Write-Host "If necessary, clean up the Terraform State to prevent TF errors."
                try {
                    & "$terraform" state rm 'kubernetes_cluster_role_binding_v1.sp-admin' 2>$null
                }
                catch {}
            }
        }
        elseif (($TfModule -eq "software") -and ($TfAction -in @("apply", "plan"))) {
            # If necessary, we may need to move TF resources to support TF module updates
            Move-TerraformResources -terraform "$terraform"
        }

        Write-Host "=============== Print TF Vars ==============="
        Get-ChildItem env:TF_VAR_* | Sort-Object Name
        $RetryAttempts = 0
        $MaxRetryAttempts = 3

        while ($RetryAttempts -le $MaxRetryAttempts) {
            Write-Host "Running Execute-Terraform..."

            & "$terraform" $TfAction @TfFlags 2>&1 | `
                Tee-Object -Variable TfResults

            if ($TfResults | Where-Object { $_ -match '^Error:.*' }) {
                # Only attempt retries on Terraform Apply
                if ($TfAction -eq "apply") {
                    Write-Host "Terraform encountered an error."
                    if ($TfResults | Select-String 'Public network access is disabled') {
                        $RetryAttempts++
                        Write-Host "Message Found: 'Public network access is disabled'"
                        Write-Host "RetryAttempts: $RetryAttempts"
                    }
                    elseif ($TfResults | Select-String 'This TCP connection does not allow access') {
                        $RetryAttempts++
                        Write-Host "Message Found: 'This TCP connection does not allow access'"
                        Write-Host "RetryAttempts: $RetryAttempts"
                    }
                    elseif ($TfResults | Select-String 'dial tcp') {
                        $RetryAttempts++
                        Write-Host "Message Found: 'dial tcp'"
                        Write-Host "RetryAttempts: $RetryAttempts"
                    }
                    else {
                        Write-Host "Terraform encountered an unexpected error. Exiting.."
                        exit -1
                    }
                }
                else {
                    Write-Host "Terraform encountered an error. Exiting.."
                    exit -1
                }
            }
            else {
                if ($TfAction -eq "destroy" -and `
                        $TfModule -eq "infrastructure") {
                    # If we just performed a TF destroy on the Infrastructure,
                    # Try to remvove the TF state file of the Software module
                    Remove-StateFile -TfStateStorageInfo $TfStorageAccountInfo `
                        -TfWorkspace $TfWorkspace `
                        -TfModule "software" `
                        -Enclave $env:ENCLAVE `
                        2>&1
                }
                Write-Host "Terraform executed successfully."
                break
            }
        }
        if ($RetryAttempts -gt $MaxRetryAttempts) {
            Write-Host "Maximum Retry attempts reached. Exiting.."
            exit -1
        }

        if ($TfAction -eq "apply") {
            # Generate TLS Certs, if needed
            if ($TfModule -eq "infrastructure") {
                if ($GenerateCerts -eq "true") {
                    Write-Host "Generating TLS Certs.."

                    $Suffix = $TfWorkspace.ToLower()
                    if (@("test", "prod") -contains $Suffix) {
                        $Suffix = ""
                    }

                    $KeyVault = (& "$terraform" output key_vault_name).Replace('"', '')
                    Write-Host "KeyVault: $KeyVault"
                    & "$IaCDir\scripts\ps\cert\Generate-Certs.ps1" `
                        -Suffix $Suffix `
                        -RootDomain $RootDomain `
                        -KeyVault $KeyVault
                }
            }

            # Execute Post PowerShell scripts, if needed
            if ($PostPowerShellScripts) {
                Write-Host "PostPowerShellScripts: $PostPowerShellScripts"
                $PostPowerShellScripts.Split(',') | ForEach-Object {
                    Write-Host "Running PostPowerShellScript: $_"
                    & "$IaCDir\scripts\ps\$_" `
                        -BinDir $BinDir
                    $PS_LASTEXITCODE = $LASTEXITCODE
                    "PowerShell LASTEXITCODE: $PS_LASTEXITCODE"
                    if ($PS_LASTEXITCODE -ne 0) {
                        Write-Output "Error running PostPowerShellScript. Exiting.."
                        exit -1
                    }
                }
            }
        }
    }
    else {
        Write-Error "Terraform directory not found: $IaCDir/$TfDir"
        exit 1
    }
}
else {
    Write-Error "Terraform not found at: $terraform"
    exit 1
}
exit 0
