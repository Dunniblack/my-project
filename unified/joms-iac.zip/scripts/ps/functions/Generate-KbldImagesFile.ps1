[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPlainTextForPassword', 'NexusPassword',
	Justification = 'Password is stored in plain text before being passed to this script and would need to be converted back to plain text in this script')]
param (
	[Parameter(Mandatory = $true)]
	[string]$AksCluster,
	[Parameter(Mandatory = $true)]
	[string]$AksResourceGroup,
	[Parameter(Mandatory = $false)]
	[string]$ArgoCdNamespace = "argocd",
	[Parameter(Mandatory = $false)]
	[string]$ParentArgoApp = "bootstrap-parent",
	[Parameter(Mandatory = $true)]
	[string]$NEXUS_USERNAME,
	[Parameter(Mandatory = $true)]
	[string]$NEXUS_PASSWORD,
	[Parameter(Mandatory = $true)]
	[string]$NEXUS_DOMAIN,
	[Parameter(Mandatory = $true)]
	[string]$NEXUS_REPO,
	[Parameter(Mandatory = $true)]
	[string]$BinDir,
	[Parameter(Mandatory = $false)]
	[string]$NexusHelmIndexFile = "IaC\helm\index.yaml",
	[Parameter(Mandatory = $false)]
	[string]$HelmChartSkip = "kyverno-policies",
	[Parameter(Mandatory = $false)]
	[bool]$PrintDebug = $false
)
Write-Output "AksCluster: $AksCluster"

# Update Path Variable
$env:Path += ";$BinDir"

# Helm Version
& "$BinDir\helm" version

# Download the Helm Registy index.yaml file
$ImgpkgImagesFiles = @()
$HelmIndexFile = ".\index.yaml"
$NexusHelmFolder = Split-Path -parent $NexusHelmIndexFile
& scripts\ps\functions\Download-Nexus.ps1 `
	-ArtifactSource $NexusHelmIndexFile `
	-ArtifactDestination $HelmIndexFile `
	-NexusRepo  $NEXUS_REPO `
	-NexusUsername "$NEXUS_USERNAME" `
	-NexusPassword "$NEXUS_PASSWORD"

$HelmIndex = ((Get-Content $HelmIndexFile | yq -e -o=json) | ConvertFrom-Json) `
| Select -ExpandProperty "entries"

# Setup Kube Context to AKS Cluster
try {
	Write-Output "Removing KubeConfig: $env:USERPROFILE\.kube\config"
	Remote-Item -Path "$env:USERPROFILE\.kube\config" -Force
}
catch {}
az aks get-credentials -n $AksCluster -g $AksResourceGroup --format azure --overwrite-existing
kubelogin convert-kubeconfig  -l azurecli

# Get the targeted K8s version
$KubeVersion = (az aks show -n $AksCluster -g $AksResourceGroup --query kubernetesVersion -o tsv)

# Get a list of all the Argo Apps
$ArgoApps = $(kubectl -n $ArgocdNamespace get application -ocustom-columns=":metadata.name" `
	| where { $_ -ne $ParentArgoApp })


$ArgoApps | ForEach-Object {
	$ArgoApp = $_
	if ($ArgoApp) {
		Write-Output "ArgoApp: $_"

		# Identify all the Helm sources
		$HelmSources = (kubectl -n $ArgocdNamespace get application $ArgoApp -ojson `
			| ConvertFrom-Json).spec.sources
		if (-Not $HelmSources) {
			$HelmSources = (kubectl -n $ArgocdNamespace get application $ArgoApp -ojson `
				| ConvertFrom-Json).spec.source
		}

		# Identify the Docker images for each Helm chart
		$HelmSources | ForEach-Object {
			$HelmSource = $_
			$HelmRepoURL = $HelmSource.repoURL
			$HelmChart = $HelmSource.chart
			$HelmVersion = $HelmSource.targetRevision
			Write-Output "Generate images.yml for Helm Source:"
			Write-Output "HelmChart: $HelmRepoURL/$HelmChart"
			Write-Output "HelmVersion: $HelmVersion"

			# Skip the Helm charts that throw errors
			if ($HelmChartSkip.Split(',') -notcontains $HelmChart) {

				$HelmValues = $HelmSource.helm.values
				$HelmValuesFile = "./$HelmChart-values.yml"
				$HelmValuesFiles = $HelmSource.helm.valueFiles
				$HelmConfigFile = "./$HelmChart-config.yml"
				$ImgpkgFolder = "./$HelmChart/.imgpkg"
				$ImgpkgImagesFile = "$ImgpkgFolder/images.yml"

				# Save the Helm values to a local file
				Set-Content $HelmValuesFile $HelmValues

				# Apply multiple Helm values files, if needed
				$AllHelmValuesFiles = "$HelmValuesFile"
				if ($HelmValuesFiles) {
					$AllHelmValuesFiles = "$HelmValuesFile,$HelmChart/$($HelmValuesFiles -Join ",$HelmChart/")"
				}
				Write-Output "AllHelmValuesFiles: $AllHelmValuesFiles"

				# Verify the Helm versions align
				$CurrentHelmChart = $HelmIndex.$HelmChart | Where-Object -Property "version" -eq $HelmVersion
				if (-not $CurrentHelmChart) {
					Write-Output "Error finding the correct Helm version in the Helm index file. Exiting.."
					Write-Output "Expected Version: $HelmVersion"
					Write-Output "Found Versions: $($HelmIndex.$HelmChart.version -Join ", ")"
					exit 1
				}

				# Delete the old Helm Chart folder, if it exists
				if (Test-Path -Path ".\$HelmChart" ) {
					Remove-Item -Path ".\$HelmChart" -Recurse -Force
				}

				# Download the Helm chart
				$ArtifactSource = $CurrentHelmChart.urls
				$ArtifactDestination = ".\$HelmChart.tgz"
				& scripts\ps\functions\Download-Nexus.ps1 `
					-ArtifactSource "$NexusHelmFolder\$ArtifactSource " `
					-ArtifactDestination $ArtifactDestination `
					-NexusRepo  $NEXUS_REPO `
					-NexusUsername "$NEXUS_USERNAME" `
					-NexusPassword "$NEXUS_PASSWORD"

				# Extract the Helm Chart
				tar -xzf  $ArtifactDestination

				# If Debugging, print Values files
				if ($PrintDebug) {
					$AllHelmValuesFiles.split(",") | ForEach-Object {
						$HelmValuesFile = $_
						"======================================"
						"HelmValuesFile: $HelmValuesFile"
						Get-Content $HelmValuesFile
						"======================================"
					}
				}

				# Make sure the .imgpkg folder exists
				if (-Not (Test-Path $ImgpkgFolder)) {
					New-Item -Path $ImgpkgFolder -ItemType "Directory" -Force | Out-Null
				}

				# Render Helm templates
				(& "$BinDir\helm" template $HelmChart --values $AllHelmValuesFiles --kube-version $KubeVersion) | `
					Set-Content $HelmConfigFile -Encoding UTF8
				$HELM_LASTEXITCODE = $LASTEXITCODE
				"HELM LASTEXITCODE: $HELM_LASTEXITCODE"
				if ($HELM_LASTEXITCODE -ne 0) {
					Write-Output "Error rendering Helm templates. Exiting.."
					exit 1
				}
				if ($PrintDebug) {
					"--------------------------------------"
					"HelmConfigFile: $HelmConfigFile"
					Get-Content $HelmConfigFile
					"--------------------------------------"
				}


				# Generate the .imgpkg/images.yaml file
				& "$BinDir\kbld" -f $HelmConfigFile --imgpkg-lock-output $ImgpkgImagesFile  | Out-Null
				$KBLD_LASTEXITCODE = $LASTEXITCODE
				"KBLD LASTEXITCODE: $KBLD_LASTEXITCODE"
				if ($KBLD_LASTEXITCODE -ne 0) {
					Write-Output "Error rendering Kbld templates. Exiting.."
					exit 1
				}

				$ImgpkgImagesFiles += $ImgpkgImagesFile
			}
		}
	}
}

# Aggregate the .imgpkg/images.yaml files into one
$FinalImgpkgImageFile = "kbld-images-file.yaml"
@"
apiVersion: imgpkg.carvel.dev/v1alpha1
kind: ImagesLock
images:
"@ | Set-Content $FinalImgpkgImageFile

$ImgpkgImagesFiles | ForEach-Object {
	$Images = (Get-Content $_ | yq .images)
	if ($Images -and ($Images.Trim() -ne 'null')) {
		Add-Content $FinalImgpkgImageFile $Images
	}
}

Get-Content $FinalImgpkgImageFile | yq -e

Write-Output "Upload the Kbld Images File"

$bytes = [System.Text.Encoding]::ASCII.GetBytes("$($NEXUS_USERNAME):$NEXUS_PASSWORD")
$base64AuthInfo = [Convert]::ToBase64String($bytes)
$headers = @{Authorization = "Basic $base64AuthInfo" }

Function Upload-Nexus {
	Param (
		[Parameter(Mandatory = $true)]
		[string]$File,
		[Parameter(Mandatory = $false)]
		[string]$Location = 'IaC/manifest'
	)
	Invoke-WebRequest -Method Put `
		-URI "https://$NEXUS_DOMAIN/repository/$NEXUS_REPO/$Location/$File" `
		-InFile $File `
		-ContentType 'application/x-yaml' `
		-Headers $headers `
		-UseBasicParsing
}

Upload-Nexus -File $FinalImgpkgImageFile
$DateTime = (Get-Date).ToString("yyyyMMdd-hhmmss")
Upload-Nexus -File $FinalImgpkgImageFile -Location "IaC/manifest/$DateTime"



