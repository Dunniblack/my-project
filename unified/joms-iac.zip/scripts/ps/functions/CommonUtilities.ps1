Set-StrictMode -Version Latest

<#
.SYNOPSIS
    Executes an external command and throws on failure (non-zero exit code).

.DESCRIPTION
    Ensures external tools (git, az, etc.) respect $ErrorActionPreference = 'Stop' by checking $LASTEXITCODE.

.NOTES
    Alias: Exec

.EXAMPLE
    Exec git push origin main
#>
function Invoke-ExternalCommand {
    # Parse arguments into the command and pass-through arguments
    $Command, $PassThroughArguments = $Args

    # Collect pass-through arguments into an array - ensures single passthrough arg is not captured as a String
    $CommandArguments = @($PassThroughArguments)

    # Store original ErrorActionPreference
    $originalErrorActionPreference = $ErrorActionPreference

    try {
        # Temporarily allow external command warnings to not terminate the script
        # This is necessary because Azure CLI sends warnings to stderr for preview features,
        # and PowerShell treats stderr as errors when ErrorActionPreference = 'Stop'
        $ErrorActionPreference = 'Continue'

        # Execute the command with pass-through arguments
        & $Command @CommandArguments

        # Check exit code and throw if command failed
        if ($LASTEXITCODE -ne $null -and $LASTEXITCODE -ne 0) {
            throw "External command failed with exit code $LASTEXITCODE"
        }
    }
    finally {
        # Always restore original ErrorActionPreference
        $ErrorActionPreference = $originalErrorActionPreference
    }
}


<#
.SYNOPSIS
    Returns one of two values based on a boolean condition.

.DESCRIPTION
    Ternary operator polyfill for older PowerShell versions.

.EXAMPLE
    Get-Conditional ($val -gt 5) "High" "Low"
#>
function Get-Conditional {
    param(
        [Parameter(Mandatory, Position = 0)]
        [bool]$Condition,

        [Parameter(Mandatory, Position = 1)]
        [Object]$IfTrue,

        [Parameter(Mandatory, Position = 2)]
        [Object]$IfFalse
    )

    if ($Condition) {
        return $IfTrue
    }
    return $IfFalse
}

<#
.SYNOPSIS
    Returns the value if not null, otherwise returns the default value.

.DESCRIPTION
    Null-coalescing operator (??) polyfill for older PowerShell versions.

.EXAMPLE
    Get-Coalesce $Val "Default"
#>
function Get-Coalesce {
    param(
        [Parameter(Mandatory, Position = 0)]
        [AllowNull()]
        [Object]$Value,

        [Parameter(Mandatory, Position = 1)]
        [Object]$Default
    )

    if ($null -ne $Value) {
        return $Value
    }
    return $Default
}

# Create short alias for Invoke-ExternalCommand - allows cleaner syntax in scripts
Set-Alias -Name Exec -Value Invoke-ExternalCommand -Description "Execute external command with error checking"
