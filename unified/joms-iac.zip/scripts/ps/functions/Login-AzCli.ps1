# Log into Azure and set default Sunscription
[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$ARM_CLIENT_ID,
    [Parameter(Mandatory = $true)]
    [string]$ARM_CLIENT_SECRET,
    [Parameter(Mandatory = $true)]
    [string]$ARM_TENANT_ID,
    [Parameter(Mandatory = $false)]
    [string]$ARM_CLOUD = "AzureUSGovernment",
    [Parameter(Mandatory = $false)]
    [string]$ARM_CA_CERT_PATH = ".\certs\trust\azure-ca.crt",
    [Parameter(Mandatory = $false)]
    [bool]$POWERSHELL_LOGIN = $false
)

$ErrorActionPreference = 'Stop'

# Import common functions
. "$PSScriptRoot/CommonUtilities.ps1"

if (Test-Path $ARM_CA_CERT_PATH) {
    $env:REQUESTS_CA_BUNDLE = $ARM_CA_CERT_PATH
    Write-Output $env:REQUESTS_CA_BUNDLE
}
else {
    Write-Output "The path '$ARM_CA_CERT_PATH' does not exist."
}

Write-Host "Set Cloud Enclave"
Exec az cloud set --name $ARM_CLOUD

Write-Host "Logging into Azure using service principal"
Exec az login `
    --service-principal `
    --username $ARM_CLIENT_ID `
    --password $ARM_CLIENT_SECRET `
    --tenant $ARM_TENANT_ID

Write-Host "Listing available subscriptions"
Exec az account list

Write-Host "Get default subscription"
$Subscription = "$(Exec az account list --query '[0].id' --output tsv)"

Write-Host "Set Subscription: $Subscription"
Exec az account set --subscription $Subscription

Write-Host "Current account context:"
Exec az account show

if ($POWERSHELL_LOGIN) {
    Write-Host "Log into Azure with PowerShell Modules"
    $SecurePassword = ConvertTo-SecureString $ARM_CLIENT_SECRET -AsPlainText -Force
    $Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $ARM_CLIENT_ID, $SecurePassword
    Connect-AzAccount -ServicePrincipal -TenantId $ARM_TENANT_ID -Credential $Credential -Environment $ARM_CLOUD
    Write-Host "Success!"
}
