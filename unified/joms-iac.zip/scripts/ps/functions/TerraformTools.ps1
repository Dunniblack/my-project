
function Write-Section {
    param([Parameter(Mandatory)][string]$Title)
    Write-Host ("=" * 15 + " $Title " + "=" * 15)
}

function Get-TerraformFlags {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidateSet('plan', 'apply', 'destroy', 'show', 'detect-drift')] [string]$Action,
        [Parameter(Mandatory = $false)][string]$DefaultVarsFile
    )
    $ResolvedAction = Get-Conditional -Condition ($Action -eq 'detect-drift') -IfTrue 'plan' -IfFalse $Action
    $flags = @('-no-color', '-compact-warnings')
    if ($ResolvedAction -in @('plan', 'apply', 'destroy') -and $DefaultVarsFile) { $flags += @('-var-file', $DefaultVarsFile) }
    if ($ResolvedAction -in @('apply', 'destroy')) { $flags += '-auto-approve' }
    return $flags
}

function Build-StateFileName {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Enclave,
        [Parameter(Mandatory)][string]$TfWorkspace
    )

    $TFStateFile = "$TfWorkspace.tfstate"
    if ($Enclave -eq "wdsf") {
        $TFStateFile = "$TfWorkspace.tfstateenv:$TfWorkspace"
    }
    return $TFStateFile
}

function Get-StateFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][StorageAccountInfo]$TfStateStorageInfo,
        [Parameter(Mandatory)][string]$Enclave,
        [Parameter(Mandatory)][string]$TfWorkspace,
        [Parameter(Mandatory)][string]$TfModule,
        [Parameter(Mandatory)][string]$LocalFile
    )

    $TfStateFile = Build-StateFileName -TfWorkspace $TfWorkspace -Enclave $Enclave
    Write-Host "Retrieving Terraform state file $TfModule/$TfStateFile..."
    try {
        Get-Blob `
            -StorageAccountInfo $TfStateStorageInfo `
            -BlobName "$TfModule/$TFStateFile" `
            -LocalFile $LocalFile `
            -ErrorAction Stop |
        Out-Null
    }
    catch {
        Write-Error "Failed to retrieve Terraform state file $TfModule/$TFStateFile to $LocalFile : $_"
    }
}

function Remove-StateFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][StorageAccountInfo]$TfStateStorageInfo,
        [Parameter(Mandatory)][string]$Enclave,
        [Parameter(Mandatory)][string]$TfWorkspace,
        [Parameter(Mandatory)][string]$TfModule
    )

    $TfStateFile = Build-StateFileName -TfWorkspace $TfWorkspace -Enclave $Enclave
    Remove-Blob -StorageAccountInfo $TfStateStorageInfo -BlobName "$TfModule/$TFStateFile"
}

function Get-TerraformStateOutputs {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][StorageAccountInfo]$TfStateStorageInfo,
        [Parameter(Mandatory)][string]$Enclave,
        [Parameter(Mandatory)][string]$TfWorkspace,
        [Parameter(Mandatory)][string]$TfModule
    )

    $TempStateFile = [System.IO.Path]::GetTempFileName()
    try {
        Get-StateFile `
            -TfStateStorageInfo $TfStateStorageInfo `
            -Enclave $Enclave `
            -TfWorkspace $TfWorkspace `
            -TfModule $TfModule `
            -LocalFile $TempStateFile |
        Out-Null

        $Json = $null
        try {
            $Json = Get-Content $TempStateFile | ConvertFrom-Json
        }
        catch {
            Write-Error "Failed to parse Terraform state file $TempStateFile : $_"
        }

        try {
            $Outputs = @{}
            foreach ($Key in $Json.outputs.PSObject.Properties.Name) {
                $Outputs[$Key] = $Json.outputs.$Key.value
            }
            return $Outputs
        }
        catch {
            Write-Error "Failed to parse Terraform state outputs from JSON: $_"
        }
    }
    finally {
        Remove-Item -Path $TempStateFile -ErrorAction SilentlyContinue
    }
}

function Publish-DriftReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][StorageAccountInfo]$DriftStorageInfo,
        [Parameter(Mandatory)][object]$ReportData
    )

    $Enclave = $ReportData.Enclave
    $Module = $ReportData.Module
    $Workspace = $ReportData.Workspace
    $Timestamp = $ReportData.TimeGenerated

    $tempFile = [System.IO.Path]::GetTempFileName()
    try {
        Out-File -InputObject $ReportData.TerraformLog -FilePath $tempFile -Encoding UTF8

        # Upload the file
        Save-Blob `
            -StorageAccountInfo $DriftStorageInfo `
            -BlobName "$Enclave-$Module-$Workspace-$Timestamp-drift-alert.log" `
            -FilePath $tempFile
    }
    finally {
        Remove-Item -Path $tempFile -ErrorAction SilentlyContinue
    }
}

function Test-TerraformDrift {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Terraform,
        [Parameter(Mandatory)][string]$Enclave,
        [Parameter(Mandatory)][string]$Workspace,
        [Parameter(Mandatory)][string]$Module,
        [Parameter(Mandatory = $false)][string]$DefaultVarsFile
    )
    Write-Host "Testing for Terraform drift..."
    $flags = Get-TerraformFlags -Action 'plan' -DefaultVarsFile $DefaultVarsFile

    # Create a temporary zero byte file - this is overwritten by terraform plan
    $tempPlanFile = [System.IO.Path]::GetTempFileName()
    try {
        # Run terraform plan with flags to perform drift detection only
        # See: https://developer.hashicorp.com/terraform/cli/commands/plan#planning-modes
        # See: https://developer.hashicorp.com/terraform/cli/commands/plan#exit-codes
        # Capture raw text output
        $TextOutput = & $Terraform 'plan' @($flags + @('-refresh-only', '-detailed-exitcode', "-out=$tempPlanFile"))

        $ExitCode = [int]$LASTEXITCODE
        $DriftDetected = [boolean]($ExitCode -eq 2)
        $JsonData = $null

        # If drift is detected, build JSON data for logging and/or publication
        if ($DriftDetected) {
            Write-Host "Generating drift report..."
            $plan = & $Terraform show -json $tempPlanFile | ConvertFrom-Json

            $resourceDrift = $plan.resource_drift
            $timestamp = Get-Coalesce -Value $plan.timestamp -Default (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")

            $JsonData = @{
                Version       = "1.0"
                TimeGenerated = $timestamp
                Enclave       = $Enclave
                Module        = $Module
                Workspace     = $Workspace
                ResourceDrift = $resourceDrift
                TerraformLog = $TextOutput
            }
        }
        else {
            Write-Host "No drift detected"
        }

        return [pscustomobject]@{
            # If drift is detected, exit code is 0, otherwise it is the exit code of the terraform plan
            ExitCode      = [int](Get-Conditional $DriftDetected 0 $ExitCode)
            DriftDetected = [boolean]$DriftDetected
            ReportObject  = $JsonData
        }
    }
    finally {
        # Clean up plan file
        Remove-Item -Path $tempPlanFile -ErrorAction SilentlyContinue
    }
}
