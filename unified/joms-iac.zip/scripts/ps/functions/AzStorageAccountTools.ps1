

class StorageAccountInfo {
    [ValidateNotNullOrEmpty()][string]$Name
    [ValidateNotNullOrEmpty()][string]$Container
    [string]$AccountKey

    StorageAccountInfo($Name, $Container) {
        $this.Init($Name, $Container, $null)
    }

    StorageAccountInfo($Name, $Container, $AccountKey) {
        $this.Init($Name, $Container, $AccountKey)
    }

    # Shared initialization logic
    hidden [void] Init($Name, $Container, $AccountKey) {
        $this.Name = $Name
        $this.Container = $Container
        $this.AccountKey = $AccountKey
    }
}

function New-StorageAccountInfo {
    [cmdletbinding()]
    Param (
        [Parameter(Mandatory = $true, Position = 0)]
        [String]$Name,
        [Parameter(Mandatory = $true, Position = 1)]
        [String]$Container,
        [Parameter(Mandatory = $false, Position = 2)]
        [String]$AccountKey
    )


    if ($AccountKey) {
        return [StorageAccountInfo]::New($Name, $Container, $AccountKey)
    }
    else {
        return [StorageAccountInfo]::New($Name, $Container)
    }
}

function Get-Blob {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][StorageAccountInfo]$StorageAccountInfo,
        [Parameter(Mandatory)][string]$BlobName,
        [Parameter(Mandatory)][string]$LocalFile
    )

    try {
        $params = @(
            'storage', 'blob', 'download',
            '--name', $BlobName,
            '--file', $LocalFile,
            '--overwrite', 'true',
            '--only-show-errors',
            '--no-progress'
        ) + (Get-StorageAccountArgs $StorageAccountInfo)

        Invoke-ExternalCommand az @params
    }
    catch {
        Write-Error "Failed to download blob $BlobName to $LocalFile : $($_.Exception.Message)"
    }
}

function Save-Blob {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][StorageAccountInfo]$StorageAccountInfo,
        [Parameter(Mandatory)][string]$BlobName,
        [Parameter(Mandatory)][string]$FilePath
    )

    try {
        $params = @(
            'storage', 'blob', 'upload',
            '--name', $BlobName,
            '--file', $FilePath,
            '--only-show-errors',
            '--no-progress'
        ) + (Get-StorageAccountArgs $StorageAccountInfo)
        Invoke-ExternalCommand az @params
    }
    catch {
        Write-Error "Failed to save blob $BlobName : $($_.Exception.Message)"
    }
}

function Remove-Blob {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][StorageAccountInfo]$StorageAccountInfo,
        [Parameter(Mandatory)][string]$BlobName
    )

    try {
        $params = @(
            'storage', 'blob', 'delete',
            '--name', $BlobName,
            '--only-show-errors'
        ) + (Get-StorageAccountArgs $StorageAccountInfo)
        Invoke-ExternalCommand az @params
    }
    catch {
        Write-Error "Failed to remove blob $BlobName : $($_.Exception.Message)"
    }
}

# Helper function to get blob authentication arguments based on storage account info
function Get-StorageAccountArgs {
    param(
        [Parameter(Mandatory)][StorageAccountInfo]$StorageAccountInfo
    )

    $params = @(
        '--account-name', $StorageAccountInfo.Name,
        '--container-name', $StorageAccountInfo.Container,
        '--auth-mode', 'key'
    )

    if ($StorageAccountInfo.AccountKey) {
        $params += (
            '--account-key', $StorageAccountInfo.AccountKey
        )
    }

    return $params
}
