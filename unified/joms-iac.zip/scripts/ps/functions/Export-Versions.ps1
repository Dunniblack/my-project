# Export Version numbers
((Get-Content scripts/sh/metadata/versions.sh) -match '=') | `
    ForEach-Object {
        $KeyValue = (($_ -split 'export')[-1]).Trim()
        $KeyValue = $KeyValue.Split('=')
        $Key = $KeyValue[0]
        $Value = $KeyValue[1]
        Invoke-Expression "`$env:$Key='$Value'"
    }