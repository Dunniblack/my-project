# Exrtract an Archive and verify the extracted file exists
[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$Archive,
    [Parameter(Mandatory = $true)]
    [string]$Destination,
    [Parameter(Mandatory = $false)]
    [string]$VerifyFile = $Null
)

if (-Not (Test-Path $Destination)) {
    New-Item -Path $Destination -ItemType Directory -Force
}

try {
    Write-Host "Extracting Archive: $Archive"
    Expand-Archive -Path $Archive `
        -DestinationPath $Destination `
        -Force
}
catch {
    Write-Error "Failed to extract Archive: $_"
    exit 1
}

if ($VerifyFile) {
    $File = "$Destination\$VerifyFile"
    if (Test-Path $File) {
        Write-Host "Verified file: $File"
    }
    else {
        Write-Error "File not found ($File)!"
        exit 1
    }
}
