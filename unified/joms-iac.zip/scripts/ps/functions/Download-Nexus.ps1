# Download the artifact from Nexus
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPlainTextForPassword', 'NexusPassword',
    Justification = 'Password is stored in plain text before being passed to this script and would need to be converted back to plain text in this script')]
param (
    [Parameter(Mandatory = $true)]
    [string]$ArtifactSource,
    [Parameter(Mandatory = $true)]
    [string]$ArtifactDestination,
    [Parameter(Mandatory = $true)]
    [string]$NexusRepo,
    [Parameter(Mandatory = $true)]
    [string]$NexusUsername,
    [Parameter(Mandatory = $true)]
    [string]$NexusPassword
)

Write-Host "Downloading $ArtifactSource from Nexus"
$url = "https://nexus.seicdevops.com/" + `
    "repository/$NexusRepo/$ArtifactSource"

$bytes = [System.Text.Encoding]::ASCII.GetBytes("$($NexusUsername):$NexusPassword")
$base64AuthInfo = [Convert]::ToBase64String($bytes)
$headers = @{Authorization = "Basic $base64AuthInfo" }

try {
    Invoke-WebRequest -Uri $url -OutFile $ArtifactDestination -Headers $headers
    Write-Host "Artifact downloaded successfully"
}
catch {
    Write-Error "Failed to download artifact: $_"; exit 1
}
