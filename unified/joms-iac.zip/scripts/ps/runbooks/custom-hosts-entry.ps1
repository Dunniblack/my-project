# This script adds or removes custom entries in the Hosts file on specified VMs.

param (
    [Parameter(Mandatory = $false)]
    [string]$custom_entries,

    [Parameter(Mandatory = $false)]
    [bool]$remove_custom_entries = $false,

    [Parameter(Mandatory = $false)]
    [string]$filter_vm = "BST",

    [Parameter(Mandatory = $false)]
    [string]$filter_rg_vm = "APP-RGP-01"
)

# Define a unique comment to identify entries managed by this script
$customComment = "# Custom DNS Entry"

Write-Output "Logging into Azure using Managed Identity..."
try {
    Connect-AzAccount -Identity -EnvironmentName "AzureUSGovernment"
}
catch {
    Write-Error -Message "Failed to authenticate. Error: $_.Exception"
    throw $_.Exception
}

# Validate parameters
if (-not $remove_custom_entries -and [string]::IsNullOrWhiteSpace($custom_entries)) {
    throw "Parameter 'custom_entries' cannot be empty when not removing entries. Please provide a comma-separated list of entries (e.g., '10.0.0.0 host1.com,10.0.0.1 host2.com')."
}

# Prepare entries to add to hosts file
$contenToAdd = ""
if (-not $remove_custom_entries) {
    $entryList = $custom_entries.Split(',') | ForEach-Object { $_.Trim() }
    foreach ($entry in $entryList) {
        if ($entry) {
            # Ensure it's not an empty string from a trailing comma
            $contenToAdd += "$entry`t$customComment,"
        }
    }
}

Write-Output "`r`nContent to be added:"
Write-Output $contenToAdd.Replace(',', "`r`n")

# Prepare script to run on VMs ##############################
$part1 = @"
param(
    [string]`$custom_comment,
    [string]`$entries_to_add
)

`$hosts_file = "`$env:windir\System32\drivers\etc\hosts"
`$backup_dir = "C:\temp\hosts_backup\"

if (!(Test-Path `$backup_dir)) { New-Item -ItemType Directory -Path `$backup_dir -Force }
Copy-Item `$hosts_file "`$backup_dir\hosts.`$((Get-Date).ToString('yyyyMMddHHmmss')).bak"

Start-Transcript -Path "`$backup_dir\custom-hosts-entry.log" -Force

# Always remove old custom entries first for idempotency
`$content_clean = Get-Content `$hosts_file | Where-Object { `$_ -notmatch `$custom_comment -and `$_.Trim() -ne ''}

`$final_content = `$content_clean
if (-not [string]::IsNullOrWhiteSpace(`$entries_to_add)) {
    `$final_content += "``r``n``r``n"
    `$final_content += `$entries_to_add.Replace(',', "``r``n")
}

`$maxRetries = 3
`$retryDelaySeconds = 5
`$updateSuccess = `$false

for (`$i = 1; `$i -le `$maxRetries; `$i++) {
    Write-Output "Attempt `$i of `$maxRetries to update hosts file..."
    `$final_content | Set-Content `$hosts_file -Force

    `$current_content = Get-Content `$hosts_file -ErrorAction SilentlyContinue
    `$non_empty_lines = `$current_content | Where-Object { `$_.Trim() -ne '' }

    if (`$non_empty_lines.Count -gt 0) {
        Write-Output "Hosts file updated successfully."
        `$updateSuccess = `$true
        break
    }
    else {
        Write-Warning "Hosts file appears empty after update attempt `$i."
        if (`$i -lt `$maxRetries) {
            Write-Output "Waiting for `$retryDelaySeconds seconds before retrying..."
            Start-Sleep -Seconds `$retryDelaySeconds
        }
    }
}

if (-not `$updateSuccess) {
    Write-Error "Failed to update hosts file after `$maxRetries attempts."
    exit 1
}

exit 0
"@

$scriptParams = @{
    custom_comment = $customComment
    entries_to_add = $contenToAdd
}

Write-Output "`r`nScript to run on VMs:"
Write-Output $part1

$vms = Get-AzVM | Where-Object { $_.StorageProfile.OsDisk.OsType -match 'windows' -and $_.Name -match $filter_vm -and $_.ResourceGroupName -match $filter_rg_vm }
if (-not $vms) {
    Write-Output "No VMs found matching the criteria. Exiting."
    return
}
Write-Output "Found $($vms.Count) VMs to update. Starting parallel execution..."

$all_results = $vms | ForEach-Object -Parallel {
    $vm_thread = $_
    $script_thread = $using:part1
    $params_thread = $using:scriptParams
    try {
        $result = Invoke-AzVMRunCommand -ResourceGroupName $vm_thread.ResourceGroupName -Name $vm_thread.Name -CommandId 'RunPowerShellScript' -ScriptString $script_thread -Parameter $params_thread -ErrorAction Stop
        $outputMessage = ($result.Value | Select-Object -ExpandProperty Message) -join "`n"
        if ($outputMessage -notmatch 'Hosts file updated successfully.') {
            throw "Remote script execution failed on $($vm_thread.Name). Full output: $outputMessage"
        }
        Write-Host "Successfully updated hosts file on $($vm_thread.Name)."
        [PSCustomObject]@{ VMName = $vm_thread.Name; Succeeded = $true; Output = $outputMessage }
    }
    catch {
        $errorMessage = $_.Exception.ToString()
        Write-Error "An error occurred while processing VM $($vm_thread.Name): $errorMessage"
        [PSCustomObject]@{ VMName = $vm_thread.Name; Succeeded = $false; Output = $errorMessage }
    }
} -ThrottleLimit 5

# Success/failure reporting logic
Write-Output "------------------------------------"
Write-Output "Parallel execution complete. Verifying results:"
$failed_jobs = $all_results | Where-Object { -not $_.Succeeded }
$successful_jobs = $all_results | Where-Object { $_.Succeeded }

if ($successful_jobs) {
    Write-Output "`n--- SUCCESSFUL UPDATES ---"
    $successful_jobs | Sort-Object VMName | ForEach-Object { Write-Output "VM: $($_.VMName) | Status: Succeeded" }
}
if ($failed_jobs) {
    Write-Error "`n--- FAILED UPDATES ---"
    $failed_jobs | Sort-Object VMName | ForEach-Object { Write-Error "- VM: $($_.VMName), Status: Failed, Error: $($_.Output)" }
    throw "Failing runbook due to errors in one or more remote script executions."
}
Write-Output "`nAll bastion hosts files updated successfully."

