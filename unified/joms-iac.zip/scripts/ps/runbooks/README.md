# Client Tools Installation - Azure Automation Runbook
# location: scripts/ps/runbooks/update-client-tools.ps1

### Components
- **Mother Script**: Azure Automation Runbook (orchestration)
- **Remote Script**: PowerShell executed on target VMs
- **Security**: Managed Identity + Key Vault integration
- **Artifact Source**: JFrog Artifactory repository

## Supported Tools

| Tool | Version | Type | Purpose |
|------|---------|------|---------|
| Docker | 27.4.0 | Container Platform | Container management |
| Kubectl | 1.29.12 | Kubernetes CLI | Kubernetes administration |
| Helm | 3.15.4 | Package Manager | Kubernetes package management |
| Terraform | 1.9.8 | IaC Tool | Infrastructure as Code |
| JFrog CLI | 2.72.2 | Artifact Manager | Artifact repository management |
| Buildx | 0.19.2 | Docker Extension | Advanced Docker builds |
| Velero | 1.15.2 | Backup Tool | Kubernetes backup/restore |
| imgpkg | 0.44.0 | Image Packaging | Container image packaging |
| kbld | 0.45.1 | Image Builder | Kubernetes image building |
| kubelogin | 0.1.5 | Auth Plugin | Azure Kubernetes authentication |
| yq | 4.45.1 | YAML Processor | YAML/JSON manipulation |


### Required Permissions
- **Managed Identity**: 
  - `Virtual Machine Contributor` or `Virtual Machine Command Executor` on target VMs
  - `Key Vault Secrets User` on Key Vault
- **Key Vault Access**: Get permissions on secrets

## Configuration Variables

### Azure Automation Variables

| Variable Name | Type | Description | Example |
|---------------|------|-------------|---------|
| `ToolsToHandleJson` | String | JSON configuration of tools | See Tools Configuration |

### Key Vault Secrets

| Secret Name | Description | Example |
|-------------|-------------|---------|
| `artifactoryUser` | Artifactory username | `"automation-user"` |
| `artifactorySecret` | Artifactory password/token | `"secure-token-123"` |
| `DevopsAlertUrl` | Alert Teams HTTP connector webhook endpoint | `"https://alaskanorthstarresourcesllc.webhook.office.com/webhook/<etc>"` |

### Tools Configuration JSON

```json
{
  "docker": {
    "ArtifactFile": "docker-27.4.0.exe",
    "LocalFileName": "docker.exe",
    "CheckCommand": "docker version"
  },
  "kubectl": {
    "ArtifactFile": "kubectl-1.29.12.exe",
    "LocalFileName": "kubectl.exe",
    "CheckCommand": "kubectl version --client"
  },
  "terraform-bundle": {
    "ArtifactFile": "terraform-bundle-1.9.8.zip",
    "LocalFileName": "terraform.exe",
    "CheckCommand": "terraform version"
  },
  "helm": {
    "ArtifactFile": "helm-3.15.4.exe",
    "LocalFileName": "helm.exe",
    "CheckCommand": "helm version"
  },
  "jf": {
    "ArtifactFile": "jf-2.72.2.exe",
    "LocalFileName": "jf.exe",
    "CheckCommand": "jf -v"
  },
  "buildx": {
    "ArtifactFile": "buildx-0.19.2.exe",
    "LocalFileName": "buildx.exe",
    "CheckCommand": "buildx version"
  },
  "velero": {
    "ArtifactFile": "velero-1.15.2.exe",
    "LocalFileName": "velero.exe",
    "CheckCommand": "velero version"
  },
  "imgpkg": {
    "ArtifactFile": "imgpkg-0.44.0.exe",
    "LocalFileName": "imgpkg.exe",
    "CheckCommand": "imgpkg version"
  },
  "kbld": {
    "ArtifactFile": "kbld-0.45.1.exe",
    "LocalFileName": "kbld.exe",
    "CheckCommand": "kbld version"
  },
  "kubelogin": {
    "ArtifactFile": "kubelogin-0.1.5.exe",
    "LocalFileName": "kubelogin.exe",
    "CheckCommand": "kubelogin --version"
  },
  "yq": {
    "ArtifactFile": "yq-4.45.1.exe",
    "LocalFileName": "yq.exe",
    "CheckCommand": "yq --version"
  }
}
```

## Usage

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `Stage` | String | No | `"dev"` | Environment (dev/test/prod) |
| `VMPattern` | String | No | `"BST"` | VM name pattern filter |
| `ResourceGroupPattern` | String | No | `"APP-RGP-01"` | Resource group pattern filter |

### Execution Examples

```powershell
# Install tools on dev environment BST VMs
.\client-tools-final.ps1 -Stage "dev" -VMPattern "BST" -ResourceGroupPattern "APP-RGP-01"

# Install tools on production environment
.\client-tools-final.ps1 -Stage "prod" -VMPattern "PROD" -ResourceGroupPattern "PROD-RG"

# Install on specific VM pattern
.\client-tools-final.ps1 -VMPattern "DEV-VM-*"
```

## Expected Outcomes

### Successful Execution

```
=== Client Tools Installation Runbook ===
Environment: dev | VM Pattern: BST | Resource Group Pattern: APP-RGP-01
Connected as MSI@50342 to subscription AZ-DOD-AF-CCE-AFMC-D-IL5-JOMSMVP-01
Loaded configuration for 11 tools
Found 2 VMs for processing

Processing VM: BST1JOMSMVPDDE (14:30:15)
✅ SUCCESS: BST1JOMSMVPDDE - All tools installed

Processing VM: BST2JOMSMVPDDE (14:32:20)
✅ SUCCESS: BST2JOMSMVPDDE - All tools already present

=== FINAL RESULTS ===
Successful VMs: 2
Failed VMs: 0
Total execution time: 4.25 minutes
🎉 ALL VMs COMPLETED SUCCESSFULLY
```

### Partial Failure Example

```
Processing VM: BST1JOMSMVPDDE (14:30:15)
❌ FAILED: BST1JOMSMVPDDE - Failed tools: docker, kubectl

Processing VM: BST2JOMSMVPDDE (14:32:20)
✅ SUCCESS: BST2JOMSMVPDDE - All tools installed

=== FINAL RESULTS ===
Successful VMs: 1
Failed VMs: 1
Total execution time: 6.12 minutes
⚠️ SOME VMs FAILED
```

### Remote VM Output (Success)

```
=== Client Tools Installation on BST1JOMSMVPDDE ===
Processing 11 tools
OK: docker
MISSING: kubectl
MISSING: helm
Installing 2 tools...
DOWNLOADED: kubectl
SUCCESS: kubectl
DOWNLOADED: helm
SUCCESS: helm
=== ALL TOOLS INSTALLED AND VERIFIED ===
FinalFailedTools: []
```

### Remote VM Output (Partial Failure)

```
=== Client Tools Installation on BST1JOMSMVPDDE ===
Processing 11 tools
Installing 3 tools...
ERROR: docker - The remote server returned an error: (404) Not Found
SUCCESS: kubectl
SUCCESS: helm
=== SOME TOOLS FAILED: docker ===
FinalFailedTools: docker
```

## Installation Process

1. **Environment Setup**
   - Connects to Azure using Managed Identity
   - Retrieves configuration from Automation Variables
   - Loads tool definitions from JSON configuration

2. **VM Discovery**
   - Finds Windows VMs matching name and resource group patterns
   - Validates VM accessibility and state

3. **Credential Management**
   - Retrieves Artifactory credentials from Key Vault
   - Sets up secure authentication for artifact downloads

4. **Tool Installation per VM**
   - Checks existing tool installations
   - Downloads missing tools from Artifactory
   - Installs tools to `C:\Users\Public\Public Software`
   - Updates system PATH environment variable
   - Verifies installation success

5. **Reporting**
   - Provides detailed logs for each VM
   - Reports success/failure status
   - Generates execution summary

## File Locations

### On Target VMs
- **Installation Directory**: `C:\Users\Public\Public Software`
- **Temporary Downloads**: `%TEMP%\ClientToolDownloads`
- **PATH Addition**: Tools directory added to system PATH

### Artifactory Structure
```
{ArtifactoryRepo}/
├── {ArtifactoryBasePath}/
│   ├── docker-27.4.0.exe
│   ├── kubectl-1.29.12.exe
│   ├── helm-3.15.4.exe
│   ├── terraform-bundle-1.9.8.zip
│   └── ...other tools
```

## Troubleshooting

### Common Issues

| Issue | Cause | Solution |
|-------|-------|----------|
| "No matching VMs found" | VM/RG pattern mismatch | Verify pattern parameters |
| "Failed to retrieve secrets" | Key Vault permissions | Check Managed Identity permissions |
| "The remote server returned an error: (404)" | Missing artifact | Verify artifact exists in repository |
| "Cannot process argument transformation" | Parameter serialization | Check JSON formatting |

### Log Analysis

Look for these key indicators in logs:
- ✅ **SUCCESS**: Tool installed and verified
- ❌ **FAILED**: Tool installation failed
- ⚠️ **UNKNOWN**: Could not determine status
- **FinalFailedTools: []**: All tools successful
- **FinalFailedTools: tool1, tool2**: Specific failures

### Manual Verification

On target VMs, verify installation:
```powershell
# Check tool versions
docker version
kubectl version --client
helm version
terraform version

# Verify PATH
$env:PATH -split ';' | Where-Object { $_ -like "*Public Software*" }

# Check installed files
Get-ChildItem "C:\Users\Public\Public Software"
```

## Security Considerations

- Credentials are retrieved from Key Vault at runtime
- No hardcoded passwords or tokens in scripts
- Managed Identity provides secure Azure authentication
- Temporary files are cleaned up after installation
- Network traffic to Artifactory uses HTTPS with authentication


### Environment Management
- **Dev**: `https://artifact.dev.azure.cce.af.mil`
- **Test**: `https://artifact.test.azure.cce.af.mil`
- **Prod**: `https://artifact.prod.azure.cce.af.mil`