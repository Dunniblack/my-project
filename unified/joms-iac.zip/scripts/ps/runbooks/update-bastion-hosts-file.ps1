# This script updates the Hosts file on the Bastions with the FQDN for all private DNS zones and AKS private clusters.

param (
    [Parameter(Mandatory = $false)]
    [ValidateSet("wdsf", "c1", "thundercamp")]
    [string]$enclave = "c1",
    [Parameter(Mandatory = $false)]
    [ValidateSet("BST", "TFA")]
    [string]$filter_vm = "BST",
    [Parameter(Mandatory = $false)]
    [string]$filter_rg_vm = "APP-RGP-01"
)

if ($enclave -eq "c1") {
    Write-Output "Logging into Azure using AAA Managed Identity..."

    try {
        "Logging in to Azure..."
        Connect-AzAccount -Identity -EnvironmentName "AzureUSGovernment"
    }
    catch {
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

$global:entries = "`r`n# Private endpoints - BEGIN`r`n"
# Prepare entries to add to hosts file ######################
function Get-HostsFileLines {

    ## Enumerates DNS records from the Private DNS zones. This would include all Private Endpoints, except for AKS cluster.
    $zones = Get-AzPrivateDnsZone

    foreach ($zone in $zones) {
        $zoneIncluded = $false
        Write-Output "Checking Private DNS Zone: $($zone.Name), RGP:$($zone.ResourceGroupName)"
        if ($zone.Name -match 'privatelink.') {
            Write-Output "PrivateLink: $($zone.Name)"
            $records = Get-AzPrivateDnsRecordSet -ResourceGroupName $zone.ResourceGroupName -ZoneName $zone.Name -RecordType A

            foreach ($record in $records) {
                $ip = $record.Records.Ipv4Address
                $fqdn1 = $record.Name + "." + $record.ZoneName
                $fqdn2 = ($record.Name + "." + $record.ZoneName).Replace(".privatelink.", ".")

                $fqdn2 = $fqdn2.Replace("vaultcore.azure.net", "vault.usgovcloudapi.net")

                Write-Output "A Record: $fqdn1 $($record.Records.Ipv4Address)"
                Write-Output "A Record: $fqdn2 $($record.Records.Ipv4Address)"

                $entry = "$ip`t$fqdn1`t$fqdn2`t# Private DNS Zone"
                $global:entries += "$entry`r`n"
            }
            $zoneIncluded = $true
        }
        if ( -not $zoneIncluded -and $zone.Name -match 'private.mysql.') {
            Write-Output "MySQL Private IP: $($zone.Name)"
            $records = Get-AzPrivateDnsRecordSet -ResourceGroupName $zone.ResourceGroupName -ZoneName $zone.Name -RecordType A

            foreach ($record in $records) {
                $ip = $record.Records.Ipv4Address
                $fqdn1 = $record.Name + "." + $record.ZoneName
                $fqdn2 = ($record.Name + "." + $record.ZoneName).Replace(".private.", ".")

                Write-Output "A Record: $fqdn1 $($record.Records.Ipv4Address)"
                Write-Output "A Record: $fqdn2 $($record.Records.Ipv4Address)"

                $entry = "$ip`t$fqdn1`t$fqdn2`t# Private DNS Zone"
                $global:entries += "$entry`r`n"
            }
            $zoneIncluded = $true
        }

        $isHostsFileZone = $false
        if ( -not $zoneIncluded ) {
            $tagValue = $zone.Tags["HOSTSFILE"]
            if ("${tagValue}" -ne "") {
                Write-Output "Tag: HOSTSFILE=${tagValue}"
                $isHostsFileZone = $true
            }
        }
        if ($isHostsFileZone -and $zone.Name -notmatch 'privatelink.') {
            Write-Output "Tagged Private DNS Zone: $($zone.Name)"
            # Zone is tagged "HOSTSFILE" but is NOT a privatelink zone
            $records = Get-AzPrivateDnsRecordSet -ResourceGroupName $zone.ResourceGroupName -ZoneName $zone.Name -RecordType A

            foreach ($record in $records) {
                $ip = $record.Records.Ipv4Address
                $fqdn1 = $record.Name + "." + $record.ZoneName

                Write-Output "A Record: $fqdn1 $($record.Records.Ipv4Address)"

                $entry = "$ip`t$fqdn1`t# Private DNS Zone"
                $global:entries += "$entry`r`n"
            }
        }
    }

    Write-Output "Get Private Endpoints of AKS clusters"
    $aks_clusters = Get-AzAksCluster

    foreach ($aks_cluster in $aks_clusters) {
        $aks_pep = Get-AzPrivateEndpoint | Where-Object { $_.PrivateLinkServiceConnections[0].PrivateLinkServiceId -like "*$($aks_cluster.Name)*" }
        if ($aks_pep) {
            $aks_nic = Get-AzNetworkInterface -ResourceId $aks_pep.NetworkInterfaces[0].Id
            $aks_ip = $aks_nic.IpConfigurations[0].PrivateIpAddress
            $aks_fqdn1 = $aks_cluster.PrivateFQDN
            $aks_fqdn2 = $aks_cluster.AzurePortalFQDN

            Write-Output "A Record: $aks_fqdn1 $aks_ip"
            Write-Output "A Record: $aks_fqdn2d $aks_ip"

            $aks_entry = "$aks_ip`t$aks_fqdn1`t$aks_fqdn2`t# AKS Private IP"
            $global:entries += "$aks_entry`r`n"
        }
    }
}

Get-HostsFileLines
$content_to_add = $global:entries
Write-Output "`r`nContent to be added to hosts file:"
$content_to_add

# Prepare script to run on VMs ##############################
$part1 = @'
$hosts_file = "$env:windir\System32\drivers\etc\hosts"
$backup_dir = "C:\temp\hosts_backup\"

if (!(Test-Path $backup_dir)) { New-Item -ItemType Directory -Path $backup_dir -Force }

# Backup hosts file
Copy-Item $hosts_file "$backup_dir\hosts.$((Get-Date).ToString('yyyyMMddHHmmss')).bak"

Try {
    Start-Transcript -Path "`$backup_dir\update-bastion-hosts-file.log" -Force
} Catch {}

#Write-Output "---------------------------------------"
#Write-Output "Original content before clean:"
#Get-Content $hosts_file

# Remove empty lines and existing entries matching "privatelink.", "Private endpoints", or "gvdtic" in hosts file
# Also remove any lines flagged with end-of-line-comments for Private DNS Zone and AKS Privte IP
$content_clean = Get-Content $hosts_file | Where-Object { $_ -notmatch 'privatelink.|Private endpoints|gvdtic|Private DNS Zone|AKS Private IP' -and $_.Trim() -ne '' }

#Write-Output "---------------------------------------"
#Write-Output "Remaining content after clean:"
#$content_clean

$entries = @'

'@

$part2 = "`r`n'@"

$part3 = @'

$maxRetries = 3
$retryDelaySeconds = 5
$updateSuccess = $false

for ($i = 1; $i -le $maxRetries; $i++) {
    Write-Output "Attempt $i of $maxRetries to update hosts file..."

    $content_clean + $entries | Set-Content $hosts_file -Force

    # Verification step: Check if the file has meaningful content
    $current_content = Get-Content $hosts_file -ErrorAction SilentlyContinue
    $non_empty_lines = $current_content | Where-Object { $_.Trim() -ne '' }

    if ($non_empty_lines.Count -gt 0) {
        Write-Output "Hosts file updated successfully."
        $updateSuccess = $true
        break # Exit the loop on success
    }
    else {
        Write-Warning "Hosts file appears empty after update attempt $i."
        if ($i -lt $maxRetries) {
            Write-Output "Waiting for $retryDelaySeconds seconds before retrying..."
            Start-Sleep -Seconds $retryDelaySeconds
        }
    }
}

if (-not $updateSuccess) {
    Write-Error "Failed to update hosts file after $maxRetries attempts. The file remains empty."
    # Exit with a non-zero code to indicate failure to the calling process
    exit 1
}
exit 0
'@

$script = $part1 + $content_to_add + $part2 + $part3
Write-Output "`r`nScript to run on VMs:"
Write-Output $script

if ($enclave -eq "c1") {
    $vms = Get-AzVM | Where-Object { $_.StorageProfile.OsDisk.OsType -match 'windows' -and $_.Name -match $filter_vm -and $_.ResourceGroupName -match $filter_rg_vm }
    if (-not $vms) {
        Write-Output "No VMs found matching the criteria. Exiting."
        return
    }
    Write-Output "Found $($vms.Count) VMs to update. Starting parallel execution..."

    $all_results = $vms | ForEach-Object -Parallel {
        $vm_thread = $_
        $script_thread = $using:script
        # $threadId = [System.Threading.Thread]::CurrentThread.ManagedThreadId
        # Write-Host "[Thread ID: $threadId] Starting hosts file update on $($vm_thread.Name)..."
        try {
            $result = Invoke-AzVMRunCommand -ResourceGroupName $vm_thread.ResourceGroupName -Name $vm_thread.Name -CommandId 'RunPowerShellScript' -ScriptString $script_thread -ErrorAction Stop
            $outputMessage = ($result.Value | Select-Object -ExpandProperty Message) -join "`n"
            if ($outputMessage -notmatch 'Hosts file updated successfully.') {
                throw "Remote script execution failed on $($vm_thread.Name). Full output: $outputMessage"
            }
            # Write-Host "[Thread ID: $threadId] Successfully updated hosts file on $($vm_thread.Name)."
            [PSCustomObject]@{
                VMName    = $vm_thread.Name
                Succeeded = $true
                Output    = $outputMessage
            }
        }
        catch {
            $errorMessage = $_.Exception.ToString()
            # Write-Error "[Thread ID: $threadId] An error occurred while processing VM $($vm_thread.Name): $errorMessage"
            [PSCustomObject]@{
                VMName    = $vm_thread.Name
                Succeeded = $false
                Output    = $errorMessage
            }
        }
    } -ThrottleLimit 5

    Write-Output "------------------------------------"
    Write-Output "Parallel execution complete. Verifying results:"
    $failed_jobs = $all_results | Where-Object { -not $_.Succeeded }
    $successful_jobs = $all_results | Where-Object { $_.Succeeded }

    if ($successful_jobs) {
        Write-Output "`n--- SUCCESSFUL UPDATES ---"
        $successful_jobs | Sort-Object VMName | ForEach-Object { Write-Output "VM: $($_.VMName) | Status: Succeeded" }
    }
    if ($failed_jobs) {
        Write-Error "`n--- FAILED UPDATES ---"
        $failed_jobs | Sort-Object VMName | ForEach-Object { Write-Error "- VM: $($_.VMName), Status: Failed, Error: $($_.Output)" }
        throw "Failing runbook due to errors in one or more remote script executions."
    }
    Write-Output "`nAll bastion hosts files updated successfully."
}
else {
    Write-Output "Start running script on local machine"
    Invoke-Expression -Command $script
}