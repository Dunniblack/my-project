[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [ValidateSet("dev", "test", "prod")]
    [string]$stage = "dev",

    [Parameter(Mandatory = $false)]
    [string]$keyvaultname = "DEJOMSMVP$($stage[0])IL5KVT".ToUpper(),

    [Parameter(Mandatory = $false)]
    [string]$resourcegroupname  = "AZ-GV-DOD-AF-CCE-AFMC-$($stage[0])-IL5-JOMS-Global-RGP-01".ToUpper(),

    [Parameter(Mandatory = $false)]
    [string]$bastionvmpattern = "BST",

    [Parameter(Mandatory = $false)]
    [string]$bastionresourcegrouppattern = "APP-RGP-01",

    [Parameter(Mandatory = $false)]
    [string]$adopatsecretname = "git-credentials",

    [Parameter(Mandatory = $false)]
    [string]$poolnamepattern = "AFMC-JOMSMVP*"
)

# ------------------------------------------------------------------
# Setup
# ------------------------------------------------------------------
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$CurrentDateStr = Get-Date -Format "yyyyMMdd-HHmm"

Write-Output "=========================================="
Write-Output "ADO Agent Pool Monitor"
Write-Output "stage          : $stage"
Write-Output "KeyVault       : $keyvaultname"
Write-Output "Pool Pattern   : $poolnamepattern"
Write-Output "=========================================="

# ------------------------------------------------------------------
# 1. Authenticate via Managed Identity
# ------------------------------------------------------------------
Write-Output "`nConnecting to Azure via Managed Identity..."
try {
    Connect-AzAccount -Identity -EnvironmentName "AzureUSGovernment" | Out-Null
    $context = Get-AzContext
    Write-Output "Authenticated as $($context.Account.Id)."
}
catch {
    Write-Error "FATAL: Managed Identity authentication failed: $_"
    throw
}

# ------------------------------------------------------------------
# 2. Retrieve ADO PAT from Key Vault
# ------------------------------------------------------------------
Write-Output "`nRetrieving secret '$adopatsecretname' from Key Vault '$keyvaultname'..."
try {
    $gitCredentialJson = Get-AzKeyVaultSecret -VaultName $keyvaultname -Name $adopatsecretname -AsPlainText

    if (-not $gitCredentialJson) {
        throw "Secret '$adopatsecretname' not found or is empty."
    }

    $credentialObject = $gitCredentialJson | ConvertFrom-Json
    $adoPat = $credentialObject.password

    if (-not $adoPat) {
        throw "The 'password' property was not found in the '$adopatsecretname' secret."
    }

    Write-Output "Successfully retrieved ADO PAT from Key Vault."
}
catch {
    Write-Error "FATAL: Failed to retrieve ADO PAT: $_"
    throw
}

# ------------------------------------------------------------------
# 2b. Retrieve Teams webhook URL from Key Vault
# ------------------------------------------------------------------
$webhookSecretName = "DevopsAlertUrl"
Write-Output "`nRetrieving secret '$webhookSecretName' from Key Vault '$keyvaultname'..."
try {
    $TeamsWebhookUrl = Get-AzKeyVaultSecret -VaultName $keyvaultname -Name $webhookSecretName -AsPlainText

    if (-not $TeamsWebhookUrl -or $TeamsWebhookUrl -notmatch "^https://") {
        throw "Secret '$webhookSecretName' not found, empty, or invalid URL."
    }

    Write-Output "Successfully retrieved Teams webhook URL from Key Vault."
}
catch {
    Write-Error "FATAL: Failed to retrieve Teams webhook URL: $_"
    throw
}

# ------------------------------------------------------------------
# Helper Function: Send Alert to Teams
# ------------------------------------------------------------------
function Send-TeamsAlert {
    param(
        [string]$stage,
        [string]$MonitoredAt,
        [int]$TotalFindings,
        [array]$Findings
    )

    try {
        Write-Output "Sending alert to Teams..."

        if (-not $TeamsWebhookUrl) {
            throw "Teams webhook URL is empty"
        }

        # Build findings text
        $findingsText = ""
        if ($Findings.Count -gt 0) {
            $findingsText = "Offline Agents:`n"
            foreach ($finding in $Findings) {
                $findingsText += "- Pool: $($finding.PoolName), Agent: $($finding.AgentName), Status: $($finding.Status)`n"
            }
        }

        # MessageCard payload
        $alertPayload = @{
            "@type" = "MessageCard"
            "@context" = "http://schema.org/extensions"
            "themeColor" = "0076D7"
            "summary" = "ADO Agent Alert"
            "sections" = @(
                @{
                    "activityTitle" = "ADO Agent Alert"
                    "activitySubtitle" = "stage: $stage"
                    "facts" = @(
                        @{
                            "name" = "Monitored At"
                            "value" = "$MonitoredAt"
                        },
                        @{
                            "name" = "Total Offline Agents"
                            "value" = "$TotalFindings"
                        }
                    )
                    "text" = $findingsText
                }
            )
        } | ConvertTo-Json -Depth 10

        Invoke-RestMethod `
            -Uri $TeamsWebhookUrl `
            -Method POST `
            -Body $alertPayload `
            -ContentType "application/json"

        Write-Output "Alert sent successfully to Teams"
        return $true
    }
    catch {
        Write-Error "Failed to send alert to Teams: $($_.Exception.Message)"
        return $false
    }
}

# ------------------------------------------------------------------
# 3. Find a running Windows bastion VM
# ------------------------------------------------------------------
Write-Output "`nFinding an available bastion VM..."
$selectedVM = $null
try {
    $bastionVMs = @(Get-AzVM | Where-Object {
        $_.StorageProfile.OsDisk.OsType -eq 'Windows' -and
        $_.Name -match $bastionvmpattern -and
        $_.ResourceGroupName -match $bastionresourcegrouppattern
    })

    if ($bastionVMs.Count -eq 0) {
        throw "No VMs found matching patterns (Name: '$bastionvmpattern', RG: '$bastionresourcegrouppattern')."
    }

    foreach ($vm in $bastionVMs) {
        $vmStatus = Get-AzVM -ResourceGroupName $vm.ResourceGroupName -Name $vm.Name -Status
        $powerState = ($vmStatus.Statuses | Where-Object { $_.Code -like "PowerState/*" }).DisplayStatus
        if ($powerState -eq "VM running") {
            $selectedVM = $vm
            break
        }
    }

    if (-not $selectedVM) {
        throw "No running bastion VMs found from the candidate list."
    }

    Write-Output "Selected running VM: $($selectedVM.Name) (RG: $($selectedVM.ResourceGroupName))"
}
catch {
    Write-Error "FATAL: Could not find a bastion host: $_"
    throw
}
# ------------------------------------------------------------------
# 4. Define the remote script (runs on the bastion VM)
#    This script queries the ADO REST API and returns structured output.
#    Note: Common-Utilities.ps1 is NOT available on the bastion VM,
#    so this script uses Invoke-RestMethod (a PS cmdlet) directly.
# ------------------------------------------------------------------
$remoteScript = @'
[CmdletBinding()]
param(
    [string]$adoPat,
    [string]$stage,
    [string]$poolnamepattern
)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

Write-Host "=== ADO Agent Monitor - Executing on $env:COMPUTERNAME ==="

$findings = [System.Collections.Generic.List[hashtable]]::new()

try {
    $tfsServer = "tfs.$($stage).azure.cce.af.mil"
    $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($adoPat)"))
    $headers = @{
        Authorization  = "Basic $base64AuthInfo"
        'Content-Type' = 'application/json'
    }

    $poolsUri = "https://$($tfsServer)/DefaultCollection/_apis/distributedtask/pools?api-version=7.1"
    Write-Host "Querying agent pools from $poolsUri"
    $poolsResponse = Invoke-RestMethod -Uri $poolsUri -Method Get -Headers $headers -TimeoutSec 30

    if (-not $poolsResponse.value) {
        Write-Host "No agent pools found."
        Write-Output "RESULT_JSON:[]"
        exit 0
    }

    foreach ($pool in $poolsResponse.value) {
        if ($pool.name -notlike $poolnamepattern) {
            Write-Host "--- Skipping Pool: '$($pool.name)' (does not match '$poolnamepattern') ---"
            continue
        }

        $poolId   = $pool.id
        $poolName = $pool.name
        Write-Host "--- Checking Pool: '$poolName' (ID: $poolId) ---"

        $agentsUri = "https://$($tfsServer)/DefaultCollection/_apis/distributedtask/pools/$($poolId)/agents?includeCapabilities=false&api-version=7.0"
        $agentsResponse = Invoke-RestMethod -Uri $agentsUri -Method Get -Headers $headers -TimeoutSec 30

        if (-not $agentsResponse.value) {
            Write-Host "  No agents in pool '$poolName'."
            continue
        }

        $totalAgents   = @($agentsResponse.value).Count
        $enabledAgents = @($agentsResponse.value | Where-Object { $_.enabled -eq $true })
        $offlineAgents = @($enabledAgents | Where-Object { $_.status -eq "offline" })
        $onlineAgents  = @($enabledAgents | Where-Object { $_.status -eq "online" })

        Write-Host "  Total: $totalAgents | Enabled: $($enabledAgents.Count) | Online: $($onlineAgents.Count) | Offline: $($offlineAgents.Count)"

        if ($offlineAgents.Count -gt 0) {
            foreach ($agent in $offlineAgents) {
                $findings.Add(@{
                    PoolName      = $poolName
                    PoolId        = $poolId
                    AgentName     = $agent.name
                    AgentId       = $agent.id
                    Status        = "OFFLINE"
                    Enabled       = $true
                    OSDescription = if ($agent.osDescription) { $agent.osDescription } else { "Unknown" }
                })
                Write-Host "  [!!] OFFLINE: $($agent.name)"
            }
        }
        else {
            Write-Host "  All enabled agents online."
        }
    }

    # Serialize findings as JSON and output with a marker prefix
    $json = $findings | ConvertTo-Json -Depth 5 -Compress
    if ($findings.Count -eq 0) { $json = "[]" }
    Write-Output "RESULT_JSON:$json"
}
catch {
    Write-Host "An error occurred: $($_.Exception.Message)"
    Write-Output "SCRIPT_ERROR:$($_.Exception.Message)"
    exit 1
}
'@

# ------------------------------------------------------------------
# 5. Execute remote script on the bastion VM
# ------------------------------------------------------------------
Write-Output "`nExecuting monitoring script on VM '$($selectedVM.Name)'..."
$scriptParams = @{
    adoPat          = $adoPat
    stage           = $stage
    PoolNamePattern = $poolnamepattern
}

try {
    $result = Invoke-AzVMRunCommand `
        -ResourceGroupName $selectedVM.ResourceGroupName `
        -Name $selectedVM.Name `
        -CommandId 'RunPowerShellScript' `
        -ScriptString $remoteScript `
        -Parameter $scriptParams

    $output = $result.Value[0].Message
    Write-Output "--- Remote Script Output ---"
    Write-Output $output
    Write-Output "----------------------------"
}
catch {
    Write-Error "FATAL: Remote script execution failed: $_"
    throw
}

# ------------------------------------------------------------------
# 6. Parse results and upload report if offline agents found
# ------------------------------------------------------------------
$Findings = @()

if ($output -match "RESULT_JSON:(.+)") {
    $jsonPayload = $matches[1].Trim()
    $Findings = @(ConvertFrom-Json -InputObject $jsonPayload)
}
elseif ($output -match "SCRIPT_ERROR:(.+)") {
    $scriptError = $matches[1].Trim()
    # Treat the script error itself as a finding so it gets reported
    $Findings = @([PSCustomObject]@{
        PoolName      = "N/A"
        PoolId        = 0
        AgentName     = "N/A"
        AgentId       = 0
        Status        = "MONITOR_ERROR"
        Enabled       = $false
        OSDescription = "N/A"
        ErrorMessage  = $scriptError
    })
    Write-Warning "Remote script returned an error: $scriptError"
}
else {
    Write-Error "Unexpected output from remote script. No findings to process."
    throw
}

# ------------------------------------------------------------------
# 7. Send alert to Teams (only if there are findings)
# ------------------------------------------------------------------
if ($Findings.Count -gt 0) {
    Write-Output "`nOffline agent(s) detected! Sending alert to Teams..."

    $monitoredAt = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")

    $alertSent = Send-TeamsAlert -stage $stage -MonitoredAt $monitoredAt -TotalFindings $Findings.Count -Findings $Findings

    if ($alertSent) {
        Write-Output "Alert sent successfully."
    } else {
        Write-Error "Failed to send alert."
        throw
    }
}
else {
    Write-Output "`nAll monitored agents are online. No alert to send."
}

# ------------------------------------------------------------------
# 8. Summary
# ------------------------------------------------------------------
Write-Output "`n=========================================="
Write-Output "ADO Agent Pool Monitor Complete"
Write-Output "stage           : $stage"
Write-Output "Bastion VM used : $($selectedVM.Name)"
Write-Output "Findings        : $($Findings.Count)"
Write-Output "=========================================="
