[CmdletBinding()]
param (
    [Parameter(Mandatory = $false)]
    [ValidateSet("dev", "test", "prod")]
    [string]$Stage = "dev",
    [Parameter(Mandatory = $false)]
    [bool]$UpdateClientTools = $true,
    [Parameter(Mandatory = $false)]
    [string]$VMPattern = "BST",
    [Parameter(Mandatory = $false)]
    [string]$ResourceGroupPattern = "APP-RGP-01",
    [Parameter(Mandatory = $false)]
    [string]$KeyVaultName = "DEJOMSMVP$($Stage[0])IL5KVT".ToUpper(),
    [Parameter(Mandatory = $false)]
    [string]$ArtifactoryBasePath = "IaC/software/win-amd64/",
    [Parameter(Mandatory = $false)]
    [string]$ArtifactoryRepo = "AFMC-JOMSMVP-$Stage".ToUpper()
)

#region Configuration and Setup
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Write-Output "=== Client Tools Installation Runbook ==="
Write-Output "Environment: $Stage | Update Client Tools: $UpdateClientTools | VM Pattern: $VMPattern | Resource Group Pattern: $ResourceGroupPattern"

try {
    Connect-AzAccount -Identity -EnvironmentName "AzureUSGovernment"
    $context = Get-AzContext
    Write-Output "Connected as $($context.Account.Id) to subscription $($context.Subscription.Name)"
}
catch {
    Write-Error "Failed to connect to Azure: $_"
    throw
}

try {
    $config = @{
        KeyVaultName        = $KeyVaultName
        ToolsToHandleJson   = Get-AutomationVariable -Name "ToolsToHandleJson"
        ArtifactoryBasePath = $ArtifactoryBasePath
        ArtifactoryRepo     = $ArtifactoryRepo
        ArtifactoryBaseUrl  = "https://artifact.$Stage.azure.cce.af.mil"
    }
}
catch {
    Write-Error "Failed to retrieve configuration: $_"
    throw
}

$toolsToHandle = $config.ToolsToHandleJson | ConvertFrom-Json -AsHashtable
Write-Output "Loaded configuration for $(@($toolsToHandle.Keys).Count) tools"
#endregion

#region Remote Script
$remoteScript = @'
[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$ArtifactoryBaseUrl,
    [Parameter(Mandatory = $true)]
    [string]$ArtifactoryRepo,
    [Parameter(Mandatory = $true)]
    [string]$ArtifactoryBasePath,
    [Parameter(Mandatory = $true)]
    [string]$ToolsToHandle,
    [Parameter(Mandatory = $true)]
    [int]$UpdateClientTools,
    [Parameter(Mandatory = $true)]
    [string]$ArtifactoryUsername,
    [Parameter(Mandatory = $true)]
    [string]$ArtifactoryPassword
)

$PublicSoftwareDir = "C:\Users\Public\Public Software"
$TempDownloadDir = [System.IO.Path]::GetTempPath() + "ClientToolDownloads"
$BackupDir = "C:\temp\update_client_tools\"

if (!(Test-Path $BackupDir)) { New-Item -ItemType Directory -Path $BackupDir -Force }
Start-Transcript -Path "$BackupDir\update-client-tools.log" -Force

Write-Host "=== Client Tools Installation on $env:COMPUTERNAME ==="

# Parse tools configuration
try {
    $tools = @(($ToolsToHandle | ConvertFrom-Json).PSObject.Properties | ForEach-Object {
        @{
            Name = $_.Name
            ArtifactFile = $_.Value.ArtifactFile
            LocalFileName = $_.Value.LocalFileName
            CheckCommand = $_.Value.CheckCommand
        }
    })
    Write-Host "Processing $(@($tools).Count) tools"
} catch {
    Write-Error "Tool parsing failed: $_"
    Write-Output "FinalFailedTools: All tools"
    exit 1
}

# Test if tool is working
function Test-Tool($tool) {
    try {
        $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";$PublicSoftwareDir"
        $cmd = $tool.CheckCommand.Split(' ')[0]
        if (Get-Command $cmd -ErrorAction SilentlyContinue) {
            $null = Invoke-Expression $tool.CheckCommand 2>$null
            return ($LASTEXITCODE -eq 0)
        }
        return $false
    } catch { return $false }
}

# Install tool
function Install-Tool($tool) {
    $finalPath = Join-Path $PublicSoftwareDir $tool.LocalFileName

    try {
        # Setup authentication
        $auth = [Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes("${ArtifactoryUsername}:${ArtifactoryPassword}"))
        $headers = @{ Authorization = "Basic $auth" }

        # Ensure directory exists and remove existing file
        $destDir = Split-Path $finalPath -Parent
        if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
        if (Test-Path $finalPath) { Remove-Item $finalPath -Force }

        $url = "$ArtifactoryBaseUrl/artifactory/$ArtifactoryRepo/$ArtifactoryBasePath$($tool.ArtifactFile)"

        if ($tool.ArtifactFile.EndsWith('.zip')) {
            # Handle ZIP files with .NET extraction
            $tempZip = Join-Path $TempDownloadDir $tool.ArtifactFile
            if (-not (Test-Path $TempDownloadDir)) { New-Item -ItemType Directory -Path $TempDownloadDir -Force | Out-Null }

            Invoke-WebRequest -Uri $url -OutFile $tempZip -Headers $headers -UseBasicParsing -TimeoutSec 60

            Add-Type -AssemblyName System.IO.Compression.FileSystem
            $zip = [System.IO.Compression.ZipFile]::OpenRead($tempZip)

            try {
                $entry = $zip.Entries | Where-Object { $_.Name -eq $tool.LocalFileName -or $_.Name -ieq $tool.LocalFileName } | Select-Object -First 1
                if ($entry) {
                    [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $finalPath, $true)
                    Write-Host "EXTRACTED: $($tool.Name)"
                } else {
                    throw "File $($tool.LocalFileName) not found in ZIP"
                }
            } finally {
                $zip.Dispose()
                Remove-Item $tempZip -Force -ErrorAction SilentlyContinue
            }
        } else {
            # Handle direct file downloads
            Invoke-WebRequest -Uri $url -OutFile $finalPath -Headers $headers -UseBasicParsing -TimeoutSec 60
            Write-Host "DOWNLOADED: $($tool.Name)"
        }

        # Verify installation
        if ((Test-Path $finalPath) -and ((Get-Item $finalPath).Length -gt 100)) {
            Write-Host "SUCCESS: $($tool.Name)"
            return $true
        } else {
            Write-Host "FAILED: $($tool.Name) - invalid file"
            return $false
        }

    } catch {
        Write-Host "ERROR: $($tool.Name) - $($_.Exception.Message)"
        return $false
    }
}

# Setup PATH environment
try {
    if (-not (Test-Path $PublicSoftwareDir)) { New-Item -ItemType Directory -Path $PublicSoftwareDir -Force | Out-Null }
    $currentPath = [System.Environment]::GetEnvironmentVariable("PATH", "Machine")
    if (-not ($currentPath -split ';' -contains $PublicSoftwareDir)) {
        $newPath = ($currentPath -split ';' | Where-Object { $_ -ne '' } | Select-Object -Unique) + $PublicSoftwareDir -join ';'
        [System.Environment]::SetEnvironmentVariable("PATH", $newPath, "Machine")
        $env:PATH = $newPath
    }
} catch {
    Write-Error "PATH setup failed"
    Write-Output "FinalFailedTools: All tools"
    exit 1
}

if ($UpdateClientTools) {
    # Reinstall all the tools
    foreach ($tool in $tools) {
        Install-Tool $tool
    }
} else {
    # Check which tools need installation
    $missing = @()
    foreach ($tool in $tools) {
        if (-not (Test-Tool $tool)) {
            $missing += $tool
            Write-Host "MISSING: $($tool.Name)"
        } else {
            Write-Host "OK: $($tool.Name)"
        }
    }

    $missingCount = @($missing).Count
    if ($missingCount -eq 0) {
        Write-Host "All tools present and working"
        Write-Output "FinalFailedTools: []"
        exit 0
    }

    # Install missing tools
    Write-Host "Installing $missingCount tools..."
    if (Test-Path $TempDownloadDir) { Get-ChildItem $TempDownloadDir -Recurse | Remove-Item -Force -ErrorAction SilentlyContinue }

    foreach ($tool in $missing) {
        Install-Tool $tool
    }
}

# Final verification
$env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";$PublicSoftwareDir"
$finalFailures = @()
foreach ($tool in $tools) {
    if (-not (Test-Tool $tool)) {
        $finalFailures += $tool.Name
    }
}

# Cleanup and exit
if (Test-Path $TempDownloadDir) { Remove-Item $TempDownloadDir -Recurse -Force -ErrorAction SilentlyContinue }

$finalFailureCount = @($finalFailures).Count
if ($finalFailureCount -eq 0) {
    Write-Host "=== ALL TOOLS INSTALLED AND VERIFIED ==="
    Write-Output "FinalFailedTools: []"
    exit 0
} else {
    Write-Host "=== SOME TOOLS FAILED: $($finalFailures -join ', ') ==="
    Write-Output "FinalFailedTools: $($finalFailures -join ', ')"
    exit 1
}
'@
#endregion

#region VM Processing
Write-Output "Finding target VMs..."

try {
    $vms = Get-AzVM | Where-Object {
        $_.StorageProfile.OsDisk.OsType -eq 'Windows' -and
        $_.Name -match $VMPattern -and
        $_.ResourceGroupName -match $ResourceGroupPattern
    }

    if ($vms.Count -eq 0) {
        Write-Error "No matching VMs found."
        exit 1
    }

    Write-Output "Found $($vms.Count) VMs for processing"
}
catch {
    Write-Error "Error retrieving VMs: $_"
    exit 1
}

# Get credentials
try {
    $artifactoryUserSecret = Get-AzKeyVaultSecret -VaultName $config.KeyVaultName -Name "artifactoryUser"
    $artifactoryPasswordSecret = Get-AzKeyVaultSecret -VaultName $config.KeyVaultName -Name "artifactorySecret"

    $artifactoryUser = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($artifactoryUserSecret.SecretValue))
    $artifactoryPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($artifactoryPasswordSecret.SecretValue))
}
catch {
    Write-Error "Failed to retrieve secrets: $_"
    exit 1
}

$scriptParams = @{
    ArtifactoryBaseUrl  = $config.ArtifactoryBaseUrl
    ArtifactoryRepo     = $config.ArtifactoryRepo
    ArtifactoryBasePath = $config.ArtifactoryBasePath
    ToolsToHandle       = $config.ToolsToHandleJson
    UpdateClientTools   = [int]$UpdateClientTools
    ArtifactoryUsername = $artifactoryUser
    ArtifactoryPassword = $artifactoryPassword
}

# Process VMs
$results = @()
$startTime = Get-Date

foreach ($vm in $vms) {
    Write-Output "Processing VM: $($vm.Name) ($(Get-Date -Format 'HH:mm:ss'))"

    try {
        $result = Invoke-AzVMRunCommand -ResourceGroupName $vm.ResourceGroupName -Name $vm.Name -CommandId 'RunPowerShellScript' -ScriptString $remoteScript -Parameter $scriptParams

        $output = $result.Value[0].Message
        $errorOutput = $result.Value[1].Message

        # Determine success
        if ($output -match "FinalFailedTools:\s*\[\s*\]") {
            $success = $true
            Write-Output "✅ SUCCESS: $($vm.Name) - All tools installed"
        }
        elseif ($output -match "FinalFailedTools:\s*(.+)") {
            $failedTools = $matches[1].Trim()
            $success = $false
            Write-Output "❌ FAILED: $($vm.Name) - Failed tools: $failedTools"
        }
        elseif ($output -match "All tools present") {
            $success = $true
            Write-Output "✅ SUCCESS: $($vm.Name) - All tools already present"
        }
        else {
            $success = $false
            Write-Output "⚠️ UNKNOWN: $($vm.Name) - Could not determine status"
        }

    }
    catch {
        $success = $false
        $errorOutput = $_.Exception.Message
        Write-Output "❌ ERROR: $($vm.Name) - $errorOutput"
    }

    $results += [PSCustomObject]@{
        VMName    = $vm.Name
        Success   = $success
        Timestamp = Get-Date
    }
}

# Final summary
$endTime = Get-Date
$totalTime = ($endTime - $startTime).TotalMinutes
$successCount = @($results | Where-Object { $_.Success }).Count
$failureCount = @($results | Where-Object { -not $_.Success }).Count

Write-Output "=== FINAL RESULTS ==="
Write-Output "Successful VMs: $successCount"
Write-Output "Failed VMs: $failureCount"
Write-Output "Total execution time: $([math]::Round($totalTime, 2)) minutes"

if ($failureCount -eq 0) {
    Write-Output "🎉 ALL VMs COMPLETED SUCCESSFULLY"
    exit 0
}
else {
    throw "⚠️ SOME VMs FAILED"
}
#endregion