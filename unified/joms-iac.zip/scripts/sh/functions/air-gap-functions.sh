#!/usr/bin/env bash

## Upload Functions
upload_artifact() {
    echo "Uploading artifact: $1"
    upload_artifact_wdsf_nexus "$1"
}

upload_artifact_wdsf_nexus() {
    artifact=$(basename "$1")
    curl -s -k \
        -u "$NEXUS_USERNAME:$NEXUS_PASSWORD" \
        --upload-file "$artifact" \
    "https://$NEXUS_DOMAIN/repository/$NEXUS_REPO/$1"
}


## Docker Login Functions
docker_login_nexus() {
    # Log into WDSF Nexus with Docker
    echo "${NEXUS_PASSWORD}" | \
        docker login --username "${NEXUS_USERNAME}" \
            --password-stdin "${NEXUS_DOMAIN}"
}


## Linux Download Functions
download_helm_dependencies() {
    # Download Helm (Linux)
    IN_FILE="helm-v$HELM_VERSION-linux-amd64.tar.gz"
    OUT_FILE="helm"
    BASE_URL="https://get.helm.sh"
    curl -s -L "$BASE_URL/$IN_FILE" -O
    tar -zxvf "$IN_FILE" "linux-amd64/$OUT_FILE" --strip-components 1
    # Verify checksum
    HASH_FILE="$IN_FILE.sha256sum"
    curl -s -L "$BASE_URL/$HASH_FILE" -O
    EXPECTED_HASH=$(cat "$HASH_FILE" | awk '{print $1}')
    ACTUAL_HASH=$(sha256sum $IN_FILE | awk '{print $1}')
    rm -f "$HASH_FILE"
    rm -f "$IN_FILE"
    compare_checksums "$EXPECTED_HASH" "$ACTUAL_HASH"
    chmod +x "$OUT_FILE"
}

download_docker_dependencies() {
    # Download YQ (Linux)
    IN_FILE="yq_linux_amd64"
    OUT_FILE="yq"
    BASE_URL="https://github.com/mikefarah/yq/releases/download/v$YQ_VERSION"
    curl -s -L "$BASE_URL/$IN_FILE" \
        -o "$OUT_FILE"
    # Verify checksum
    HASH_FILE="checksums"
    curl -s -L "$BASE_URL/$HASH_FILE" -O
    EXPECTED_HASH=$(cat "$HASH_FILE" | grep "$IN_FILE " | awk '{print $19}')
    ACTUAL_HASH=$(sha256sum $OUT_FILE | awk '{print $1}')
    rm -f "$HASH_FILE"
    compare_checksums "$EXPECTED_HASH" "$ACTUAL_HASH"
    chmod +x "$OUT_FILE"

    echo "Docker / BuildX Versions:"
    docker version
    docker buildx version
}

compare_checksums() {
    local expected_hash=$1
    local actual_hash=$2
    if [ "$expected_hash" != "$actual_hash" ]; then
        echo "Checksums didn't match. Exiting.."
        echo "Expected Hash: '$expected_hash'"
        echo "Actual Hash: '$actual_hash'"
        exit 1
    else
        echo "Checksums verified!"
    fi
}

retry() {
  set +e
  local n=0
  local try=$1
  local cmd="${@: 2}"
  [[ $# -le 1 ]] && { echo "Usage: retry <number_of_retries> <command>"; return 1; }

  until [[ $n -ge $try ]]
  do
    $cmd && break  # Run command and break loop if successful (exit code 0)
    ((n++)) # Increment counter if failed
    echo "Command failed. Attempt $n/$try. Retrying in 2 seconds..."
    sleep 2 # Wait for a short delay
  done

  if [[ $n -ge $try ]]; then
    echo "Failed to execute command after $try attempts."
    return 1 # Return a failure exit code
  fi
  set -e
}
