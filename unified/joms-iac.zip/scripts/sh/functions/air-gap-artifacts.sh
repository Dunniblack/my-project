#!/usr/bin/env bash
set -eo pipefail
#set -x

# Script to air-gap artifacts to WDSF Nexus

cat scripts/sh/metadata/versions.sh
source scripts/sh/metadata/versions.sh
source scripts/sh/functions/air-gap-functions.sh


BINARY_FOLDER='IaC/software/win-amd64'
MANIFEST_FOLDER='IaC/manifest'
PACKAGE_FOLDER='IaC/package'
DATE="$(date -u +%Y%m%d)"

if [ "${DESTINATION}" != "wdsf" ]; then
    DEST_PATH="${DESTINATION//-//}"
    BINARY_FOLDER="${DEST_PATH}/${BINARY_FOLDER}"
    MANIFEST_FOLDER="${DEST_PATH}/${MANIFEST_FOLDER}"
    PACKAGE_FOLDER="${DEST_PATH}/${PACKAGE_FOLDER}"
fi

airgap_binaries() {
    echo "Air-gapping the Binaries"

    # Download Docker
    IN_FILE="docker-$DOCKER_VERSION.zip"
    OUT_FILE="docker-$DOCKER_VERSION.exe"
    BASE_URL="https://download.docker.com/win/static/stable/x86_64"
    curl -s -L "$BASE_URL/$IN_FILE" -O
    unzip -p "$IN_FILE" docker/docker.exe > "$OUT_FILE"
    # Verify checksum
    HASH_FILE="checksum"
    curl -I -s -L "$BASE_URL/$IN_FILE" | cat | grep -i "^ETag" > $HASH_FILE
    EXPECTED_HASH=$(cat "$HASH_FILE" | awk '{print $2}' | tr -d '"\r')
    ACTUAL_HASH=$(md5sum $IN_FILE | awk '{print $1}')
    rm -f "$HASH_FILE"
    rm -f "$IN_FILE"
    compare_checksums "$EXPECTED_HASH" "$ACTUAL_HASH"
    upload_artifact "$BINARY_FOLDER/$OUT_FILE"

    # Download Docker BuildX
    IN_FILE="buildx-v$BUILDX_VERSION.windows-amd64.exe"
    OUT_FILE="buildx-$BUILDX_VERSION.exe"
    BASE_URL="https://github.com/docker/buildx/releases/download/v$BUILDX_VERSION"
    curl -s -L "$BASE_URL/$IN_FILE" \
        -o "$OUT_FILE"
    # Verify checksum
    HASH_FILE="checksums.txt"
    curl -s -L "$BASE_URL/$HASH_FILE" -O
    EXPECTED_HASH=$(cat "$HASH_FILE" | grep "$IN_FILE" | awk '{print $1}')
    ACTUAL_HASH=$(sha256sum $OUT_FILE | awk '{print $1}')
    rm -f "$HASH_FILE"
    compare_checksums "$EXPECTED_HASH" "$ACTUAL_HASH"
    upload_artifact "$BINARY_FOLDER/$OUT_FILE"

    # Download ImgPkg
    IN_FILE="imgpkg-windows-amd64.exe"
    OUT_FILE="imgpkg-$IMGPKG_VERSION.exe"
    BASE_URL="https://github.com/carvel-dev/imgpkg/releases/download/v$IMGPKG_VERSION/"
    curl -s -L "$BASE_URL/$IN_FILE" \
        -o "$OUT_FILE"
    # Verify checksum
    HASH_FILE="checksums.txt"
    curl -s -L "$BASE_URL/$HASH_FILE" -O
    EXPECTED_HASH=$(cat "$HASH_FILE" | grep "$IN_FILE" | awk '{print $1}')
    rm -f "$HASH_FILE"
    ACTUAL_HASH=$(sha256sum $OUT_FILE | awk '{print $1}')
    compare_checksums "$EXPECTED_HASH" "$ACTUAL_HASH"
    upload_artifact "$BINARY_FOLDER/$OUT_FILE"

    # Download Kbld
    IN_FILE="kbld-windows-amd64.exe"
    OUT_FILE="kbld-$KBLD_VERSION.exe"
    BASE_URL="https://github.com/carvel-dev/kbld/releases/download/v$KBLD_VERSION"
    curl -s -L "$BASE_URL/$IN_FILE" \
        -o "$OUT_FILE"
    # Verify checksum
    HASH_FILE="checksums.txt"
    curl -s -L "$BASE_URL/$HASH_FILE" -O
    EXPECTED_HASH=$(cat "$HASH_FILE" | grep "$IN_FILE" | awk '{print $1}')
    ACTUAL_HASH=$(sha256sum $OUT_FILE | awk '{print $1}')
    rm -f "$HASH_FILE"
    compare_checksums "$EXPECTED_HASH" "$ACTUAL_HASH"
    upload_artifact "$BINARY_FOLDER/$OUT_FILE"

    # Download YQ
    IN_FILE="yq_windows_amd64.exe"
    OUT_FILE="yq-$YQ_VERSION.exe"
    BASE_URL="https://github.com/mikefarah/yq/releases/download/v$YQ_VERSION"
    curl -s -L "$BASE_URL/$IN_FILE" \
        -o "$OUT_FILE"
    # Verify checksum
    HASH_FILE="checksums"
    curl -s -L "$BASE_URL/$HASH_FILE" -O
    EXPECTED_HASH=$(cat "$HASH_FILE" | grep "$IN_FILE" | awk '{print $19}')
    ACTUAL_HASH=$(sha256sum $OUT_FILE | awk '{print $1}')
    rm -f "$HASH_FILE"
    compare_checksums "$EXPECTED_HASH" "$ACTUAL_HASH"
    upload_artifact "$BINARY_FOLDER/$OUT_FILE"

    # Download Kubectl
    IN_FILE="kubectl.exe"
    OUT_FILE="kubectl-$KUBECTL_VERSION.exe"
    BASE_URL="https://dl.k8s.io/release/v$KUBECTL_VERSION/bin/windows/amd64"
    curl -s -L "$BASE_URL/$IN_FILE" \
        -o "$OUT_FILE"
    # Verify checksum
    HASH_FILE="$IN_FILE.sha256"
    curl -s -L "$BASE_URL/$HASH_FILE" -O
    EXPECTED_HASH=$(cat "$HASH_FILE")
    rm -f "$HASH_FILE"
    ACTUAL_HASH=$(sha256sum $OUT_FILE | awk '{print $1}')
    compare_checksums "$EXPECTED_HASH" "$ACTUAL_HASH"
    upload_artifact "$BINARY_FOLDER/$OUT_FILE"

    # Download Kubelogin
    IN_FILE="kubelogin-win-amd64.zip"
    OUT_FILE="kubelogin-$KUBELOGIN_VERSION.exe"
    BASE_URL="https://github.com/Azure/kubelogin/releases/download/v$KUBELOGIN_VERSION"
    curl -s -L "$BASE_URL/$IN_FILE" -O
    unzip -p "$IN_FILE" bin/windows_amd64/kubelogin.exe > "$OUT_FILE"
    # Verify checksum
    HASH_FILE="$IN_FILE.sha256"
    curl -s -L "$BASE_URL/$HASH_FILE" -O
    EXPECTED_HASH=$(cat "$HASH_FILE" | awk '{print $1}')
    ACTUAL_HASH=$(sha256sum $IN_FILE | awk '{print $1}')
    rm -f "$HASH_FILE"
    rm -f "$IN_FILE"
    compare_checksums "$EXPECTED_HASH" "$ACTUAL_HASH"
    upload_artifact "$BINARY_FOLDER/$OUT_FILE"

    # Download Helm (Windows)
    IN_FILE="helm-v$HELM_VERSION-windows-amd64.zip"
    OUT_FILE="helm-$HELM_VERSION.exe"
    BASE_URL="https://get.helm.sh"
    curl -s -L "$BASE_URL/$IN_FILE" -O
    unzip -p "$IN_FILE" windows-amd64/helm.exe > "$OUT_FILE"
    # Verify checksum
    HASH_FILE="$IN_FILE.sha256sum"
    curl -s -L "$BASE_URL/$HASH_FILE" -O
    EXPECTED_HASH=$(cat "$HASH_FILE" | awk '{print $1}')
    ACTUAL_HASH=$(sha256sum $IN_FILE | awk '{print $1}')
    rm -f "$HASH_FILE"
    rm -f "$IN_FILE"
    compare_checksums "$EXPECTED_HASH" "$ACTUAL_HASH"
    upload_artifact "$BINARY_FOLDER/$OUT_FILE"

    # Download Velero
    BASE_NAME="velero-v$VELERO_VERSION-windows-amd64"
    IN_FILE="$BASE_NAME.tar.gz"
    OUT_FILE="velero-$VELERO_VERSION.exe"
    BASE_URL="https://github.com/vmware-tanzu/velero/releases/download/v$VELERO_VERSION"
    curl -s -L "$BASE_URL/$IN_FILE" -O
    tar -zxvf "$IN_FILE" "$BASE_NAME/velero.exe" --strip-components 1
    mv "velero.exe" $OUT_FILE
    # Verify checksum
    HASH_FILE="CHECKSUM"
    curl -s -L "$BASE_URL/$HASH_FILE" -O
    EXPECTED_HASH=$(cat "$HASH_FILE" | grep "$IN_FILE" | awk '{print $1}')
    ACTUAL_HASH=$(sha256sum $IN_FILE | awk '{print $1}')
    rm -f "$HASH_FILE"
    rm -f "$IN_FILE"
    compare_checksums "$EXPECTED_HASH" "$ACTUAL_HASH"
    upload_artifact "$BINARY_FOLDER/$OUT_FILE"
}

generate_helm_index() {
    # Download the latest Helm index from Nexus
    OLD_FILE="index.old.yaml"
    curl -s -k \
        -u "$NEXUS_USERNAME:$NEXUS_PASSWORD" \
        "https://$NEXUS_DOMAIN/repository/$NEXUS_REPO/$HELM_REGISTRY_FOLDER/index.yaml" \
        -o $OLD_FILE

    # Generate Helm index based on local files
    if ! grep -q "Error 404" "$OLD_FILE" ; then
        helm repo index . --merge $OLD_FILE
    else
        helm repo index .
    fi
}

airgap_helm_charts() {
    echo "Air-gapping the Helm Charts"

    # Verify input
    if [ "$HELM_REGISTRY_FOLDER" = "" ]; then
        echo "HELM_REGISTRY_FOLDER cannot be an empty value. Exiting.."
        exit 1
    fi

    # Get the Helm Linux binary
    download_helm_dependencies

    # Log into the WDSF Docker instance
    docker_login_nexus

    # Download ArgoCD Helm Chart
    OUT_FILE="argo-cd-${ARGOCD_HELM_VERSION}.tgz"
    ./helm repo add argo https://argoproj.github.io/argo-helm
    ./helm repo update
    ./helm pull argo/argo-cd --version "${ARGOCD_HELM_VERSION}"
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Download Kyverno Helm Chart
    OUT_FILE="kyverno-${KYVERNO_HELM_VERSION}.tgz"
    ./helm repo add kyverno https://kyverno.github.io/kyverno
    ./helm repo update
    ./helm pull kyverno/kyverno --version "${KYVERNO_HELM_VERSION}"
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Package the Kyverno Policies Helm Chart
    HELM_CHART='kyverno-policies'
    HELM_CHART_PATH="helm-charts/$HELM_CHART"
    OUT_FILE="$HELM_CHART-${KYVERNO_POLICIES_HELM_VERSION}.tgz"
    helm package $HELM_CHART_PATH --version "${KYVERNO_POLICIES_HELM_VERSION}"
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Download Cert-Manager Helm Chart
    OUT_FILE="cert-manager-v${CERT_MANAGER_HELM_VERSION}.tgz"
    ./helm repo add cert-manager https://charts.jetstack.io
    ./helm repo update
    ./helm pull cert-manager/cert-manager --version "${CERT_MANAGER_HELM_VERSION}"
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Download External-Secrets-Operator Helm Chart
    OUT_FILE="external-secrets-${EXTERNAL_SECRETS_HELM_VERSION}.tgz"
    ./helm repo add external-secrets https://charts.external-secrets.io
    ./helm repo update
    ./helm pull external-secrets/external-secrets --version "${EXTERNAL_SECRETS_HELM_VERSION}"
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Download Traefik Helm Chart
    OUT_FILE="traefik-${TRAEFIK_HELM_VERSION}.tgz"
    ./helm repo add traefik https://traefik.github.io/charts
    ./helm repo update
    ./helm pull traefik/traefik --version "${TRAEFIK_HELM_VERSION}"
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Download Grafana Helm Chart
    OUT_FILE="kube-prometheus-stack-${GRAFANA_HELM_VERSION}.tgz"
    ./helm repo add grafana https://prometheus-community.github.io/helm-charts
    ./helm repo update
    ./helm pull grafana/kube-prometheus-stack --version "${GRAFANA_HELM_VERSION}"
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Download Loki Helm Chart
    OUT_FILE="loki-${LOKI_HELM_VERSION}.tgz"
    ./helm repo add loki https://grafana.github.io/helm-charts --force-update
    ./helm repo update
    ./helm pull loki/loki --version "${LOKI_HELM_VERSION}"
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Download Grafana Alloy Helm Chart
    OUT_FILE="alloy-${ALLOY_HELM_VERSION}.tgz"
    ./helm repo add alloy https://grafana.github.io/helm-charts
    ./helm repo update
    ./helm pull alloy/alloy --version "${ALLOY_HELM_VERSION}"
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Download Rancher Helm Chart
    OUT_FILE="rancher-${RANCHER_HELM_VERSION}.tgz"
    ./helm repo add rancher https://releases.rancher.com/server-charts/stable
    ./helm repo update
    ./helm pull rancher/rancher --version "${RANCHER_HELM_VERSION}"
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Download Velero Helm Chart
    OUT_FILE="velero-${VELERO_HELM_VERSION}.tgz"
    ./helm repo add velero https://vmware-tanzu.github.io/helm-charts/
    ./helm repo update
    ./helm pull velero/velero --version "${VELERO_HELM_VERSION}"
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Download Noms-Cluster-Base Git and Package up
    OUT_FILE="cluster-base-resources-${CLUSTER_BASE_RESOURCES_HELM_VERSION}.tgz"
    rm -rf noms-cluster-base
    git clone https://"${GIT_UN}":"${GIT_PW}"@bitbucket.seicdevops.com/scm/dep/noms-cluster-base.git
    cd noms-cluster-base
    git checkout cluster-base-resources-conversion-dynamic
    helm package . --destination ..
    cd ..
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Download Core-Cluster-Applications Git and Package up
    OUT_FILE="core-cluster-applications-${CORE_CLUSTER_APPLICATIONS_HELM_VERSION}.tgz"
    rm -rf argocd-mvcr
    git clone https://"${GIT_UN}":"${GIT_PW}"@bitbucket.seicdevops.com/scm/dep/argocd-mvcr.git
    cd argocd-mvcr
    git checkout ANR-2550-restore
    # git checkout core-cluster-applications
    cd core-cluster-applications
    helm package . --destination ../..
    cd ../..
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Download Twistlock/Prisma-Cloud Git and Package up
    OUT_FILE="twistlock-${TWISTLOCK_HELM_VERSION}.tgz"
    rm -rf cloud1-deployment
    git clone https://"${GIT_UN}":"${GIT_PW}"@bitbucket.seicdevops.com/scm/dep/cloud1-deployment.git
    cd cloud1-deployment
    git checkout develop
    cd twistlock/chart/
    helm package . --destination ../../..
    cd ../../..
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Download Noms-Infrastructure Helm Chart
    HELM_CHART='noms-infrastructure'
    OUT_FILE="${HELM_CHART}-${NOMS_INFRASTRUCTURE_HELM_VERSION}.tgz"
    helm pull "oci://${NEXUS_DOMAIN}/helm-dev-oci/${HELM_CHART}" --version "${NOMS_INFRASTRUCTURE_HELM_VERSION}"
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Generate a Helm Repo Index Yaml File and Upload
    generate_helm_index
    upload_artifact "$HELM_REGISTRY_FOLDER/index.yaml"
}

airgap_mp_helm_chart() {
    echo "Air-gapping the Mission Planner Helm Chart"

    # Get the Helm Linux binary
    download_helm_dependencies

    # Log into the WDSF Docker instance
    docker_login_nexus

    # Download Mission Planner Helm Chart
    HELM_CHART='wp-server-b1-il5'
    OUT_FILE="${HELM_CHART}-${MISSION_PLANNER_HELM_VERSION}.tgz"
    helm pull "oci://${NEXUS_DOMAIN}/helm-dev-oci/${HELM_CHART}" --version "${MISSION_PLANNER_HELM_VERSION}"
    upload_artifact "$HELM_REGISTRY_FOLDER/$OUT_FILE"

    # Generate a Helm Repo Index Yaml File and Upload
    generate_helm_index
    upload_artifact "$HELM_REGISTRY_FOLDER/index.yaml"
}

airgap_docker_images() {
    echo "Air-gapping the Docker images"

    # Download the Docker dependencies
    download_docker_dependencies

    # Log into the WDSF Nexus Docker instance
    docker_login_nexus

    # Download the Kbld Images file
    OUT_FILE="kbld-images-file.yaml"
    curl -s -k \
        -u "$NEXUS_USERNAME:$NEXUS_PASSWORD" \
        "https://$NEXUS_DOMAIN/repository/$NEXUS_REPO/$MANIFEST_FOLDER/$OUT_FILE" -O

    readarray IMAGES < <(./yq e -o=j -I=0 '.images[]' kbld-images-file.yaml)

    MANIFEST='docker.manifest'
    :> "$MANIFEST"
    :> "$MANIFEST.tmp"

    # Only Airgap Docker images referenced from WDSF Nexus
    for image in "${IMAGES[@]}"; do
        image_tag=$(echo "$image" | ./yq e '.annotations."kbld.carvel.dev/id"' -);
        (echo "$image_tag" | grep "$NEXUS_DOMAIN" >> "$MANIFEST") || :;
    done

    # Make sure to include the other Twistlock Docker images
    # (Not referenced in the Helm chart, so Kbld doesn't pick them up)
    TWISTLOCK_CONSOLE_IMG=$(grep console "$MANIFEST")
    if [ -n "$TWISTLOCK_CONSOLE_IMG" ]; then
        TWISTLOCK_DEFENDER_IMG="${TWISTLOCK_CONSOLE_IMG//console/defender}"
        echo "$TWISTLOCK_DEFENDER_IMG" >> "$MANIFEST"
    fi

    # Make sure to include the other Prometheus Docker images
    # (Not referenced in the Helm chart, so Kbld doesn't pick them up)
    PROMETHEUS_OPERATOR_IMG=$(grep prometheus-operator "$MANIFEST")
    if [ -n "$PROMETHEUS_OPERATOR_IMG" ]; then
        PROMETHEUS_CONFIG_IMG="${PROMETHEUS_OPERATOR_IMG//prometheus-operator:/prometheus-config-reloader:}"
        echo "$PROMETHEUS_CONFIG_IMG" >> "$MANIFEST"
    fi

    # Make sure to include the other Rancher images
    # (Not referenced in the Helm chart, so Kbld doesn't pick them up)
    if grep -q "rancher" "$MANIFEST"; then
      cat <<-EOF >> "$MANIFEST"
        $NEXUS_DOMAIN/rancher/fleet:v0.12.5
        $NEXUS_DOMAIN/rancher/kubectl:v1.32.2
        $NEXUS_DOMAIN/rancher/machine:v0.15.0-rancher131-carbide-1
        $NEXUS_DOMAIN/rancher/mirrored-cluster-api-controller:v1.9.5
        $NEXUS_DOMAIN/rancher/rancher-agent:v2.11.4-carbide-1
        $NEXUS_DOMAIN/rancher/rancher-cleanup:v1.0.3
        $NEXUS_DOMAIN/rancher/rancher-webhook:v0.7.4
        $NEXUS_DOMAIN/rancher/shell:v0.4.1
        $NEXUS_DOMAIN/rancher/system-upgrade-controller:v0.15.2
EOF
    fi

    # Make sure images are sorted and unique
    sort -u "$MANIFEST" -o "$MANIFEST"

    # Airgap the final Docker images
    while read -r source_image; do
        image_tag="$(basename "$source_image")"
        image_repo="$(basename "$(dirname "$source_image")")"
        dest_image="$ART_DOMAIN/$ART_DOCKER_REPO/$image_repo/$image_tag"
        echo "Source: $source_image"
        echo "Destination: $dest_image"

        echo "$dest_image" >> "$MANIFEST.tmp"
        echo "Checking for existence of $dest_image..."
        if docker manifest inspect "$dest_image" > /dev/null 2>&1; then
            echo "Image $dest_image already exists. Skipping."
            continue
        fi
        retry 3 \
           docker pull "$source_image"
        docker tag "$source_image" "$dest_image"
        retry 3 \
           docker push "$dest_image"
        if [ $? -eq 0 ]; then
            echo "Push successful for $dest_image. Cleaning up local images..."
            docker rmi "$source_image"
            docker rmi "$dest_image"
        else
            echo "ERROR: Failed to push $dest_image after 3 attempts. Halting script."
            exit 1
        fi
        #docker buildx imagetools create --tag "$dest_image" "$source_image"
    done <"$MANIFEST"

    mv "$MANIFEST.tmp" "$MANIFEST"

    upload_artifact "IaC/manifest/$MANIFEST"
    upload_artifact "IaC/manifest/$DATE/$MANIFEST"
}

airgap_terraform_bundle() {
    echo "Air-gapping the Terraform Bundle"

    # Download and build Terraform Bundle
    git clone \
        --single-branch \
        --branch=v0.15 \
        --depth=1 \
        https://github.com/hashicorp/terraform.git tf-bundle
    cd tf-bundle
    go build -o ../terraform-bundle ./tools/terraform-bundle

    echo "TERRAFORM_BUNDLE_VERSION:"
    ../terraform-bundle --version

    echo "TERRAFORM_VERSION: $TERRAFORM_VERSION"

    # Download and package the Terraform Provider
    ../terraform-bundle package -os=windows -arch=amd64 ../terraform/bundle/providers.hcl

    # Rename the default file name
    OUT_FILE="terraform-bundle-${TERRAFORM_VERSION}.zip"
    mv terraform_"${TERRAFORM_VERSION}"-bundle*_windows_amd64.zip $OUT_FILE

    upload_artifact "$BINARY_FOLDER/$OUT_FILE"
    cd "$WORKSPACE"
}

airgap_iac_package() {
    echo "Air-gapping the IaC Package"
    OUT_FILE="joms-iac.zip"

    # Create a Git archive of current IaC
    git archive -o $OUT_FILE HEAD --format 'zip'

    upload_artifact "$PACKAGE_FOLDER/$OUT_FILE"
    upload_artifact "$PACKAGE_FOLDER/$DATE/$OUT_FILE"
}

if [[ "$AIRGAP_BINARIES" = "true" ]]; then
    airgap_binaries
fi
if [[ "$AIRGAP_TF_BUNDLE" = "true" ]]; then
    airgap_terraform_bundle
fi
if [[ "$AIRGAP_HELM_CHARTS" = "true" ]]; then
    airgap_helm_charts
fi
if [[ "$AIRGAP_MP_HELM_CHART" = "true" ]]; then
    airgap_mp_helm_chart
fi
if [[ "$AIRGAP_DOCKER_IMGS" = "true" ]]; then
    airgap_docker_images
fi
if [[ "$AIRGAP_IAC_PACKAGE" = "true" ]]; then
    airgap_iac_package
fi
