#!/usr/bin/env bash
set -euo pipefail

TARGET_IMAGES="${TARGET_IMAGES:-}"
AD_HOC_OSCAP_DATASTREAM="${AD_HOC_OSCAP_DATASTREAM:-}"
AD_HOC_OSCAP_PROFILE="${AD_HOC_OSCAP_PROFILE:-}"
IMAGE_COMMANDS="${IMAGE_COMMANDS:-}"
RUN_SCANS="${RUN_SCANS:-true}"

# Inputs:
#   $@: Names of required environment variables.
# Returns:
#   0 when all named variables are set; exits 1 when any are missing.
require_env() {
    local missing=0
    for name in "$@"; do
        if [[ -z "${!name:-}" ]]; then
            echo "Required environment variable is not set: $name" >&2
            missing=1
        fi
    done
    if [[ "$missing" -ne 0 ]]; then
        exit 1
    fi
}

# Inputs:
#   $1: Image reference or component name.
# Outputs:
#   Writes a filesystem/blob-path-safe name to stdout.
# Returns:
#   0 unless sed fails.
safe_path_name() {
    sed -E 's#[^A-Za-z0-9._-]+#_#g; s#^_+##; s#_+$##' <<< "$1"
}

# Inputs:
#   $1: Boolean-like string.
# Returns:
#   0 for true/yes/1; 1 for all other values.
is_true() {
    case "${1,,}" in
        true|yes|1) return 0 ;;
        *) return 1 ;;
    esac
}

# Inputs:
#   $1: Docker image reference.
# Returns:
#   0 when the image includes an explicit registry; 1 otherwise.
is_fully_qualified_image() {
    local image="$1"
    local first_path_part

    if [[ "$image" != */* ]]; then
        return 1
    fi

    first_path_part="${image%%/*}"
    [[ "$first_path_part" == *.* || "$first_path_part" == *:* || "$first_path_part" == "localhost" ]]
}

# Inputs:
#   Environment: WORKSPACE, OSCAP_OUTPUT_ROOT, OSCAP_RUN_ID, NEXUS_DOMAIN,
#     NEXUS_USERNAME, NEXUS_PASSWORD, OSCAP_STORAGE_ACCOUNT, OSCAP_RESULTS_CONTAINER.
# Side effects:
#   Initializes global path variables, logs in to Docker, writes auth files, and
#   creates the plain-text link file Jenkins archives.
# Returns:
#   0 on successful initialization; non-zero on failed commands.
init_workspace() {
    results_dir="$WORKSPACE/$OSCAP_OUTPUT_ROOT/$OSCAP_RUN_ID"
    docker_config_dir="$WORKSPACE/.docker"
    oscap_auth_dir="$WORKSPACE/.oscap-scan"
    oscap_work_dir="$WORKSPACE/.oscap-work"

    mkdir -p "$results_dir" "$docker_config_dir" "$oscap_auth_dir" "$oscap_work_dir"

    export DOCKER_CONFIG="$docker_config_dir"
    export OSCAP_AUTH_FILE="$oscap_auth_dir/auth.json"

    docker login "$NEXUS_DOMAIN" \
        --username "$NEXUS_USERNAME" \
        --password-stdin <<< "$NEXUS_PASSWORD"
    cp "$DOCKER_CONFIG/config.json" "$OSCAP_AUTH_FILE"

    storage_suffix="$(az cloud show --query suffixes.storageEndpoint --output tsv)"
    blob_url_base="https://${OSCAP_STORAGE_ACCOUNT}.blob.${storage_suffix}/${OSCAP_RESULTS_CONTAINER}"

    # Jenkins archives only this plain-text pointer file by default; SCAP reports live in Blob Storage.
    {
        echo "OSCAP Image Scan Results"
        echo
        printf 'Storage account : %s\n' "$OSCAP_STORAGE_ACCOUNT"
        printf 'Container       : %s\n' "$OSCAP_RESULTS_CONTAINER"
        printf 'Run prefix      : %s\n' "$OSCAP_RUN_ID"
        printf 'Blob root       : %s\n' "$blob_url_base/$OSCAP_RUN_ID/"
        echo
    } > "$results_dir/storage-links.txt"
}

# Inputs:
#   Environment: OSCAP_STORAGE_ACCOUNT, and optionally OSCAP_STORAGE_ACCOUNT_KEY.
# Side effects:
#   Sets OSCAP_STORAGE_RESOURCE_GROUP and OSCAP_STORAGE_ACCOUNT_KEY for Blob uploads.
# Returns:
#   0 when upload credentials are available; exits 1 when Azure cannot resolve them.
resolve_storage_upload_credentials() {
    if [[ -n "${OSCAP_STORAGE_ACCOUNT_KEY:-}" ]]; then
        return 0
    fi

    if ! OSCAP_STORAGE_RESOURCE_GROUP="$(
        az storage account show \
            --name "$OSCAP_STORAGE_ACCOUNT" \
            --query resourceGroup \
            --output tsv \
            --only-show-errors
    )" || [[ -z "$OSCAP_STORAGE_RESOURCE_GROUP" ]]; then
        echo "Unable to resolve resource group for storage account: $OSCAP_STORAGE_ACCOUNT" >&2
        exit 1
    fi

    if ! OSCAP_STORAGE_ACCOUNT_KEY="$(
        az storage account keys list \
            --resource-group "$OSCAP_STORAGE_RESOURCE_GROUP" \
            --account-name "$OSCAP_STORAGE_ACCOUNT" \
            --query '[0].value' \
            --output tsv \
            --only-show-errors
    )" || [[ -z "$OSCAP_STORAGE_ACCOUNT_KEY" ]]; then
        echo "Unable to resolve storage account key for: $OSCAP_STORAGE_ACCOUNT" >&2
        exit 1
    fi
}

# Inputs:
#   Environment: IMAGE_LIST_FILE and WORKSPACE.
# Side effects:
#   Sets global image_list_file to an absolute path.
# Returns:
#   0 when the image list exists; exits 1 when it cannot be found.
resolve_image_list_file() {
    image_list_file="$IMAGE_LIST_FILE"
    if [[ "$image_list_file" != /* ]]; then
        image_list_file="$WORKSPACE/$image_list_file"
    fi

    if [[ ! -f "$image_list_file" ]]; then
        echo "Image list file not found: $image_list_file" >&2
        exit 1
    fi
}

# Inputs:
#   Environment: TARGET_IMAGES, AD_HOC_OSCAP_DATASTREAM, and AD_HOC_OSCAP_PROFILE.
#   Global variables: image_list_file, oscap_work_dir.
# Side effects:
#   Sets global selected_image_list and writes the internal scan list.
# Returns:
#   0 when at least one image is selected; exits 1 when the list is empty.
#
# Internal scan list format:
#   column 1 = image reference
#   column 2 = component name
#   column 3 = optional datastream override
#   column 4 = optional profile override
#
# TARGET_IMAGES is an override mode: when present, only those images are
# processed and AD_HOC_OSCAP_DATASTREAM/AD_HOC_OSCAP_PROFILE apply to those images. When it
# is empty, image-list.yaml provides the scan list and its own optional overrides.
build_selected_image_list() {
    selected_image_list="$oscap_work_dir/selected-images.psv"
    local image
    local image_csv
    local raw_image
    local found_csv_image=0

    : > "$selected_image_list"

    image_csv="$(printf '%s' "$TARGET_IMAGES" | tr '\r\n' ',,')"
    IFS=',' read -r -a ad_hoc_images <<< "$image_csv"
    for raw_image in "${ad_hoc_images[@]}"; do
        image="$(xargs <<< "$raw_image")"
        if [[ -n "$image" ]]; then
            printf '%s|ad-hoc|%s|%s\n' "$image" "$AD_HOC_OSCAP_DATASTREAM" "$AD_HOC_OSCAP_PROFILE" >> "$selected_image_list"
            found_csv_image=1
        fi
    done

    if [[ "$found_csv_image" -eq 1 ]]; then
        return 0
    fi

    resolve_image_list_file

    # Normalize the grouped YAML config into an internal pipe-delimited list for the scan loop.
    # This stays outside results_dir so Jenkins archives only the plain-text link file.
    ~/go/bin/yq eval -r '
        .components[] |
        .name as $component |
        (.oscap.datastream // "") as $componentDatastream |
        (.oscap.profile // "") as $componentProfile |
        (.images // [])[] |
        [
            (.ref // .image // .),
            $component,
            (.oscap.datastream // $componentDatastream),
            (.oscap.profile // $componentProfile)
        ] |
        join("|")
    ' "$image_list_file" >> "$selected_image_list"

    if [[ ! -s "$selected_image_list" ]]; then
        echo "No images selected to scan" >&2
        exit 1
    fi
}

# Inputs:
#   $1: Requested image reference.
#   $2: Component name.
#   $3: OpenSCAP scan exit code.
#   $4: Evidence command exit code.
#   $@: Uploaded report URLs.
# Side effects:
#   Appends a human-readable result row to storage-links.txt.
# Returns:
#   0 unless writing to storage-links.txt fails.
append_storage_link_row() {
    local image="$1"
    local component="$2"
    local scan_rc="$3"
    local evidence_rc="$4"
    shift 4
    local report_url
    local report_count=0

    {
        printf 'Component   : %s\n' "$component"
        printf 'Image       : %s\n' "$image"
        printf 'Scan RC     : %s\n' "$scan_rc"
        printf 'Evidence RC : %s\n' "$evidence_rc"
        echo 'Outputs     :'
        if [[ "$#" -eq 0 ]]; then
            echo '  None uploaded'
        else
            for report_url in "$@"; do
                report_count=$((report_count + 1))
                printf '  %s. %s\n' "$report_count" "$report_url"
            done
        fi
        echo
    } >> "$results_dir/storage-links.txt"
}

# Inputs:
#   $1: Failure label.
#   $2: Image reference.
#   $3: Exit code.
#   $4: Log file to summarize.
# Outputs:
#   Writes a short failure summary and log tail to stdout.
# Returns:
#   0; missing or unreadable logs are tolerated.
print_failure_context() {
    local label="$1"
    local image="$2"
    local exit_code="$3"
    local log_file="$4"

    echo "$label failed for $image with exit code $exit_code"
    if [[ -s "$log_file" ]]; then
        echo "Last 40 lines from $(basename "$log_file"):"
        tail -n 40 "$log_file" || true
    fi
}

# Inputs:
#   $1: Scan exit code.
#   $2: OpenSCAP log file.
# Returns:
#   0 when the failure looks resource-related; 1 otherwise.
is_resource_failure() {
    local exit_code="$1"
    local log_file="$2"

    if [[ "$exit_code" -eq 137 || "$exit_code" -eq 139 ]]; then
        return 0
    fi

    [[ -s "$log_file" ]] && grep -Eiq \
        'out of memory|Memory allocation failed|pthread_create failed|Resource temporarily unavailable|Not enough space|Killed|Segmentation fault' \
        "$log_file"
}

# Inputs:
#   $1: Image whose scan hit a likely resource failure.
# Outputs:
#   Writes a compact Jenkins-console resource snapshot for troubleshooting OOM/PID/disk failures.
# Returns:
#   0; missing host tools or cgroup files are tolerated.
print_resource_context() {
    local image="$1"
    local cgroup_file

    echo "Agent resource snapshot after resource-related scan failure for $image:"
    if command -v free >/dev/null 2>&1; then
        free -h || true
    fi

    if [[ -r /proc/meminfo ]]; then
        awk '/^(MemTotal|MemAvailable|SwapTotal|SwapFree):/ { print }' /proc/meminfo || true
    fi

    echo "ulimit_max_user_processes=$(ulimit -u 2>/dev/null || true)"
    echo "ulimit_open_files=$(ulimit -n 2>/dev/null || true)"

    for cgroup_file in \
        /sys/fs/cgroup/memory.max \
        /sys/fs/cgroup/memory.current \
        /sys/fs/cgroup/pids.max \
        /sys/fs/cgroup/pids.current \
        /sys/fs/cgroup/memory/memory.limit_in_bytes \
        /sys/fs/cgroup/memory/memory.usage_in_bytes; do
        if [[ -r "$cgroup_file" ]]; then
            printf '%s=%s\n' "$(basename "$cgroup_file")" "$(cat "$cgroup_file")"
        fi
    done

    df -h "$WORKSPACE" /tmp 2>/dev/null || df -h "$WORKSPACE" || true
    docker system df 2>/dev/null || true
}

# Inputs:
#   $1: Local image result directory.
#   $2: Destination Blob prefix.
#   $3: oscap-scan output name prefix.
#   Environment: OSCAP_STORAGE_ACCOUNT, OSCAP_STORAGE_ACCOUNT_KEY, and OSCAP_RESULTS_CONTAINER.
# Side effects:
#   Populates global uploaded_report_urls with uploaded report links and
#   upload_scap_reports_error with a short failure reason.
# Returns:
#   0 when at least one generated default SCAP report uploads; non-zero otherwise.
upload_scap_reports() {
    local image_result_dir="$1"
    local blob_prefix="$2"
    local output_name="$3"
    local report_file
    local report_name
    local report_url
    local -a report_files
    local -a expected_report_files
    uploaded_report_urls=()
    upload_scap_reports_error=""

    expected_report_files=(
        "$image_result_dir/$output_name-report.html"
        "$image_result_dir/$output_name-report.xml"
        "$image_result_dir/$output_name-stigviewer.xml"
    )
    report_files=()

    for report_file in "${expected_report_files[@]}"; do
        if [[ -f "$report_file" ]]; then
            report_files+=("$report_file")
        fi
    done

    if [[ "${#report_files[@]}" -eq 0 ]]; then
        shopt -s nullglob
        report_files=(
            "$image_result_dir"/*-report.html
            "$image_result_dir"/*-report.xml
            "$image_result_dir"/*-stigviewer.xml
        )
        shopt -u nullglob
    fi

    if [[ "${#report_files[@]}" -eq 0 ]]; then
        upload_scap_reports_error="no default SCAP report files were generated"
        return 1
    fi

    for report_file in "${report_files[@]}"; do
        report_name="$(basename "$report_file")"
        if ! az storage blob upload \
            --account-name "$OSCAP_STORAGE_ACCOUNT" \
            --account-key "$OSCAP_STORAGE_ACCOUNT_KEY" \
            --auth-mode key \
            --container-name "$OSCAP_RESULTS_CONTAINER" \
            --name "$blob_prefix/$report_name" \
            --file "$report_file" \
            --overwrite true \
            --only-show-errors \
            --no-progress \
            --output none \
            1> /dev/null; then
            upload_scap_reports_error="Azure upload failed for $report_name"
            return 1
        fi
        report_url="$blob_url_base/$blob_prefix/$report_name"
        uploaded_report_urls+=("$report_url")
    done

    [[ "${#uploaded_report_urls[@]}" -gt 0 ]]
}

# Inputs:
#   $1: Local evidence log file.
#   $2: Destination Blob prefix.
#   Environment: OSCAP_STORAGE_ACCOUNT, OSCAP_STORAGE_ACCOUNT_KEY, and OSCAP_RESULTS_CONTAINER.
# Side effects:
#   Populates global uploaded_evidence_url with the uploaded evidence link.
# Returns:
#   0 when the evidence log uploads; non-zero otherwise.
upload_evidence_log() {
    local evidence_log="$1"
    local blob_prefix="$2"
    local evidence_name
    uploaded_evidence_url=""

    if [[ ! -f "$evidence_log" ]]; then
        return 1
    fi

    evidence_name="$(basename "$evidence_log")"
    if ! az storage blob upload \
        --account-name "$OSCAP_STORAGE_ACCOUNT" \
        --account-key "$OSCAP_STORAGE_ACCOUNT_KEY" \
        --auth-mode key \
        --container-name "$OSCAP_RESULTS_CONTAINER" \
        --name "$blob_prefix/$evidence_name" \
        --file "$evidence_log" \
        --overwrite true \
        --only-show-errors \
        --no-progress \
        --output none \
        1> /dev/null; then
        return 1
    fi

    uploaded_evidence_url="$blob_url_base/$blob_prefix/$evidence_name"
}

# Inputs:
#   $1: Docker image reference to remove.
# Side effects:
#   Attempts to remove the image and prune dangling layers from the Jenkins agent.
# Returns:
#   Always 0; cleanup failures are intentionally ignored.
cleanup_docker_image() {
    local image="$1"

    if [[ -z "$image" ]]; then
        return 0
    fi

    # Target image layers accumulate in the Jenkins agent Docker daemon unless removed explicitly.
    {
        docker image rm "$image"
        docker image prune -f
    } > /dev/null 2>&1 || true
}

# Inputs:
#   $1: Requested image reference.
#   $2: Component name.
#   $3: Effective datastream from image-list.yaml, or from AD_HOC_OSCAP_DATASTREAM in TARGET_IMAGES mode.
#   $4: Effective profile from image-list.yaml, or from AD_HOC_OSCAP_PROFILE in TARGET_IMAGES mode.
# Side effects:
#   Pulls/scans one image, optionally runs evidence commands, uploads SCAP reports,
#   appends plain-text links, removes local result files, and updates overall_rc.
# Returns:
#   0 unless an unexpected command failure occurs; scan/evidence failures are recorded
#   in overall_rc instead of returned directly.
scan_image() {
    local image="$1"
    local component="$2"
    local image_datastream="$3"
    local image_profile="$4"
    local safe_name
    local safe_component
    local image_result_dir
    local resolved_image=""
    local effective_datastream
    local effective_profile
    local scan_rc=1
    local scan_rc_display="1"
    local evidence_rc=0
    local blob_prefix
    local report_output_name=""
    local pull_rc
    local scan_was_skipped=0
    local -a output_urls
    uploaded_report_urls=()
    uploaded_evidence_url=""
    upload_scap_reports_error=""
    output_urls=()

    safe_name="$(safe_path_name "$image")"
    safe_component="$(safe_path_name "$component")"
    image_result_dir="$results_dir/$safe_name"
    effective_datastream="$image_datastream"
    effective_profile="$image_profile"
    mkdir -p "$image_result_dir"

    : > "$image_result_dir/pull.log"
    if ! is_fully_qualified_image "$image"; then
        echo "Image must be fully qualified with a registry: $image" >> "$image_result_dir/pull.log"
    else
        echo "Pulling $image" >> "$image_result_dir/pull.log"
        set +e
        docker pull "$image" >> "$image_result_dir/pull.log" 2>&1
        pull_rc=$?
        set -e

        echo "pull_exit_code=$pull_rc" >> "$image_result_dir/pull.log"
        if [[ "$pull_rc" -eq 0 ]]; then
            resolved_image="$image"
            report_output_name="$(safe_path_name "$resolved_image")"
        fi
    fi

    if [[ -n "$resolved_image" ]]; then
        if ! is_true "$RUN_SCANS"; then
            scan_was_skipped=1
            scan_rc=0
            scan_rc_display="SKIPPED"
            echo "OpenSCAP scan skipped because RUN_SCANS is false." > "$image_result_dir/oscap-scan.log"
            echo "Skipping OpenSCAP scan for $resolved_image"
        else
            set +e
            run_oscap_scan "$resolved_image" "$image_result_dir" "$effective_datastream" "$effective_profile"
            scan_rc=$?
            scan_rc_display="$scan_rc"
            set -e
            if [[ "$scan_rc" -ne 0 ]]; then
                print_failure_context "OpenSCAP scan" "$resolved_image" "$scan_rc" "$image_result_dir/oscap-scan.log"
                if is_resource_failure "$scan_rc" "$image_result_dir/oscap-scan.log"; then
                    print_resource_context "$resolved_image"
                fi
            fi
        fi

        if [[ -n "$IMAGE_COMMANDS" ]]; then
            set +e
            run_evidence "$resolved_image" "$image_result_dir" "$scan_rc"
            evidence_rc=$?
            set -e
            if [[ "$evidence_rc" -ne 0 ]]; then
                print_failure_context "Post-scan evidence command" "$resolved_image" "$evidence_rc" "$image_result_dir/post-scan-evidence.log"
            fi
        fi
    else
        echo "Unable to pull $image" > "$image_result_dir/oscap-scan.log"
        print_failure_context "Image pull" "$image" 1 "$image_result_dir/pull.log"
        overall_rc=1
    fi

    if [[ "$scan_rc" -ne 0 || "$evidence_rc" -ne 0 ]]; then
        overall_rc=1
    fi

    cleanup_docker_image "$resolved_image"

    # Upload each image's SCAP reports immediately, then delete temporary local files.
    blob_prefix="$OSCAP_RUN_ID/components/$safe_component/$safe_name"

    if [[ "$scan_was_skipped" -eq 0 ]]; then
        if upload_scap_reports "$image_result_dir" "$blob_prefix" "$report_output_name"; then
            output_urls+=("${uploaded_report_urls[@]}")
        else
            echo "No SCAP reports uploaded for $image: $upload_scap_reports_error" >&2
            overall_rc=1
        fi
    fi

    if [[ -f "$image_result_dir/post-scan-evidence.log" ]]; then
        if upload_evidence_log "$image_result_dir/post-scan-evidence.log" "$blob_prefix"; then
            output_urls+=("$uploaded_evidence_url")
        else
            echo "Failed to upload evidence command output for $image" >&2
            overall_rc=1
        fi
    fi

    append_storage_link_row "$image" "$component" "$scan_rc_display" "$evidence_rc" "${output_urls[@]}"

    rm -rf "$image_result_dir"
}

# Inputs:
#   $1: Resolved image reference to scan.
#   $2: Local image result directory.
#   $3: Effective datastream value.
#   $4: Effective profile value.
#   Environment: WORKSPACE.
# Side effects:
#   Writes oscap-scan.log and scanner-generated output under the image result directory.
# Returns:
#   Exit code from oscap-scan.
run_oscap_scan() {
    local resolved_image="$1"
    local image_result_dir="$2"
    local datastream="$3"
    local profile="$4"
    local scan_output_name
    local -a scan_args
    local scan_rc

    scan_output_name="$(safe_path_name "$resolved_image")"
    scan_args=(--auto-defaults --output-name "$scan_output_name")
    if [[ -n "$datastream" ]]; then
        scan_args+=(--datastream "$datastream")
    fi
    if [[ -n "$profile" ]]; then
        scan_args+=(--profile "$profile")
    fi
    scan_args+=("$resolved_image")

    echo "Scanning $resolved_image"
    set +e
    OSCAP_OUTPUT_DIR="$image_result_dir" \
        "$WORKSPACE/bin/oscap-scan" "${scan_args[@]}" \
        > "$image_result_dir/oscap-scan.log" 2>&1
    scan_rc=$?

    return "$scan_rc"
}

# Inputs:
#   $1: Resolved image reference.
#   $2: Local image result directory.
#   $3: OpenSCAP scan exit code.
#   Environment: IMAGE_COMMANDS.
# Side effects:
#   Runs IMAGE_COMMANDS inside a fresh container and writes post-scan-evidence.log.
#   /oscap-results is mounted so commands can write files into the result folder.
# Returns:
#   Exit code from the evidence container.
run_evidence() {
    local resolved_image="$1"
    local image_result_dir="$2"
    local scan_rc="$3"
    local evidence_rc

    echo "Running post-scan evidence commands inside $resolved_image"
    set +e
    docker run --rm \
        --entrypoint /bin/bash \
        -e "OSCAP_TARGET_IMAGE=$resolved_image" \
        -e "OSCAP_IMAGE_RESULT_DIR=/oscap-results" \
        -e "OSCAP_SCAN_EXIT_CODE=$scan_rc" \
        -v "$image_result_dir:/oscap-results" \
        "$resolved_image" \
        -lc "$IMAGE_COMMANDS" \
        > "$image_result_dir/post-scan-evidence.log" 2>&1
    evidence_rc=$?

    return "$evidence_rc"
}

# Inputs:
#   Global variables: selected_image_list, results_dir, blob_url_base, OSCAP_RUN_ID.
# Side effects:
#   Scans all selected images sequentially and writes overall-exit-code.txt.
# Returns:
#   0; aggregate scan status is written to overall-exit-code.txt for Jenkins to consume.
scan_selected_images() {
    overall_rc=0

    while IFS='|' read -r image component datastream profile; do
        if [[ -z "$image" ]]; then
            continue
        fi
        scan_image "$image" "$component" "$datastream" "$profile"
    done < "$selected_image_list"

    echo "$overall_rc" > "$results_dir/overall-exit-code.txt"
    echo "OSCAP image scan links: $results_dir/storage-links.txt"
    echo "Blob root: $blob_url_base/$OSCAP_RUN_ID/"
}

# Inputs:
#   Environment variables validated by require_env plus optional scan parameters.
# Side effects:
#   Runs the full image scan workflow and uploads SCAP reports.
# Returns:
#   0 when orchestration completes; individual scan failures are represented in
#   overall-exit-code.txt, while unexpected command failures return non-zero.
main() {
    require_env \
        WORKSPACE \
        OSCAP_OUTPUT_ROOT \
        OSCAP_RUN_ID \
        IMAGE_LIST_FILE \
        OSCAP_STORAGE_ACCOUNT \
        OSCAP_RESULTS_CONTAINER \
        NEXUS_DOMAIN \
        NEXUS_USERNAME \
        NEXUS_PASSWORD

    if ! is_true "$RUN_SCANS" && [[ -z "$IMAGE_COMMANDS" ]]; then
        echo "IMAGE_COMMANDS is required when RUN_SCANS is false" >&2
        exit 1
    fi
    init_workspace
    resolve_storage_upload_credentials
    build_selected_image_list
    scan_selected_images
}

main "$@"
