// Jenkins Job DSL script to create all WDSF jobs
// This script creates pipeline jobs from Jenkinsfiles


// Set parameters
def workspace = WORKSPACE
def jobDefinitions = JOB_DEFINITIONS

// Create all pipeline jobs
jobDefinitions.each { entry ->
    def jobKey = entry.key
    def jobName = entry.value.name
    def jobDescription = entry.value.description
    def skipJob = entry.value.skipJob
    def jobType = entry.value.type ?: 'pipeline'

    if (!skipJob) {
        if (jobType == 'multibranch') {
            multibranchPipelineJob(jobName) {
                description(jobDescription)

                branchSources {
                    git {
                        id(jobName)
                        remote(entry.value.repoUrl)
                        credentialsId(entry.value.credentialsId)
                        includes(entry.value.includes ?: '*')
                    }
                }

                factory {
                    workflowBranchProjectFactory {
                        scriptPath(entry.value.scriptPath ?: 'Jenkinsfile')
                    }
                }

                orphanedItemStrategy {
                    discardOldItems {
                        numToKeep(20)
                    }
                }
            }
        } else {
            pipelineJob(jobName) {
                description(jobDescription)

                // Configure pipeline definition with embedded script content
                definition {
                    cps {
                        // Read the Jenkinsfile content directly from the workspace
                        def scriptContent = readFileFromWorkspace("jenkins/wdsf/${jobKey}.jenkinsfile")
                        script(scriptContent)
                        sandbox(true)
                    }
                }
            }
        }
    }
}

// Create a list view for all WDSF jobs
listView('WDSF Jobs') {
    description('All WDSF deployment and utility jobs')
    jobs {
        jobDefinitions.each { entry ->
            name(entry.value.name)
        }
    }
    columns {
        status()
        weather()
        name()
        lastSuccess()
        lastFailure()
        lastDuration()
        buildButton()
    }
}
