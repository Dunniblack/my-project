param(
    [Parameter(Mandatory = $true)]  [string]$StorageAccountName,
    [Parameter(Mandatory = $true)]  [string]$ContainerName,
    [Parameter(Mandatory = $false)] [string]$StorageAccountKey  = '',
    [Parameter(Mandatory = $false)] [string]$ClusterNamePattern = '^AKSJOMS[A-Za-z]{4}GV01$'
)

# Shared helpers.
. "$PSScriptRoot/../functions/CommonUtilities.ps1"
. "$PSScriptRoot/../functions/AzStorageAccountTools.ps1"

$ErrorActionPreference = "Stop"

# Fixed thresholds.
$WarningThresholdDays = 55
$StigHardLimitDays    = 60
$KvNameBasePrefix     = 'GVJOMS'

$CurrentDateStr = Get-Date -Format "yyyyMMdd-HHmm"
$TotalFindings  = 0
$FailedClusters = @()

# Storage target.
if ($StorageAccountKey) {
    $AlertStorageInfo = New-StorageAccountInfo -Name $StorageAccountName -Container $ContainerName -AccountKey $StorageAccountKey
} else {
    $AlertStorageInfo = New-StorageAccountInfo -Name $StorageAccountName -Container $ContainerName
}

# Tracked credentials.
$trackedSecrets = @{
    "rancher-admin-password"  = @{ Namespace = "cattle-system"; Deployment = "core-app-rancher" }
    # "argocd-admin-password"   = @{ Namespace = "argocd";        Deployment = "core-app-argocd-server" }
    # "keycloak-admin-password" = @{ Namespace = "keycloak";      Deployment = "core-app-keycloak" }
}

# 1. Discover clusters.
Write-Host "`n=========================================="
Write-Host "STIG 60-Day Credential Expiry Monitor"
Write-Host "Pattern   : $ClusterNamePattern"
Write-Host "KV prefix : $KvNameBasePrefix{workspaceId}*"
Write-Host "Threshold : $WarningThresholdDays days (warn) / $StigHardLimitDays days (expired)"
Write-Host "Storage   : $StorageAccountName / $ContainerName (auth-mode: key)"
Write-Host "==========================================`n"

Write-Host "Fetching AKS cluster list from subscription..."
$ClusterJsonRaw = Exec az aks list --query "[].{name:name, rg:resourceGroup}" -o json
$ClusterJsonStr = ($ClusterJsonRaw -join "`n")
[array]$AllClusters = ConvertFrom-Json -InputObject $ClusterJsonStr

[array]$Clusters = $AllClusters | Where-Object { $_.name -match $ClusterNamePattern }

Write-Host "Found $($AllClusters.Count) AKS cluster(s) in subscription; $($Clusters.Count) match pattern '$ClusterNamePattern'."

if ($Clusters.Count -eq 0) {
    Write-Host "No matching clusters. Exiting cleanly."
    exit 0
}
Write-Host ""

# 2. Scan each cluster.
foreach ($C in $Clusters) {
    Write-Host "--- Checking Cluster: $($C.name) in RG: $($C.rg) ---"
    $ExpiringCreds = @()

    try {
# Extract the workspace ID.
        if ($C.name -notmatch '^AKSJOMS([A-Za-z]{4})') {
            throw "Cluster name '$($C.name)' does not match expected pattern 'AKSJOMS{4-letters}...'. Cannot extract workspace ID for KV lookup."
        }
        $WorkspaceId  = $Matches[1]
        $KvNamePrefix = "$KvNameBasePrefix$WorkspaceId"
        Write-Host "  Cluster workspace ID: $WorkspaceId -> KV prefix: $KvNamePrefix"

# Locate the Key Vault.
        $kvNameRaw = Exec az keyvault list --resource-group $C.rg `
            --query "[?starts_with(name, '$KvNamePrefix')].name" -o tsv
        $KeyVaultName = ($kvNameRaw -split "`n" | Where-Object { $_ } | Select-Object -First 1)

        if (-not $KeyVaultName) {
            throw "No Key Vault with name starting with '$KvNamePrefix' found in resource group '$($C.rg)' for cluster $($C.name)."
        }
        Write-Host "  Using Key Vault: $KeyVaultName"

    # Authenticate to AKS.
        $null = Exec az aks get-credentials --resource-group $C.rg --name $C.name --overwrite-existing
        $null = Exec kubelogin convert-kubeconfig -l azurecli

    # Check tracked secrets.
        foreach ($secretName in $trackedSecrets.Keys) {
            $ageDays = $null
            $source  = ""

            try {
                $secret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $secretName -ErrorAction Stop
                $ageDays = (New-TimeSpan -Start $secret.Updated.DateTime -End (Get-Date)).Days
                $source  = "Azure Key Vault"
            }
            catch {
                Write-Host "  [INFO] $secretName not found in KV $KeyVaultName. Checking initial deployment age via kubectl..."

                $ns     = $trackedSecrets[$secretName].Namespace
                $deploy = $trackedSecrets[$secretName].Deployment

                try {
                    $creationTimeStr = Exec kubectl get deployment $deploy -n $ns -o jsonpath='{.metadata.creationTimestamp}'

                    if (-not [string]::IsNullOrWhiteSpace($creationTimeStr)) {
                        $creationTimeStr = $creationTimeStr -replace "'", ""
                        $creationDate    = [datetime]$creationTimeStr
                        $ageDays         = (New-TimeSpan -Start $creationDate -End (Get-Date)).Days
                        $source          = "Cluster Deployment ($deploy)"
                    }
                    else {
                        Write-Warning "  [WARN] Could not retrieve creation timestamp for deployment '$deploy' in namespace '$ns'."
                    }
                }
                catch {
                    Write-Warning "  [WARN] Failed to query kubectl for '$deploy' in namespace '$ns'. Is the tool deployed?"
                }
            }

            if ($null -ne $ageDays) {
                Write-Host "  Secret: $secretName | Age: $ageDays Days | Source: $source"

                if ($ageDays -ge $WarningThresholdDays) {
                    $ExpiringCreds += [PSCustomObject]@{
                        Cluster       = $C.name
                        ResourceGroup = $C.rg
                        KeyVault      = $KeyVaultName
                        WorkspaceId   = $WorkspaceId
                        SecretName    = $secretName
                        AgeDays       = $ageDays
                        Source        = $source
                        Status        = if ($ageDays -ge $StigHardLimitDays) { "EXPIRED" } else { "EXPIRING_SOON" }
                    }
                }
            }
        }
    }
    catch {
        Write-Warning "  [ERROR] Failed to scan cluster $($C.name): $($_.Exception.Message)"
        $FailedClusters += [PSCustomObject]@{
            Cluster       = $C.name
            ResourceGroup = $C.rg
            Error         = $_.Exception.Message
        }
        continue
    }

    # 3. Upload findings.
    if ($ExpiringCreds.Count -gt 0) {
        $TotalFindings += $ExpiringCreds.Count
        $ReportName = "credential_alert_$($C.name)_$CurrentDateStr.json"
        $TempPath   = Join-Path $env:TEMP $ReportName

        $ExpiringCreds | ConvertTo-Json -Depth 5 | Set-Content -Path $TempPath -Encoding UTF8

        Write-Host "`n  Uploading $ReportName ($($ExpiringCreds.Count) finding(s)) to storage..."
        Save-Blob `
            -StorageAccountInfo $AlertStorageInfo `
            -BlobName "alerts/$ReportName" `
            -FilePath $TempPath
        Write-Host "  Upload successful: alerts/$ReportName"

        Remove-Item -Path $TempPath -Force -ErrorAction SilentlyContinue
    }
    else {
        Write-Host "  All tracked credentials within threshold for cluster $($C.name)."
    }

    Write-Host ""
}

# 4. Summary.
Write-Host "=========================================="
Write-Host "Credential expiry monitoring completed."
Write-Host "Clusters scanned : $($Clusters.Count)"
Write-Host "Clusters failed  : $($FailedClusters.Count)"
Write-Host "Total findings   : $TotalFindings"
Write-Host "=========================================="

if ($TotalFindings -gt 0) {
    Write-Warning "$TotalFindings credential(s) at or beyond $WarningThresholdDays-day warning threshold."
}

# Fail on cluster scan errors.
if ($FailedClusters.Count -gt 0) {
    Write-Warning "$($FailedClusters.Count) cluster(s) could not be scanned - see log above. Marking step as failed."
    exit 1
}

exit 0
