param (
    [Parameter(Mandatory = $true)]
    [string]$StorageAccountName,

    [Parameter(Mandatory = $true)]
    [string]$ContainerName,

    [Parameter(Mandatory = $false)]
    [string]$StorageAccountKey = '',

    [Parameter(Mandatory = $false)]
    [string]$ClusterNamePattern = ''
)

# Shared helpers.
. "$PSScriptRoot/../functions/CommonUtilities.ps1"
. "$PSScriptRoot/../functions/AzStorageAccountTools.ps1"

$ErrorActionPreference = "Stop"

# Fixed threshold.
$ExpiryThresholdDays = 30

$ExpirationLimit  = (Get-Date).AddDays($ExpiryThresholdDays)
$CurrentDateStr   = Get-Date -Format "yyyyMMdd-HHmm"
$TotalFindings    = 0
$FailedClusters   = @()

# Storage target.
if ($StorageAccountKey) {
    $AlertStorageInfo = New-StorageAccountInfo -Name $StorageAccountName -Container $ContainerName -AccountKey $StorageAccountKey
} else {
    $AlertStorageInfo = New-StorageAccountInfo -Name $StorageAccountName -Container $ContainerName
}

# 1. Discover clusters.
Write-Host "`n=========================================="
Write-Host "AKS TLS Certificate Expiry Monitor"
Write-Host "Threshold : $ExpiryThresholdDays days"
if ($ClusterNamePattern) {
    Write-Host "Pattern   : $ClusterNamePattern"
} else {
    Write-Host "Pattern   : (none - scanning all clusters)"
}
Write-Host "Storage   : $StorageAccountName / $ContainerName (auth-mode: key)"
Write-Host "==========================================`n"

Write-Host "Fetching AKS cluster list from subscription..."
$ClusterJsonRaw = Exec az aks list --query "[].{name:name, rg:resourceGroup}" -o json
$ClusterJsonStr = ($ClusterJsonRaw -join "`n")
[array]$AllClusters = ConvertFrom-Json -InputObject $ClusterJsonStr

# Apply filter only when requested.
if ($ClusterNamePattern) {
    [array]$Clusters = $AllClusters | Where-Object { $_.name -match $ClusterNamePattern }
    Write-Host "Found $($AllClusters.Count) AKS cluster(s) in subscription; $($Clusters.Count) match pattern '$ClusterNamePattern'."
} else {
    [array]$Clusters = $AllClusters
    Write-Host "Found $($Clusters.Count) AKS cluster(s) in subscription."
}

if ($Clusters.Count -eq 0) {
    Write-Host "No AKS clusters identified. Exiting cleanly."
    exit 0
}
Write-Host ""

# 2. Scan each cluster.
foreach ($C in $Clusters) {
    Write-Host "--- Checking Cluster: $($C.name) in RG: $($C.rg) ---"
    $ExpiringCerts = @()

    try {
        $null = Exec az aks get-credentials --resource-group $C.rg --name $C.name --overwrite-existing

        $null = Exec kubelogin convert-kubeconfig -l azurecli

        $namespaceOutput = Exec kubectl get namespaces -o jsonpath='{.items[*].metadata.name}'

        foreach ($ns in (-split $namespaceOutput)) {
            Write-Host "  Checking namespace: $ns"

            $secretOutput = Exec kubectl get secrets -n $ns --field-selector type=kubernetes.io/tls `
                -o jsonpath='{.items[*].metadata.name}'

            foreach ($s in (-split $secretOutput)) {
                Write-Host "    Processing secret: $s"

                $certKeys = @("tls.crt", "ca.crt")
                foreach ($key in $certKeys) {
                    $certDataB64 = Exec kubectl get secret $s -n $ns -o jsonpath="{.data.$($key.Replace('.', '\.'))}"

                    if ($certDataB64) {
                        $cert = [Security.Cryptography.X509Certificates.X509Certificate2]::new(
                            [Convert]::FromBase64String($certDataB64)
                        )
                        $daysRemaining = ($cert.NotAfter - (Get-Date)).Days

                        $status = "Valid"
                        if ($cert.NotAfter -lt (Get-Date)) { $status = "EXPIRED" }
                        elseif ($cert.NotAfter -lt $ExpirationLimit) { $status = "EXPIRING_SOON" }

                        if ($status -ne "Valid") {
                            $ExpiringCerts += [PSCustomObject]@{
                                Cluster       = $C.name
                                ResourceGroup = $C.rg
                                Namespace     = $ns
                                SecretName    = $s
                                CertType      = $key
                                Subject       = $cert.Subject
                                Issuer        = $cert.Issuer
                                ExpiryDate    = $cert.NotAfter.ToString("yyyy-MM-dd HH:mm:ss")
                                Status        = $status
                                DaysRemaining = $daysRemaining
                            }

                            $icon = if ($status -eq "EXPIRED") { "[!!]" } else { "[!]" }
                            Write-Host "      $icon $key ($status): $($cert.NotAfter.ToString('yyyy-MM-dd')) (${daysRemaining}d remaining)"
                        }
                    }
                }
            }
        }
    }
    catch {
        Write-Warning "  [ERROR] Failed to scan cluster $($C.name): $($_.Exception.Message)"
        $FailedClusters += [PSCustomObject]@{
            Cluster       = $C.name
            ResourceGroup = $C.rg
            Error         = $_.Exception.Message
        }
        continue
    }

    # 3. Upload findings.
    if ($ExpiringCerts.Count -gt 0) {
        $TotalFindings += $ExpiringCerts.Count
        $ReportName = "tls_alert_$($C.name)_$CurrentDateStr.json"
        $TempPath = Join-Path $env:TEMP $ReportName

        $ExpiringCerts | ConvertTo-Json -Depth 5 | Set-Content -Path $TempPath -Encoding UTF8

        Write-Host "`n  Uploading $ReportName ($($ExpiringCerts.Count) finding(s)) to storage..."
        Save-Blob `
            -StorageAccountInfo $AlertStorageInfo `
            -BlobName "alerts/$ReportName" `
            -FilePath $TempPath
        Write-Host "  Upload successful: alerts/$ReportName"

        # Clean up temp file
        Remove-Item -Path $TempPath -Force -ErrorAction SilentlyContinue
    }
    else {
        Write-Host "  No expiring certificates found in cluster $($C.name)."
    }

    Write-Host ""
}

# 4. Summary.
Write-Host "=========================================="
Write-Host "AKS TLS monitoring completed."
Write-Host "Clusters scanned : $($Clusters.Count)"
Write-Host "Clusters failed  : $($FailedClusters.Count)"
Write-Host "Total findings   : $TotalFindings"
Write-Host "=========================================="

if ($TotalFindings -gt 0) {
    Write-Warning "$TotalFindings certificate(s) are expiring or already expired within $ExpiryThresholdDays days."
}

# Fail on cluster scan errors.
if ($FailedClusters.Count -gt 0) {
    Write-Warning "$($FailedClusters.Count) cluster(s) could not be scanned - see log above. Marking step as failed."
    exit 1
}

exit 0
